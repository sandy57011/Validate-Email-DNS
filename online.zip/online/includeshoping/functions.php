<?php
	function get_product_name($pid){
		$result=mysql_query("select productname from tbl_products where id=$pid");
		$row=mysql_fetch_array($result);
		return $row['productname'];
	}
	function get_image($pid){
		$result=mysql_query("select logoimg from tbl_products where id=$pid");
		$row=mysql_fetch_array($result);
		return $row['logoimg'];
	}
	function get_price($pid,$rid,$bulkid){
		if($rid>0 && $bulkid=='1') {
		$result=mysql_query("select price_inr from tbl_productprice_rateBulk where p_id='".$pid."' and id = '".$rid."'");
		$row=mysql_fetch_array($result);
		return $row['price_inr'];
		}
		if($rid>0 && $bulkid=='0') {
		$result=mysql_query("select price_inr from tbl_productprice_rate where p_id='".$pid."' and id = '".$rid."'");
		$row=mysql_fetch_array($result);
		return $row['price_inr'];		
		}
		if($rid=='0' && $bulkid=='0') {
		$result=mysql_query("select productpriceinr from tbl_products where id=$pid");
		$row=mysql_fetch_array($result);
		return $row['productpriceinr'];
		}
	}
	function get_pricedollor($pid,$rid,$bulkid){
		if($rid>0 && $bulkid=='1') {
		$result=mysql_query("select price_dollar from tbl_productprice_rateBulk where p_id='".$pid."' and id = '".$rid."'");
		$row=mysql_fetch_array($result);
		return $row['price_dollar'];
		}
		if($rid>'0' && $bulkid=='0') {
		$result=mysql_query("select price_dollar from tbl_productprice_rate where p_id='".$pid."' and id = '".$rid."'");
		$row=mysql_fetch_array($result);
		return $row['price_dollar'];		
		}
		if($rid=='0' && $bulkid=='0') {
		$result=mysql_query("select productpricedollar from tbl_products where id=$pid");
		$row=mysql_fetch_array($result);
		return $row['productpricedollar'];
		}
	}	
	function remove_product($pid,$bulkid){
		$pid=intval($pid);
		$max=count($_SESSION['cart']);
		for($i=0;$i<$max;$i++){
			if(($pid==$_SESSION['cart'][$i]['productid']) && ($bulkid==$_SESSION['cart'][$i]['bulk'])){
				unset($_SESSION['cart'][$i]);
				break;
			}
		}
		$_SESSION['cart']=array_values($_SESSION['cart']);
	}
	function get_order_total(){
		$max=count($_SESSION['cart']);
		$sum=0;
		for($i=0;$i<$max;$i++){
			$pid=$_SESSION['cart'][$i]['productid'];
			$q=$_SESSION['cart'][$i]['qty'];
			$rrtid=$_SESSION['cart'][$i]['selp'];
			$bulkid=$_SESSION['cart'][$i]['bulk'];
			$price=get_price($pid,$rrtid,$bulkid);
			$sum+=$price*$q;
		}
		return $sum;
	}
	function get_order_total_off($total_amount,$off_flat){
		return $total_flat = ($total_amount*$off_flat)/100;
	}
	function get_order_total_gst($total_amount,$total_off,$gst){
		$total_sub_amount = $total_amount-$total_off;
		return $total_flat = ($total_sub_amount*$gst)/100;
	}
	function get_order_total_grand($total_amount,$total_off,$gst){
		$total_sub_amount = $total_amount-$total_off;
		return $total_flat = round($total_sub_amount+$gst);
	}
function addtocart($pid,$q,$selp=0,$bulkid){
	
$max=count($_SESSION['cart']);
	for($i=0;$i<$max;$i++){	
		if($_SESSION['cart'][$i]['productid']==$pid) {
		$_SESSION['cart'][$i]['qty']=$q;
		$_SESSION['cart'][$i]['selp']=$selp;
		$_SESSION['cart'][$i]['bulk']=$bulkid;
		}
		}	
	
		if($pid<1 or $q<1) return;
		
		if(is_array($_SESSION['cart'])){
			if(product_exists($pid,$bulkid)) return;
			$max=count($_SESSION['cart']);
			$_SESSION['cart'][$max]['productid']=$pid;
			$_SESSION['cart'][$max]['qty']=$q;
			$_SESSION['cart'][$max]['selp']=$selp;
			$_SESSION['cart'][$max]['bulk']=$bulkid;
		}
		else{
			$_SESSION['cart']=array();
			$_SESSION['cart'][0]['productid']=$pid;
			$_SESSION['cart'][0]['qty']=$q;
			$_SESSION['cart'][0]['selp']=$selp;
			$_SESSION['cart'][0]['bulk']=$bulkid;
		}
	}
	function product_exists($pid,$bulkid){
		$pid=intval($pid);
		$max=count($_SESSION['cart']);
		$flag=0;
		for($i=0;$i<$max;$i++){
			if(($pid==$_SESSION['cart'][$i]['productid']) && ($bulkid==$_SESSION['cart'][$i]['bulk'])){
				$flag=1;
				break;
			}
		}
		return $flag;
	}
	function validate_payUmoney_transac($posted = '')
	{
		$status=$posted["status"];
		$firstname=$posted["firstname"];
		$amount=$posted["amount"];
		$txnid=$posted["txnid"];
		$posted_hash=$posted["hash"];
		$key=$posted["key"];
		$productinfo=$posted["productinfo"];
		$email=$posted["email"];
		$salt="d4JB5Yddyd";

		If (isset($posted["additionalCharges"])) {
		   $additionalCharges=$posted["additionalCharges"];
			$retHashSeq = $additionalCharges.'|'.$salt.'|'.$status.'|||||||||||'.$email.'|'.$firstname.'|'.$productinfo.'|'.$amount.'|'.$txnid.'|'.$key;
				
		}else{	  
			$retHashSeq = $salt.'|'.$status.'|||||||||||'.$email.'|'.$firstname.'|'.$productinfo.'|'.$amount.'|'.$txnid.'|'.$key;

		}
		$hash = hash("sha512", $retHashSeq);
		
		if ($hash != $posted_hash) {
			return false;
		}
		
		return true;
	}
?>