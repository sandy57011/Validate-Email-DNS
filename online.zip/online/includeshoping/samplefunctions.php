<?php
	function sampleget_product_name($pid){
		$result=mysql_query("select sample_name from manage_sampleproduct where id=$pid");
		$row=mysql_fetch_array($result);
		return $row['sample_name'];
	}
	function sampleget_image($pid){
		$result=mysql_query("select imagefilename from manage_sampleproduct where id=$pid");
		$row=mysql_fetch_array($result);
		return $row['imagefilename'];
	}
	function sampleget_price($pid){
		$result=mysql_query("select samplepriceinr from manage_sampleproduct where id=$pid");
		$row=mysql_fetch_array($result);
		return $row['samplepriceinr'];
	}
	function sampleremove_product($pid){
		$pid=intval($pid);
		$max=count($_SESSION['samplecart']);
		for($i=0;$i<$max;$i++){
			if($pid==$_SESSION['samplecart'][$i]['productid']){
				unset($_SESSION['samplecart'][$i]);
				break;
			}
		}
		$_SESSION['samplecart']=array_values($_SESSION['samplecart']);
	}
	function sampleget_order_total(){
		$max=count($_SESSION['samplecart']);
		$sum=0;
		for($i=0;$i<$max;$i++){
			$pid=$_SESSION['samplecart'][$i]['productid'];
			$q=$_SESSION['samplecart'][$i]['qty'];
			$price=sampleget_price($pid);
			$sum+=$price*$q;
		}
		return $sum;
	}
	function sampleaddtocart($pid,$q){
	
$max=count($_SESSION['samplecart']);
		for($i=0;$i<$max;$i++){	
		if($_SESSION['samplecart'][$i]['productid']==$pid) {
		
		$_SESSION['samplecart'][$i]['qty']=$q;
		}
		
		}	
		if($pid<1 or $q<1) return;
		
		if(is_array($_SESSION['samplecart'])){
			if(sampleproduct_exists($pid)) return;
			$max=count($_SESSION['samplecart']);
			$_SESSION['samplecart'][$max]['productid']=$pid;
			$_SESSION['samplecart'][$max]['qty']=$q;
		}
		else{
			$_SESSION['samplecart']=array();
			$_SESSION['samplecart'][0]['productid']=$pid;
			$_SESSION['samplecart'][0]['qty']=$q;
		}
			
		
	}
	function sampleproduct_exists($pid){
		$pid=intval($pid);
		$max=count($_SESSION['samplecart']);
		$flag=0;
		for($i=0;$i<$max;$i++){
			if($pid==$_SESSION['samplecart'][$i]['productid']){
				$flag=1;
				break;
			}
		}
		return $flag;
	}

?>