<?php
ob_start();
@session_start();
include("include/connect.php");
include("include/function.php");
?>
<?php $result_seo=mysql_fetch_array(mysql_query("select * from  contents where id='1'"));?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo stripslashes($result_seo['title_tag']); ?></title>
<meta name="description" content="<?php echo stripslashes($result_seo['description_tag']); ?>" />
<meta name="keywords" content="<?php echo stripslashes($result_seo['meta_tag']); ?>" />

<link rel="shortcut icon" type="image/x-icon" href="<?=$rootpath?>/images/favicon.png" />



<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />


<script type="text/javascript" src="menu/js/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" media="all" href="menu/css/webslidemenu.css" />
<script type="text/javascript" src="menu/js/webslidemenu.js"></script>
<link rel="stylesheet" type="text/css" href="menu/font-awesome/css/font-awesome.min.css" />

</head>
<body>


<?php include("header.php");?>
<div class="slider">

<div class="hidden-sm hidden-xs">
<?php include("slide.php");?>
</div>
<div class="s-text"><strong>flat 20% off</strong><br />
on all orders above INR 99/-</div>
<div class="marquee">
<div class="container">
<div class="row">

<div class="col-md-2 hidden-sm hidden-xs">
<h2>Today's Offer:</h2>
</div>

<div class="col-md-10">

 <?php $resRow=mysql_fetch_array(mysql_query("select * from manage_heading where id='1'")); ?>
<marquee align="left"> <?php echo $resRow['heading']; ?></marquee>

</div>

</div>
</div>
</div>
</div>




<div class="container">
<div class="content">


<div class="ads">
<?php
$indexRows = mysql_query("select * from manage_partners where status = 1"); 
$a = 1;
while($result_rec=mysql_fetch_array($indexRows)) { 

?>



<div class="ad<?php echo $a; ?>">

  <a href="<?php echo $result_rec['url_name']; ?>"><img title="<?php echo $result_rec['partners_name']; ?>" src="adminimg/partners/<?php echo $result_rec['logoimg']; ?>" alt="ramal vigyan" /></a>
  
</div>



<?php 
$a++; 
} 
?>
<div class="clear"></div>
</div>

</div>
</div>


<div class="container2">
<div class="container">
<div class="content">
<div class="heading">
<h2>Most Popular Items</h2>
</div>
<div class="filter-div">
	<form method="post" id="filter_form">
		<label>Filter:</label>
		<select name="veg_filter" id="veg_filter">
			<option value="all">All</option>
			<option value="veg">Veg</option>
			<option value="non_veg">Non - Veg</option>
		</select>
	</form>
</div>
<div id="content_filter_veg">
<?php $result_productcat = mysql_fetch_array(mysql_query("select * from manage_productcategory order by id"));?>

<?php
$newArrivalProductList = getNewArrivalProductList();
if(count($newArrivalProductList)>0) {
foreach($newArrivalProductList as $newArrivalProductListData){
?>
<div class="product">
<a href="<?=$rootpath?>/astroDetail-<?php echo getProductCategoryUrlnameById($newArrivalProductListData['cat_id']);?>/<?php echo $newArrivalProductListData['urlname'];?>">
<div class="p-img">
<img src="adminimg/logoimg/<?php echo $newArrivalProductListData['logoimg']; ?>" alt="new" />
</div>
<div class="<?php if($newArrivalProductListData['non_veg'] ==0){echo 'veg'; }else{ echo 'non-veg';} ?>">&nbsp;</div>
<h3><?php echo $newArrivalProductListData['productname']; ?></h3>
<h5><i class="fa fa-inr"></i> <?php echo $newArrivalProductListData['productpriceinr'];?>/-</h5>
</a>
<span class="btn1" onClick="addtocart('<?php echo $newArrivalProductListData['id']?>','0')"><i class="fa fa-cart-plus" aria-hidden="true"></i> Add to cart</span>
</div>
<?php } ?>
<?php } ?>
<div class="clear"></div>
</div>


<div class="clear"></div>
</div>
</div>
</div>





<div class="home-1">
<div class="container text-center">
<div class="heading">
<h2>Browse by Category</h2>
</div>


<ul>

<?php
$productCategoryList =getProductCategoryList();
if(count($productCategoryList)>0) {
foreach($productCategoryList as $productCategoryListData) {
if(getProductCountByCatId($productCategoryListData['id'])>0) {
?>          
<li><a href="<?=$rootpath?>/astro-<?php echo $productCategoryListData['urlname'];?>">

<?php if($productCategoryListData[imagefilename] and file_exists("adminimg/logoimg/".$productCategoryListData[imagefilename])) { ?> 
<span><img src="<?=$rootpath?>/adminimg/logoimg/<?php echo $productCategoryListData[imagefilename]; ?>" title="<?php echo $productCategoryListData[titletag]; ?>" alt="<?php echo $productCategoryListData[alttag]; ?>"/></span>
<? } else {?>
<span><img src="images/cutlery.png" alt="Category" /></span>
<?php } ?>
<br />
<?php echo $productCategoryListData['name']; ?></a></li>          
<?php } ?>          
<?php } ?>         
<?php } ?>


</ul>

<div class="clear"></div>


</div>
</div>





<div class="container">
<div class="content text-center">
<?php
$indexRow = mysql_fetch_array(mysql_query("select * from contents where id='1'")); 
?>

<div class="heading">
<h1><?php echo stripslashes($indexRow['heading']); ?></h1>
</div>

<?php echo restoreTags(stripslashes($indexRow['description'])); ?>


<a href="about-us" class="btn1">Read More</a>

</div>
</div>



<!--------------------  New Arrival Section End   --------------------->



<?php include("footer.php");?>
<style>
    div#loadingDiv {
    opacity:0.7;
    filter: alpha(opacity=20);
    background-color:#000; 
    width:100%; 
    height:100%; 
    z-index:10;
    top:0; 
    left:0; 
    position:fixed; 
  }
</style>
<div id="loadingDiv"></div>
<form name="frmproduct" id="frmproduct" method="post" action="">
                            <input type="hidden" name="productid" />
                            <input type="hidden" name="productidbulk" />
                            <input type="hidden" name="command" />
</form>
<script language="javascript">
function addtocart(pid,bulkid){
	document.frmproduct.productid.value=pid;
	document.frmproduct.productidbulk.value=bulkid;
	document.frmproduct.command.value='add';
	
	$.post("ajax_add_to_cart.php",$("form#frmproduct").serialize(),
    function(data, status){
        if(status == 'success'){
            $("a#master_shopping_cart_top").html('');
            $("a#master_shopping_cart_top").html('<i class="fa fa-shopping-cart"></i>Cart ('+data+')');
			$("#cart_Modal").show();
        }
    });
}
$(document).ready(function(){
	   var $loading = $('#loadingDiv').hide();
        $(document)
          .ajaxStart(function () {
            $loading.show();
          })
          .ajaxStop(function () {
            $loading.hide();
          });
		  
		  $("#veg_filter").change(function(){
			  var veg_filter = $(this).val();
			  $("#content_filter_veg").html('<div class="please-wait">Loading...</div>');
			  $.ajax({
				type: "POST",
				url: "ajax_add_to_cart.php",
				data: "veg_filter="+veg_filter,
				success: function(data){
					$("#content_filter_veg").html(data);
				}
			  });
		  });
	});
</script>  
<div id="cart_Modal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Modal Header</h4>
      </div>
      <div class="modal-body">
        <p>Some text in the modal.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

</body>
</html>