<?php
ob_start();
@session_start();
include("include/connect.php");
include("include/function.php");
?>
<?php 
   include("includeshoping/functions.php");
?>
<?php

 $total_off = get_order_total_off(get_order_total(),20);
$gst_amount =get_order_total_gst(get_order_total(),$total_off,5);
$get_order_total_grand=get_order_total_grand(get_order_total(),$total_off,$gst_amount);
if($_REQUEST['btn']=='Confirm Order'){

$payment_method = $_REQUEST['payment_method'];
	
if($_REQUEST['samechk']=='1') {
$Bname = $_REQUEST[Nname];
$BPhone1 = $_REQUEST['NPhone1'];
$Bemail = $_REQUEST['email'];
$Bcity = $_REQUEST['Ncity'];
$Baddress1 = $_REQUEST['Naddress1'];
$BCountry = $_REQUEST['NCountry'];
$Bzipcode = $_REQUEST['NZipcode'];

$BComments = $_REQUEST['NComments'];
$sameasaddress = 1;
}	else {
$Bname = $_REQUEST[Bname];
$BPhone1 = $_REQUEST['BPhone1'];
$Bemail = $_REQUEST['Bemail'];
$Bcity = $_REQUEST['Bcity'];
$Baddress1 = $_REQUEST['Baddress1'];
$BCountry = $_REQUEST['BCountry'];
$Bzipcode = $_REQUEST['Bzipcode'];

$BComments = $_REQUEST['BComments'];
$sameasaddress = 0;
}	
	
if($_SESSION['MemId']=="") {
	mysql_query("insert into customers set ins = ''") or die(mysql_error());
	$sescustid = mysql_insert_id();
	$_SESSION[MemId] = $sescustid;
		
	mysql_query("insert into orders set memid = '".$_SESSION['MemId']."', orderid = '".$_SESSION["shoporderid"]."', se_brow_id = '".$br_s_id."', 
	delivery_cust_email = '".$_REQUEST['email']."', 
	delivery_cust_name = '".$_REQUEST['Nname']."', 
	delivery_cust_address = '".$_REQUEST['Naddress1']."', 
	delivery_cust_city = '".$_REQUEST['Ncity']."', 
	delivery_cust_state = '".$_REQUEST['NState']."', 
	delivery_cust_zip = '".$_REQUEST['NZipcode']."', 
	delivery_cust_country = '".$_REQUEST['NCountry']."', 
	delivery_cust_tel = '".$_REQUEST['NPhone1']."',
	delivery_comment = '".$_REQUEST['NComments']."',
	billing_cust_email = '".$Bemail."', 
	billing_cust_name = '".$Bname."', 
	billing_cust_address = '".$Baddress1."', 
	billing_cust_city = '".$Bcity."', 
	billing_cust_state = '".$_REQUEST['BState']."', 
	billing_zip = '".$Bzipcode."', 
	billing_cust_country = '".$BCountry."', 
	billing_cust_tel = '".$BPhone1."',
	billing_comment = '".$BComments."', 
	payment_method = '".$payment_method."', 
	reguserid = '".$_SESSION['user_idd']."'") or die(mysql_error());
}
else {
	
	mysql_query("update orders set se_brow_id = '".$br_s_id."', 
	delivery_cust_email = '".$_REQUEST['email']."', 
	delivery_cust_name = '".$_REQUEST['Nname']."', 
	delivery_cust_address = '".$_REQUEST['Naddress1']."', 
	delivery_cust_city = '".$_REQUEST['Ncity']."', 
	delivery_cust_state = '".$_REQUEST['NState']."', 
	delivery_cust_zip = '".$_REQUEST['NZipcode']."', 
	delivery_cust_country = '".$_REQUEST['NCountry']."', 
	delivery_cust_tel = '".$_REQUEST['NPhone1']."',
	delivery_comment = '".$_REQUEST['NComments']."',
	billing_cust_email = '".$Bemail."', 
	billing_cust_name = '".$Bname."', 
	billing_cust_address = '".$Baddress1."', 
	billing_cust_city = '".$Bcity."', 
	billing_cust_state = '".$_REQUEST['BState']."', 
	billing_zip = '".$Bzipcode."', 
	billing_cust_country = '".$BCountry."', 
	billing_cust_tel = '".$BPhone1."', 
	billing_comment = '".$BComments."', 
	payment_method = '".$payment_method."',
	reguserid = '".$_SESSION['user_idd']."' 
	where memid = '".$_SESSION['MemId']."' and orderid = '".$_SESSION["shoporderid"]."'") or die(mysql_error());
}		
	//////////////////////////////////////////////////////
$Oquery = "select * from order_mem where orderid = '".$_SESSION["shoporderid"]."'";
$OResult = mysql_query($Oquery) or die(mysql_error());
$ONumber = mysql_num_rows($OResult);

if($ONumber==0){

$ttoal = get_order_total();


 $query="insert into order_mem (orderid, memid, date, itemprice,offer_price,gst_price,name,email,mobile,productinfo,lastname,address1,address2,city,state,country,zipcode,udf1,udf2,udf3,udf4,udf5,pg,reguserid) values('".$_SESSION["shoporderid"]."', '".$_SESSION[MemId]."', '".time()."', '".$ttoal."','".$total_off."','".$gst_amount."','".$_REQUEST['Bname']."','".$_REQUEST['email']."','".$_REQUEST['BPhone1']."','".$_REQUEST['productinfo']."','".$_REQUEST['lastname']."','".$_REQUEST['Baddress1']."','".$_REQUEST['address2']."','".$_REQUEST[Bcity]."','".$_REQUEST[BState]."','".$_REQUEST[Bcountry]."','".$_REQUEST[Bzipcode]."','".$_REQUEST[udf1]."','".$_REQUEST[udf2]."','".$_REQUEST[udf3]."','".$_REQUEST[udf4]."','".$_REQUEST[udf5]."','".$_REQUEST[pg]."','".$_SESSION['user_idd']."')";

$insMId = mysql_insert_id();

$maxBulk=count($_SESSION['cart']);
	for($i=0;$i<$maxBulk;$i++){	
		if($_SESSION['cart'][$i]['bulk']=='1') {
mysql_query("update order_mem set bulkorder = '1' where id = '".$insMId."'");
		}
		} 
//mysql_query("insert into orders set memid = '".$_SESSION[MemId]."', orderid = '".$_SESSION["shoporderid"]."', se_brow_id = '".$br_s_id."'") or die(mysql_error());
}else{
$tutotal = get_order_total();
$query="UPDATE order_mem set  date = '".time()."', memid = '".$_SESSION[MemId]."', itemprice = '".$tutotal."',offer_price='".$total_off."',gst_price='".$gst_amount."',name='".$_REQUEST[Bname]."',email='".$_REQUEST[email]."',mobile='".$_REQUEST[BPhone1]."',productinfo='".$_REQUEST[productinfo]."',lastname='".$_REQUEST[lastname]."',address1='".$_REQUEST[Baddress1]."',address2='".$_REQUEST[address2]."',city='".$_REQUEST[Bcity]."',state='".$_REQUEST[BState]."',country='".$_REQUEST[Bcountry]."',zipcode='".$_REQUEST[Bzipcode]."',udf1='".$_REQUEST[udf1]."',udf2='".$_REQUEST[udf2]."',udf3='".$_REQUEST[udf3]."',udf4='".$_REQUEST[udf4]."',udf5='".$_REQUEST[udf5]."',pg='".$_REQUEST[pg]."', reguserid = '".$_SESSION['user_idd']."' where orderid = '".$_SESSION["shoporderid"]."'";


$maxBulk=count($_SESSION['cart']);
	for($i=0;$i<$maxBulk;$i++){	
		if($_SESSION['cart'][$i]['bulk']=='1') {
mysql_query("update order_mem set bulkorder = '1' where orderid = '".$_SESSION["shoporderid"]."'");
		}
		} 

}
mysql_query($query) or die(mysql_error());


if($payment_method == 'instamojo'){
    /*Instamojo payments*/
	define('API_KEY', '2cf9a6a6a482a4d64c8efeef3075c4cd');
	define('AUTH_TOKEN', 'd28bb06f7391926d7ce02970dc47bebe');

	require_once('include/instamojo/Instamojo.php');

	$api = new Instamojo\Instamojo(API_KEY,AUTH_TOKEN,'https://www.instamojo.com/api/1.1/');

	try {
	    $response = $api->paymentRequestCreate(array(
	        "purpose" => "Payment for Order:".$_SESSION["shoporderid"],
	        "amount" => $get_order_total_grand,
	        "send_email" => true,
	        "buyer_name" => $_REQUEST[Nname],
	        "phone" => $_REQUEST['NPhone1'],
	        "email" => $_REQUEST['email'],
	        "redirect_url" => "http://deliverykings.co.in/PayUMoneyform.php"
	        ));

	    $updt_qry = "UPDATE orders SET payment_request_id = '".$response['id']."' WHERE orderid=".$_SESSION["shoporderid"];
	    $Result = mysql_query($updt_qry) or die(mysql_error());
	    header("Location:".$response['longurl']);
	    exit();
	}
	catch (Exception $e) {
	    print('Error: ' . $e->getMessage());
	    exit();
	}
	/*Instamojo payments code ends*/
}

header("location:PayUMoneyform");
exit();
  // header("location:paysuccess.php");
}
?>
<?php $result_seo=mysql_fetch_array(mysql_query("select * from  tbl_seo where id='8'"));?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title><?php echo stripslashes($result_seo['title_tag']); ?></title>
<meta name="description" content="<?php echo stripslashes($result_seo['description_tag']); ?>" />
<meta name="keywords" content="<?php echo stripslashes($result_seo['meta_tag']); ?>" />


<link rel="shortcut icon" type="image/x-icon" href="<?=$rootpath?>/images/favicon.png" />




<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />


<script type="text/javascript" src="menu/js/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" media="all" href="menu/css/webslidemenu.css" />
<script type="text/javascript" src="menu/js/webslidemenu.js"></script>
<link rel="stylesheet" type="text/css" href="menu/font-awesome/css/font-awesome.min.css" />
</head>
<body>

<?php include("header.php");?>
<div class="inner-banner">
<div class="container">
<ul class="breadcrumb">
  <li><a href="<?php echo $rootpath; ?>/">Home</a></li>  
  <li><a href="<?php echo $rootpath; ?>/shoppingcart">Cart</a></li>  
  <li class="active">Billing</li>
</ul>
</div>
</div>
<!------------------------------------------------------------->
<?php
$loguserRow = mysql_fetch_array(mysql_query("select * from tbl_registration where id = '".$_SESSION[user_idd]."'"))
?>
<div class="container2">
<div class="container">
<div class="content">
<div class="heading">
<h1>Billing Info</h1>
</div>


<form action="" method="post" enctype="multipart/form-data" name="frmship" id="frmship" onSubmit="return Chck_Order()" style="margin:auto; height:auto">
<input type="hidden" name="command" />
<div>
        
        
        <div class="txt8"><?php if($_REQUEST['er']==1) { echo "Not A Valid Code"; } ?></div>
        <div class="row">
        
        
        
      <div class="col-md-6 text-left">
      <h2>Shipping Address</h2>
      
      <hr />
      
      
      <div class="row">
      <div class="col-md-6 f-user">
      <input name="Nname" type="text" class="txtfield-f" id="Nname" value="<?php echo $loguserRow[Nname]; ?>" placeholder="Full Name" required/></div>
      
      <div class="col-md-6 f-email">
      <input name="email" type="email" class="txtfield-f" id="email" value="<?php echo $loguserRow[email]; ?>" placeholder="Email ID" required/></div>
      
      <div class="col-md-6 f-mobile">
      <input name="NPhone1" type="tel" pattern="\d{10}" class="txtfield-f" id="NPhone1" value="<?php echo $loguserRow[NPhone1]; ?>" placeholder="Contact No." size="27" maxlength="10" required/></div>
      
      <div class="col-md-6 f-map">
      <input name="Ncity" type="text" class="txtfield-f" id="Ncity" placeholder="City" value="<?php echo $loguserRow[Ncity]; ?>" required/></div>
      
      <div class="col-md-12 f-map">
      <textarea name="Naddress1" placeholder="Enter Your Address" cols="14" rows="2" class="txtarea_f" required><?php echo $loguserRow[Naddress1]; ?></textarea>
      
        <?php /*?> 
		<input name="NState" type="text" class="txtfield-f" id="NState" placeholder="State" value="<?php echo (empty($OArray['state'])) ? '' : $OArray['state']; ?>" />
		<?php */?>
      </div>
      
      <div class="col-md-6 f-pin">
      <input name="NZipcode" type="tel" pattern="\d{6}" class="txtfield-f" id="NZipcode" placeholder="Postal Code" value="<?php echo $loguserRow[NZipcode]; ?>" maxlength="6" required/>
      </div>
      <div class="col-md-6 f-globe">
      <input type="text" name="NCountry" id="NCountry" value="<?php echo $loguserRow[NCountry]; ?>" placeholder="Country" required/>
      </div>
      
      <div class="col-md-12 f-message">
      <textarea name="NComments" placeholder="Enter Your Comments" cols="14" rows="2" class="txtarea_f"  ></textarea>
      </div>
      
      </div>      
<!--
<h2>Billing Address</h2>
<hr />
 <input type="checkbox" name="samechk" id="samechk" value="1" onclick="Billaddress()" checked="checked"/> Same As Shipping  
 
 <div class="row" id="billingaddDiv" style="display:none;">
 
 <div class="col-md-6">
 <input name="Bname" type="text" class="txtfield-f" id="Bname" value="<?php echo $loguserRow[Bname]; ?>" placeholder="Full Name" /></div>
 
 <div class="col-md-6">
 <input name="Bemail" type="email" class="txtfield-f" id="Bemail" value="<?php echo $loguserRow[Bemail]; ?>" placeholder="Email ID" />
 </div>
 
  <div class="col-md-6">
  <input name="BPhone1" type="tel" pattern="\d{10}" class="txtfield-f" id="BPhone1" value="<?php echo $loguserRow[BPhone1]; ?>" placeholder="Contact No." size="27" maxlength="10" />
  </div>
  
 <div class="col-md-6"><input name="Bcity" type="text" class="txtfield-f" id="Bcity" placeholder="City" value="<?php echo $loguserRow[Bcity]; ?>"/></div>
 
 <div class="col-md-12"><textarea name="Baddress1" id="Baddress1" placeholder="Enter Your Address" cols="14" rows="2" class="txtarea_f"><?php echo $loguserRow[Baddress1]; ?></textarea>
 <?php /*?><input name="NState" type="text" class="txtfield-f" id="NState" placeholder="State" value="<?php echo (empty($OArray['state'])) ? '' : $OArray['state']; ?>" /><?php */?>
 </div>
 
 <div class="col-md-6"><input name="Bzipcode" type="tel" pattern="\d{6}" class="txtfield-f" id="Bzipcode" placeholder="Postal Code" value="<?php echo $loguserRow[Bzipcode]; ?>" maxlength="6" /></div>
 
 <div class="col-md-6"><input type="text" name="BCountry" id="BCountry" value="<?php echo $loguserRow[BCountry]; ?>" placeholder="Country" /></div>
 
 
 <div class="col-md-12"><textarea name="BComments" placeholder="Enter Your Comments" cols="14" rows="2" class="txtarea_f"  ></textarea></div>
 

 
 </div>
 
    -->  
        
        </div>
        
        
        
        
        <div class="col-md-6">
        <h2>Order Summary</h2>
        <hr />
        <div class="box1">        
        <table width="100%" border="0" cellspacing="10" cellpadding="0">
      <tr>
        <td colspan="2" style="color:#000000;">
        </td>
        </tr>
<tr>
        <td><h4>Product Name</h4></td>
        <td align="right"><h4>Price</h4></td>
</tr>        
    <?php 
	 $query="select * from orders where orderid='".$_SESSION["shoporderid"]."' and waitstatus !=1";
	 $result=mysql_query($query); 

		while($result_rec=mysql_fetch_array($result)){	
		$itemsid=$result_rec['itemsid'];
		$id=$result_rec['id'];							
		$quantity=$result_rec['quantity'];
 			$sqlitems ="select * from tbl_products where id='".$itemsid."'";
			$itemsresult=mysql_query($sqlitems);
			$itemRows=mysql_fetch_array($itemsresult);
	  ?>
      
      <tr>
        <td><h5><?php echo $itemRows[productname]; ?></h5></td>
        <td align="right" style="color:#000000;"><i class="fa fa-inr"></i> 
<?php
$pricerateid = getPriceRateIdByPidOrdId($itemsid,$result_rec[orderid],$result_rec[bulkorder]);
 echo number_format(get_price($itemsid,$pricerateid,$result_rec[bulkorder]), 0, '.', '');?>
     
        
        &nbsp;
        (<?php 
	$queryorddet=mysql_fetch_array(mysql_query("select * from order_detail where orderid='".$_SESSION["shoporderid"]."' and productid ='".$result_rec[itemsid]."'"));				
    echo $queryorddet['quantity'];		
		 ?>)
        </td>
      </tr>
      <? }?>
      
      <tr>
      <td colspan="2"><hr /></td>
      </tr>
      
      <tr>
        
        <td><h5>Sub Total</h5></td>
        <td align="right"><h5>
          <label> <i class="fa fa-inr"></i> 
            <?=get_order_total()?>
            </label>
          </h5>
          <label><!--<input name="textfield" type="text" class="txtfield" id="textfield" value="" />-->
            </label>
          </td>
      </tr> 
	  <tr> <td><h5>Flat 20% off</h5></td>
        <td align="right"><h5>
          <label> -&nbsp;&nbsp;<i class="fa fa-inr"></i> 
            <? echo $total_off;?>
            </label>
          </h5>
          <label><!--<input name="textfield" type="text" class="txtfield" id="textfield" value="" />-->
            </label>
          </td>
      </tr>
	  <tr> <td><h5>GST 5%</h5></td>
        <td align="right"><h5>
          <label> +&nbsp;&nbsp;<i class="fa fa-inr"></i> 
            <? echo $gst_amount;?>
            </label>
          </h5>
          <label><!--<input name="textfield" type="text" class="txtfield" id="textfield" value="" />-->
            </label>
          </td>
      </tr> 
        
		<tr>
      <td colspan="2"><hr /></td>
      </tr>
		<tr>
        <td><h5>Grand Total</h5></td>
        <td align="right"><h5>
          <label> <i class="fa fa-inr"></i> 
            <? echo $get_order_total_grand; ?>
            </label>
          </h5>
          <label><!--<input name="textfield" type="text" class="txtfield" id="textfield" value="" />-->
            </label>
          </td>
      </tr>
      <tr>
		<td class="txt2"><h3>Payment Method</h3></td>
		<td align="right">
        <h4>
		<label><input required type="radio" name="payment_method" value="cod" checked="checked" />
		Cash On Delivery
		</label>
		<label><input type="radio" name="payment_method" value="instamojo" />
		Online
		</label>
        </h4>
        <!--
		<label><input type="radio" name="payment_method" value="payumoney" />
		PayUMoney
		</label>-->
        </td>
	  </tr>
      <tr>
        <td colspan="2">
        <hr />
          <!--    <input   type="submit"   value="Continue to Pay" style="width:170px; height:36px; color:#fff; font-family:'Futura Bk'; font-size:16px; margin-top:3px; margin-bottom:3px; background:#000; padding:1px 5px 5px 5px; letter-spacing:1px;" />-->
          <input name="btn" type="submit" id="btn" value="Confirm Order" class="btn1 pull-right" />
          <input name="SendOrder" type="hidden" id="SendOrder" value="1"></td>
      </tr>
      </table>
        </div>
        
        
        
        </div>
        
        
        



</div>
	</div>
</form>

<!------------------------------------------------------------->

<div class="clear"></div>
</div>
</div>
</div>


<?php include("footer.php");?>
</body>
</html>
 <script language="javascript">
function Billaddress()
 {
    if (document.getElementById('samechk').checked) {
	
document.getElementById('billingaddDiv').style.display = "none";
 
 document.frmship.Bname.value = document.frmship.Nname.value;
 document.frmship.Bemail.value = document.frmship.email.value;
 document.frmship.Baddress1.value = document.frmship.Naddress1.value;
 document.frmship.Bcity.value = document.frmship.Ncity.value;
 document.frmship.Bzipcode.value = document.frmship.NZipcode.value;
 document.frmship.BPhone1.value = document.frmship.NPhone1.value;
 document.frmship.BCountry.value = document.frmship.NCountry.value;
 
 document.getElementById("Bname").required = false;
 document.getElementById("Bemail").required = false;
 document.getElementById("Baddress1").required = false;
 document.getElementById("Bcity").required = false;
 document.getElementById("Bzipcode").required = false;
 document.getElementById("BPhone1").required = false;
 document.getElementById("BCountry").required = false;
 document.getElementById("BComments").required = false;
  
         } else {
		
document.getElementById('billingaddDiv').style.display = "block";
 document.getElementById("Bname").required = true;
 document.getElementById("Bemail").required = true;
 document.getElementById("Baddress1").required = true;
 document.getElementById("Bcity").required = true;
 document.getElementById("Bzipcode").required = true;
 document.getElementById("BPhone1").required = true;
 document.getElementById("BCountry").required = true;
 document.getElementById("BComments").required = true;
            //alert("You didn't check it! Let me check it for you.");
        }
  }
</script> 
