<?php
ob_start();
@session_start();
include("include/connect.php");
include("include/function.php");
?>
<?php $result_seo=mysql_fetch_array(mysql_query("select * from contents where id='7'"));?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title><?php echo stripslashes($result_seo['title_tag']); ?></title>
<meta name="description" content="<?php echo stripslashes($result_seo['description_tag']); ?>" />
<meta name="keywords" content="<?php echo stripslashes($result_seo['meta_tag']); ?>" />

<link rel="shortcut icon" type="image/x-icon" href="<?=$rootpath?>/images/favicon.png" />




<link href="<?=$rootpath?>/css/style.css" rel="stylesheet" type="text/css" />
<link href="<?=$rootpath?>/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />


<script type="text/javascript" src="<?=$rootpath?>/menu/js/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" media="all" href="<?=$rootpath?>/menu/css/webslidemenu.css" />
<script type="text/javascript" src="<?=$rootpath?>/menu/js/webslidemenu.js"></script>
<link rel="stylesheet" type="text/css" href="<?=$rootpath?>/menu/font-awesome/css/font-awesome.min.css" />
</head>
<body>


<?php include("header.php");?>


<div class="container">
<div>
<?php
	if($_REQUEST['commandBulk']=='Bulk'){
		$catidBulk=$_REQUEST['categoryBulk'];
		$productidBulk = $_REQUEST['productidBulk'];
		header("location:".$rootpath."/shoppingcart");
		exit();
	} ?>
<script language="javascript">
function sendToBulkPrductDetail(catid,catpid){
	document.frmproductbulk.commandBulk.value='Bulk';
	document.frmproductbulk.categoryBulk.value=catid;
	document.frmproductbulk.productidBulk.value=catpid;
	document.frmproductbulk.action = '<?=$rootpath?>/'+catid+'/'+catpid;
	document.frmproductbulk.submit();
}
</script> 

<form name="frmproductbulk" id="frmproductbulk" method="post" action="">
<input type="hidden" name="hiddproductidBulk" id="hiddproductidBulk" value="" />
	<input type="hidden" name="categoryBulk" id="categoryBulk"/>
	<input type="hidden" name="productidBulk" id="productidBulk"/>
    <input type="hidden" name="commandBulk" id="commandBulk"/>
</form>    

<!------------------------  Content Start   ---------------------------->
<?php
$pageRow = mysql_fetch_array(mysql_query("select * from contents where id ='7'")); 
?>

<h1><?php echo stripslashes($pageRow['heading']); ?></h1>

<?php echo restoreTags(stripslashes($pageRow['description'])); ?>

<!------------------------  Content End   ---------------------------->


<p>&nbsp;</p>
<p>&nbsp;</p>
<div class="container2"><h1>View Products</h1></div>

<?php
$cntt = 0;
$productCategoryList =getProductCategoryList();
if(count($productCategoryList)>0) {
foreach($productCategoryList as $productCategoryListData) {
	//if(getProductCountByCatId($productCategoryListData['id'])>0) {
	if(getProductCountByCatIdForBulk($productCategoryListData['id'])>0) {
?>  

        
          <div class="grid_4 <?php if($cntt=='2') { ?> omega <?php } ?>">
          
          <h2><a href="#"><?php echo $productCategoryListData['name']; ?></a></h2>
          <ul class="list1">
                    
<?php
$allProductListByCatId = getAllProductListByCatId($productCategoryListData['id']);
foreach($allProductListByCatId as $allProductListByCatIdData) {
?>          
          	<li><a href="javascript:void(0);" onClick="sendToBulkPrductDetail('<?php echo $productCategoryListData['urlname']; ?>','<?php echo $allProductListByCatIdData['urlname']; ?>')"><?php echo $allProductListByCatIdData['productname']; ?></a></li>
<?php } ?> 
 
          </ul>    
          </div>
          
          
<?php if($cntt=='2') { ?>
	<div class="clear"></div>
<?php 
$cntt=0; } ?>          
          
          
<?php $cntt++; } ?>          
<?php } ?>         
<?php } ?>


<div class="clear"></div>
</div>
</div>


<?php include("footer.php");?>
</body>
</html>
