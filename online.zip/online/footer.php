<div class="footer2">
<div class="container">

<div class="text-center">
<img src="<?php echo $rootpath; ?>/images/logo-footer.png" alt="delivery kings" />
<div>
  <ul>
<li><a href="<?php echo $rootpath; ?>/">Home</a></li>
  <li><a href="<?php echo $rootpath; ?>/privacy-policy">Privacy Policy</a></li>
  <li><a href="<?php echo $rootpath; ?>/return-policy">Refund Policy</a></li>
  <li><a href="<?php echo $rootpath; ?>/terms">Terms and Conditions</a></li>
  <li><a href="<?php echo $rootpath; ?>/contactus">Contact us</a></li>
</ul>
</div>



<div class="hidden-sm hidden-xs">
<div class="f-nav2">
<ul>
<?php
$productCategoryList =getProductCategoryList();
if(count($productCategoryList)>0) {
foreach($productCategoryList as $productCategoryListData) {
if(getProductCountByCatId($productCategoryListData['id'])>0) {
?>          
<li><a href="<?=$rootpath?>/astro-<?php echo $productCategoryListData['urlname'];?>"><?php echo $productCategoryListData['name']; ?></a></li>          
<?php } ?>          
<?php } ?>         
<?php } ?>
</ul>

<div class="clear"></div>

<h6><i class="fa fa-envelope-o" aria-hidden="true"></i> <?php echo stripslashes($contactRow['email']); ?> | <i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo stripslashes($contactRow['business_hr']); ?></h6>

</div>
</div>




</div>




<div class="row">
<div class="col-md-8">
<div class="row">
<div class="col-md-6">
<div class="call">
<i class="fa fa-volume-control-phone"></i>
<h5>Call us Today</h5>
<a href="tel://<?php echo $contactRow['phone']; ?>"><?php echo $contactRow['phone']; ?></a>
</div>
</div>




<div class="col-md-6">
<p>&nbsp;</p>

<div class="social">
<ul>
<?php if(getSocialLinkById(1)!="") { ?>
<li>
<a href="<?php if(getSocialLinkById(1)!="") { echo getSocialLinkById(1); } else { echo "#"; } ?>" target="_blank"><i class="fa fa-facebook" aria-hidden="true"  style="background-color:#3b5999"></i></a>
</li>
<?php } ?>

<?php if(getSocialLinkById(3)!="") { ?>
<li>
<a href="<?php if(getSocialLinkById(3)!="") { echo getSocialLinkById(3); } else { echo "#"; } ?>" target="_blank"><i class="fa fa-twitter" aria-hidden="true" style="background-color:#55acef"></i></a>
</li>
<?php } ?> 

<?php if(getSocialLinkById(2)!="") { ?>
<li>
<a href="<?php if(getSocialLinkById(2)!="") { echo getSocialLinkById(2); } else { echo "#"; } ?>" target="_blank"><i class="fa fa-google-plus" aria-hidden="true"  style="background-color:#de4b39"></i></a>
</li>
<?php } ?>

<?php if(getSocialLinkById(4)!="") { ?>
<li>
<a href="<?php if(getSocialLinkById(4)!="") { echo getSocialLinkById(4); } else { echo "#"; } ?>" target="_blank"><i class="fa fa-instagram" aria-hidden="true"  style="background-color:#007bb6"></i></a>
</li>
<?php } ?>

<?php if(getSocialLinkById(5)!="") { ?>
<li>
<a href="<?php if(getSocialLinkById(5)!="") { echo getSocialLinkById(5); } else { echo "#"; } ?>" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
</li>
<?php } ?>


<?php if(getSocialLinkById(6)!="") { ?>
<li>
<a href="<?php if(getSocialLinkById(6)!="") { echo getSocialLinkById(6); } else { echo "#"; } ?>" target="_blank"><i class="fa fa-pinterest" aria-hidden="true"></i></a>
</li>
<?php } ?>

<?php if(getSocialLinkById(7)!="") { ?>
<li>
<a href="<?php if(getSocialLinkById(7)!="") { echo getSocialLinkById(7); } else { echo "#"; } ?>" target="_blank"><i class="fa fa-tumblr" aria-hidden="true"></i></a>
</li>
<?php } ?>

<?php if(getSocialLinkById(8)!="") { ?>
<li>
<a href="<?php if(getSocialLinkById(8)!="") { echo getSocialLinkById(8); } else { echo "#"; } ?>" target="_blank"><i class="fa fa-youtube" aria-hidden="true"></i></a>
</li>
<?php } ?>


<?php if(getSocialLinkById(9)!="") { ?>
<li><a href="<?php if(getSocialLinkById(9)!="") { echo getSocialLinkById(9); } else { echo "#"; } ?>" target="_blank"><i class="fa fa-foursquare" aria-hidden="true"></i>
</a></li>
<?php } ?>

</ul>
</div>




</div>
</div>







</div>


<div class="col-md-4">


<img src="<?php echo $rootpath; ?>/images/icon-payment.png" alt="Payment" class="img-responsive" />

</div>










</div>
</div>

   

<footer>
<div class="container text-center">
Content © deliverykings.co.in | All rights reserved
</div>
</footer>
</div>