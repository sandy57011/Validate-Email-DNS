<?php  ob_start(); ?>
<?php @session_start(); ?>

<?php
error_reporting(0);
//ini_set('display_errors', true);
//error_reporting(E_ALL | E_STRICT);
date_default_timezone_set('Asia/Kolkata');
if($_SERVER['HTTP_HOST']=='localhost'){
	$hostname='localhost';
	$dbusername='root';
	$dbpassword='vertrigo';
	$database='delivery-kings';
}else{
	$hostname = 'localhost';
	$dbusername='delivery_deliver';
	$dbpassword='deliver123';
	$database='delivery_db';  
}
$pagetitle = "Delivery Kings";
$link=mysql_connect($hostname,$dbusername,$dbpassword);
mysql_select_db($database,$link);

$serverpath = "http://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
$rootpath = dirname($serverpath); 

 	if($_SESSION["shoporderid"]==""){
   	$_SESSION["shoporderid"]=mt_rand();  
  	}
?>


 