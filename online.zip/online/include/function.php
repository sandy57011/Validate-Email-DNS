<?php
 function generatePassword($length=9, $strength=8) {
	$vowels = 'aeiou';
	$consonants = 'bdghjmnpqrstvz';
	if ($strength & 1) {
		$consonants .= 'BDGHJLMNPQRSTVWXZ';
	}
	if ($strength & 2) {
		$vowels .= "AEIOU";
	}
	if ($strength & 4) {
		$consonants .= '0123456789';
	}
	if ($strength & 8) {
		$consonants .= '@#$%';
	}
 
	$password = '';
	$alt = time() % 2;
	for ($i = 0; $i < $length; $i++) {
		if ($alt == 1) {
			$password .= $consonants[(rand() % strlen($consonants))];
			$alt = 0;
		} else {
			$password .= $vowels[(rand() % strlen($vowels))];
			$alt = 1;
		}
	}
	return $password;
} 
//Function for login========================================================================================================

function LoginQuery($tablename, $field1, $value1, $field2, $value2)
{

	$Query = "select * from ".$tablename." where ".$field1." = '".$value1."' and ".$field2." = '".$value2."'";
	
	$Result= mysql_query($Query) or die(mysql_error());
	
	if(mysql_num_rows($Result)==0)
	{
	
		return 0;
	
	}
	else
	{
	
		return mysql_fetch_object($Result);
	
	}

}

//Function for login========================================================================================================

//Redirect if the user is not logged in=====================================================================================

function isLoggedIn(){

	if($_SESSION['UID']=="" and $_SESSION['username']==""){
			 
			echo "<script language=javascript>\nlocation.href='index.php?pageURL=Login&notLogged=1&redirect=http://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF']."?".$_SERVER['QUERY_STRING']."'</script>";
			exit();
			
			/*echo "<script language=javascript>
					location.href='index.php?pageURL=Login&notLogged=1&redirect=http://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF']."?".$_SERVER['QUERY_STRING']."'</script>";
			exit();	*/	
		}

 	}

//Redirect if the user is not logged in=====================================================================================

function LoggedInYes(){

 	if($_SESSION['conflogin']=='OK' or $_SESSION['clogin']=='OK')
	{
echo "<script language=javascript>alert(\"You are already logged in, logout to register/login to the site\");\nlocation.href='index.php'</script>";

		}

	}


//File Uploading============================================================================================================

function UploadFiles($filename, $tempname, $uploaddir){
	
 	$rand		= substr(md5(substr(mt_rand(100000,999999),1,3)),0,10);
 	$file 		= $rand.$filename;
 	$filepath 	= $uploaddir.$file;	 
	
 	if(move_uploaded_file($tempname,$filepath)){

 		return $file;
 	}else{
 		return "";
 	}
}

 
//Deletion of file==========================================================================================================

	function DeleteFile($filename,$directory){
		if($filename and file_exists($directory.$filename)) unlink($directory.$filename);
	
	}

 //Delete the record from a table============================================================================================

function deleteQuery($tblname,$field,$value){
	 
	mysql_query("delete from $tblname where $field = '$value'") or die(mysql_error());

}

 
//Check if administrator is logged in========================================================================================
function checkLoginadmin()
{	if ($_SESSION['admin']!="yes")
	{
		header("location: login.php");
	}
}

////////////////finding event any particular date//////
function countnumber($tablename, $field1,$value1,$field2='',$value2=''){

	$Query = "select count(*) as totalrec from ".$tablename." where ".$field1." = '".$value1."'";
  
	$Result			= mysql_query($Query) or die(mysql_error());
	
	$TotalRecords	= mysql_result($Result,0);
	 
	return 	$TotalRecords;
}


/////////////////////////////////////////////////////////////////

//Function to populate country in a list box===================================================================================

function PopulateCountry($PostCon){

	//echo "\n<select name=\"country\" onchange = \"javascript:showhidestate(this.value);\">\n";
	echo "\n<select name=\"country\">\n";
	
    echo "<option value=\"\">Country</option>\n";
	
	$query = "select * from countrylist order by cname";
	
	$result= mysql_query($query) or die(mysql_error());
	
	while($resrec=mysql_fetch_object($result)){
			if($PostCon==$resrec->cname){
				echo " <option value=\"$resrec->cname\" selected>".$resrec->cname."</option>\n";
				}
				else
				{
				echo "          <option value=\"$resrec->cname\">".$resrec->cname."</option>\n";
		      	}
	}	
    echo "</select>";   
    }

//Function to populate country in a list box===================================================================================
//Function to populate state in a list box=====================================================================================
function PopulateState($PostState){
	echo "\n<select name=\"state\" onchange=\"javascript:showhide(this.value)\">\n";
	/*if($PostState){
	echo "\n<select name=\"state\" id=\"state\">\n";	
	}else{
	
	echo "\n<select name=\"state\" id=\"state\" style=\"visibility:hidden; display:none\">\n";
	
	}*/
    echo "          <option value=\"\">State</option>\n";
	
	$query = "select * from db164448300_state order by full_name";
	
	$result= mysql_query($query) or die(mysql_error());
	
	while($resrec=mysql_fetch_object($result)){
	
		if($PostState==$resrec->full_name){
			$GLOBALS[sel] = 1;
			echo "          <option value=\"$resrec->full_name\" selected>".$resrec->full_name."</option>\n";
		
		}else{
			
			echo "          <option value=\"$resrec->full_name\">".$resrec->full_name."</option>\n";
			
		}

	}
	
	/*if($GLOBALS[sel]!=1 and !empty($PostState)){
		echo "          <option value=\"Other\" selected>Other</option>\n";
	}else{
		echo "          <option value=\"Other\" >Other</option>\n";
	}*/
    echo "</select>";   
	
}

//Function to populate state in a list box======================================================================================
//Populate number of hour in hour drop down======================================================

function PopulateHour($hr){

	echo "			<option value=\"\" selected>HH</option>\n";
	
	for($i=1;$i<=12;$i++){
		
		$hrs = sprintf("%02d",$i);
		
		if($hr==$i){
			
			echo "          <option value=\"$hrs\" selected>".$hrs."</option>\n";
		
		}else{
		
			echo "          <option value=\"$hrs\">".$hrs."</option>\n";
			
		}

	}	      

}

//Populate number of hour in hour drop down======================================================

//Populate number of minutes in minute drop down======================================================

function PopulateMinute($min){
	echo "			<option value=\"\" selected>MM</option>\n";
	for($i=0;$i<60;$i++){
		
		$mins = sprintf("%02d",$i);
		if($min==$i){
			
			echo "          <option value=\"$mins\" selected>".$mins."</option>\n";
		
		}else{
		
			echo "          <option value=\"$mins\">".$mins."</option>\n";
			
		}

	}	      

}

//Populate number of minutes in minute drop down======================================================

//Function to check the existence of a username or email address in the table===============================================

function CheckExistance($tablename, $field, $value){

	$Query = "select * from ".$tablename." where ".$field." = '".$value."'";
	
	$Result= mysql_query($Query) or die(mysql_error());
	
	if(mysql_num_rows($Result)==0){
	
		return 0;
	
	}else{
	
		return mysql_fetch_object($Result);
	
	}

}
/*--------------------------------Show banner script------------------------------------*/

function showBanner($page,$loc,$w,$h)
{		
$Query = "select * from adbanner where ad_page='".$page."' and ad_pos='".$loc."' and status=1 order by rand() limit 1";
 //echo $Query;
$Result= mysql_query($Query ) or die(mysql_error());

$resrec=mysql_fetch_array($Result);
//print_r($resrec);
$show_banner='<a href="'.$resrec[ban_URL].'" target=_blank>';
//$show_banner='<a href="http://localhost//new_rental/siteadmin" target=_blank>';
if($resrec[ad_type]=="Image"){
$show_banner.='<img src="siteadmin/'.$resrec[ad_filename].'" width="'.$w.'" height="'.$h.'" border="0" />';
}elseif($resrec[ad_type]=="Flash"){

//$show_banner.='<embed src='http://ishare.rediff.com/images/player.swf'/>';

$show_banner.='<embed src="siteadmin/'.$resrec[ad_filename].'" width="'.$w.'" height="'.$h.'"  />';
}else{
$show_banner.=$resrec[ad_filename];
}

$show_banner.='</a>';
return $show_banner;
}
function limit_word($text, $limit, $link="") {
      if (str_word_count($text, 0) > $limit) {
          $words = str_word_count($text, 2);
          $pos = array_keys($words);
		  if($link!="") {
          $text = stripslashes(substr($text, 0, $pos[$limit])) . '... '.$link;
		  } else {
		  $text = stripslashes(substr($text, 0, $pos[$limit])) . '... ';
		  }
      }
      return $text;
    }
function limit_text_bywords($text, $limit) {
      if (str_word_count($text, 0) > $limit) {
          $words = str_word_count($text, 2);
          $pos = array_keys($words);
          $text = substr($text, 0, $pos[$limit]) . '...'.'<a href="#more">Read More</a>';
      }
      return $text;
    }
function restoreTags($input) { $opened = array();
	// loop through opened and closed tags in order 
	if(preg_match_all("/<(\/?[a-z]+)>?/i", $input, $matches)) 
		{ foreach($matches[1] as $tag) { 
			if(preg_match("/^[a-z]+$/i", $tag, $regs)) { 
	// a tag has been opened 
	if(strtolower($regs[0]) != 'br') $opened[] = $regs[0]; } elseif(preg_match("/^\/([a-z]+)$/i", $tag, $regs)) { 
	// a tag has been closed
	 unset($opened[array_pop(array_keys($opened, $regs[1]))]); } } } 
	 // close tags that are still open 
	 if($opened) { 
	 $tagstoclose = array_reverse($opened); foreach($tagstoclose as $tag) $input .= "</$tag>"; } 
	 return $input; 
	 }
	 
	 
	 function getTestimonialListLimit() {
	$query =mysql_query("select * from manage_testimonials where status = '1' order by id ASC limit 0,3") or die(mysql_error());
	while($data=mysql_fetch_array($query)){
		$result_data[] = $data;		
	}
	return $result_data;
}
function getTestimonialListWithoutLimit() {
	$query =mysql_query("select * from manage_testimonials where status = '1' order by id ASC") or die(mysql_error());
	while($data=mysql_fetch_array($query)){
		$result_data[] = $data;		
	}
	return $result_data;
}


function checkLoginuser()
{
if($_SESSION['loguid']=="")
	{
$url = "index.php";
 ?>
 <script>
 alert("Please login first or Register Yourself");
 location.href="<?=$url?>"
 </script>
 <?
	}
}	 
function getAboutUsNameNameById($id) {
	$sqlRes = mysql_query("select name from manage_aboutus where id = '".$id."'") or die(mysql_error());
	$sresult_rec=mysql_fetch_array($sqlRes);
	return $sresult_rec['name'];
}
function makeurlnamebyname($str) {
	$inputstring = trim(strip_tags($str));
	$lowertext = strtolower($inputstring);
	$lowertext = str_replace(" ", "-", $lowertext);
	$lowertext = str_replace("'", "", $lowertext);
	return $lowertext;
}
function makeurlnamebynameCategory($str) {
	$inputstring = trim(strip_tags($str));
	$lowertext = strtolower($inputstring);
	$lowertext = preg_replace('/[^A-Za-z0-9\-]/', '', $lowertext);
	$lowertext = str_replace(" ", "", $lowertext);
	$lowertext = str_replace("&", "and", $lowertext);
	$lowertext = str_replace("%", "percent", $lowertext);
	$lowertext = str_replace("--", "", $lowertext);
	$lowertext = str_replace("---", "", $lowertext);
	$lowertext = str_replace(" ", "", $lowertext);
	$lowertext = str_replace("'", "", $lowertext);
	return $lowertext;
}
function makeurlnamebynameProduct($str) {
	$inputstring = trim(strip_tags($str));
	$lowertext = strtolower($inputstring);
	$lowertext = str_replace("'", "", $lowertext);
	$lowertext = str_replace(" ", "-", $lowertext);
	$lowertext = str_replace("&", "and", $lowertext);
	$lowertext = str_replace("%", "percent", $lowertext);
	$lowertext = str_replace("--", " ", $lowertext);
	$lowertext = str_replace("---", " ", $lowertext);
	$lowertext = preg_replace('/[^A-Za-z0-9\-]/', '', $lowertext);
	return $lowertext;
}
function getPageContentUrlNameAvl($id) {
	$queryRes =mysql_query("select * from contents where urlname = '".$id."'");
	return mysql_num_rows($queryRes);
}
function checkFieldValueAvl($table,$field,$fieldval) {
	$queryRes =mysql_query("select * from $table where $field = '".$fieldval."'");
	return mysql_num_rows($queryRes);
}
function redirect($page)
{
	if(!headers_sent())
		header("location:$page");
	else
		echo "<script>location.href='$page'</script>";
}
function getSocialList() {
	$query =mysql_query("select * from social_link ") or die(mysql_error());
	while($data=mysql_fetch_array($query)){
		$result_data[] = $data;		
	}
	return $result_data;
}	 
function getSocialLinkById($id) {
	$sqlRes = mysql_query("select social_link from social_link where id = '".$id."'") or die(mysql_error());
	$sresult_rec=mysql_fetch_array($sqlRes);
	return $sresult_rec['social_link'];
}
function getProductCategorynameById($id) {
	 $res=mysql_query("select name from manage_productcategory where id = '".$id."'");
	 $result =mysql_fetch_array($res);
	 return $result['name'];
}
function getProductCategoryUrlnameById($id) {
	 $res=mysql_query("select urlname from manage_productcategory where id = '".$id."'");
	 $result =mysql_fetch_array($res);
	 return $result['urlname'];
}
function getPriceRateListByPId($id) {
	$query =mysql_query("select * from tbl_productprice_rate where p_id = '".$id."'") or die(mysql_error());
	while($data=mysql_fetch_array($query)){
		$result_data[] = $data;		
	}
	return $result_data;
}
function getPriceRateListByPIdBulk($id) {
	$query =mysql_query("select * from tbl_productprice_rateBulk where p_id = '".$id."'") or die(mysql_error());
	while($data=mysql_fetch_array($query)){
		$result_data[] = $data;		
	}
	return $result_data;
} 
function getGalImageByPrId($id) {
	$query =mysql_query("select * from tbl_product_galimage where p_id = '".$id."'") or die(mysql_error());
	while($data=mysql_fetch_array($query)){
		$result_data[] = $data;		
	}
	return $result_data;
}
function getPriceListByPrId($id) {
	$query =mysql_query("select * from tbl_productprice_rate where p_id = '".$id."'") or die(mysql_error());
	while($data=mysql_fetch_array($query)){
		$result_data[] = $data;		
	}
	return $result_data;
}
function getPriceListByPrIdBulk($id) {
	$query =mysql_query("select * from tbl_productprice_rateBulk where p_id = '".$id."'") or die(mysql_error());
	while($data=mysql_fetch_array($query)){
		$result_data[] = $data;		
	}
	return $result_data;
}
function getProductReviewList($id) {
	$query =mysql_query("select * from tbl_product_review where p_id = '".$id."' and status = '1'") or die(mysql_error());
	while($data=mysql_fetch_array($query)){
		$result_data[] = $data;		
	}
	return $result_data;
}
function getTotalReviewByProductId($id) {
	$sqlRes = mysql_query("select id from tbl_product_review where p_id = '".$id."' and status = '1'") or die(mysql_error());
	$sresult_rec=mysql_num_rows($sqlRes);
	return $sresult_rec;
}
function getTotalReviewCountByProductId($id) {
	$sqlRes = mysql_query("select SUM(rrating) as totsum from tbl_product_review where p_id = '".$id."' and status = '1'") or die(mysql_error());
	$sresult_rec=mysql_fetch_array($sqlRes);
	return $sresult_rec['totsum'];
}
function getProductCategoryList() {
	$query =mysql_query("select * from manage_productcategory order by id ASC") or die(mysql_error());
	while($data=mysql_fetch_array($query)){
		$result_data[] = $data;		
	}
	return $result_data;
}
function getProductCountByCatId($id) {
	$sqlRes = mysql_query("select id from tbl_products where cat_id = '".$id."' and status = '1' and product_type = '0'") or die(mysql_error());
	$sresult_rec=mysql_num_rows($sqlRes);
	return $sresult_rec;
}
function getProductCountByCatIdForBulk($id) {
	$sqlRes = mysql_query("select id from tbl_products where cat_id = '".$id."' and status = '1' and showinbulk = '1' order by productname ASC") or die(mysql_error());
	$sresult_rec=mysql_num_rows($sqlRes);
	return $sresult_rec;
}
function getAllProductListByCatId($id) {
	$query =mysql_query("select * from tbl_products where cat_id = '".$id."' and status = '1' and product_type = '0' order by productname ASC") or die(mysql_error());
	//$query =mysql_query("select * from tbl_products where cat_id = '".$id."' and status = '1' and showinbulk = '1' order by productname ASC") or die(mysql_error());
	while($data=mysql_fetch_array($query)){
		$result_data[] = $data;		
	}
	return $result_data;
}
function getHomeSliderList() {
	$query =mysql_query("select * from slider order by id ASC") or die(mysql_error());
	while($data=mysql_fetch_array($query)){
		$result_data[] = $data;		
	}
	return $result_data;
}
function getProductNameById($id) {
	 $res=mysql_query("select productname from tbl_products where id = '".$id."'");
	 $result =mysql_fetch_array($res);
	 return $result['productname'];
}
function getProductUrlNameById($id) {
	 $res=mysql_query("select urlname from tbl_products where id = '".$id."'");
	 $result =mysql_fetch_array($res);
	 return $result['urlname'];
}
function getProductLogoNameById($id) {
	 $res=mysql_query("select logoimg from tbl_products where id = '".$id."'");
	 $result =mysql_fetch_array($res);
	 return $result['logoimg'];
}
function getGiftProductList() {
	$query =mysql_query("select * from tbl_products where status = '1' and product_type = '2'") or die(mysql_error());
	while($data=mysql_fetch_array($query)){
		$result_data[] = $data;		
	}
	return $result_data;
}
function getAllBlogList() {
	$query =mysql_query("select * from manage_blog where status = '1' order by add_date DESC") or die(mysql_error());
	while($data=mysql_fetch_array($query)){
		$result_data[] = $data;		
	}
	return $result_data;
}
function getFivePointList() {
	$query =mysql_query("select * from tbl_fivepoint where status = '1' order by id DESC") or die(mysql_error());
	while($data=mysql_fetch_array($query)){
		$result_data[] = $data;		
	}
	return $result_data;
}
function getFivePointIconsListById($id) {
	$query =mysql_query("select * from tbl_fivepointicons where p_id = '".$id."'") or die(mysql_error());
	while($data=mysql_fetch_array($query)){
		$result_data[] = $data;		
	}
	return $result_data;

}
function getExpertTeaTasterList() {
	$query =mysql_query("select * from manage_experttea where status = '1' order by id DESC") or die(mysql_error());
	while($data=mysql_fetch_array($query)){
		$result_data[] = $data;		
	}
	return $result_data;
}
function getTeamList() {
	$query =mysql_query("select * from manage_team where status = '1' order by id DESC") or die(mysql_error());
	while($data=mysql_fetch_array($query)){
		$result_data[] = $data;		
	}
	return $result_data;
}
function getCertificationsList() {
	$query =mysql_query("select * from manage_certification where status = '1' order by id DESC") or die(mysql_error());
	while($data=mysql_fetch_array($query)){
		$result_data[] = $data;		
	}
	return $result_data;
}
function getCertificationsListByPid($id) {
	$query =mysql_query("select * from tbl_product_certificationimage where p_id = '".$id."' order by id DESC") or die(mysql_error());
	while($data=mysql_fetch_array($query)){
		$result_data[] = $data;		
	}
	return $result_data;
}
function getReturnList() {
	$query =mysql_query("select * from manage_return where status = '1' order by id DESC") or die(mysql_error());
	while($data=mysql_fetch_array($query)){
		$result_data[] = $data;		
	}
	return $result_data;
}
function getReturnListAsc() {
	$query =mysql_query("select * from manage_return where status = '1' order by id ASC") or die(mysql_error());
	while($data=mysql_fetch_array($query)){
		$result_data[] = $data;		
	}
	return $result_data;
}
function getFaqList() {
	$query =mysql_query("select * from manage_faq where status = '1' order by id DESC") or die(mysql_error());
	while($data=mysql_fetch_array($query)){
		$result_data[] = $data;		
	}
	return $result_data;
}
function getFaqListASC() {
	$query =mysql_query("select * from manage_faq where status = '1' order by id ASC") or die(mysql_error());
	while($data=mysql_fetch_array($query)){
		$result_data[] = $data;		
	}
	return $result_data;
}
function getNewArrivalProductList() {
	$query =mysql_query("select * from tbl_products where newarrival = '1' and status = '1'  order by add_date DESC limit 0,8") or die(mysql_error());
	while($data=mysql_fetch_array($query)){
		$result_data[] = $data;		
	}
	return $result_data;
}
function getNewArrivalProductList_filter($veg_filter_cat) {
	if($veg_filter_cat == 'veg'){
		$non_veg = 'and non_veg = 0';
	}else if($veg_filter_cat == 'non_veg'){
		$non_veg = 'and non_veg = 1';
	}else{
		$non_veg = '';
	}
	$query =mysql_query("select * from tbl_products where newarrival = '1' and status = '1' and product_type = '0' ".$non_veg." order by add_date DESC limit 0,8") or die(mysql_error());
	while($data=mysql_fetch_array($query)){
		$result_data[] = $data;		
	}
	return $result_data;
}
function getSearchProductList($keyword) {
	$query =mysql_query("select * from tbl_products where productname like '%".$keyword."%' and status = '1' limit 0,5") or die(mysql_error());
	while($data=mysql_fetch_array($query)){
		$result_data[] = $data;		
	}
	return $result_data;
}
function getRegUserEmailNameById($id) {
	 $res=mysql_query("select uemail from tbl_registration where id = '".$id."'");
	 $result =mysql_fetch_array($res);
	 return $result['uemail'];
}
function getUsernameByUid($id) {
	 $res=mysql_query("select uname from tbl_registration where id = '".$id."'");
	 $result =mysql_fetch_array($res);
	 return $result['uname'];
}
function getAboutMeByUid($id) {
	 $res=mysql_query("select ruseraboutme from tbl_registration where id = '".$id."'");
	 $result =mysql_fetch_array($res);
	 return $result['ruseraboutme'];
}
function getProductHistoryReviewListByUid($id) {
	$query =mysql_query("select * from tbl_product_reviewhistory where u_id = '".$_SESSION['user_idd']."' order by id DESC") or die(mysql_error());
	while($data=mysql_fetch_array($query)){
		$result_data[] = $data;		
	}
	return $result_data;
}
function getPartnersList() {
	$query =mysql_query("select * from manage_partners where status = '1' order by id DESC") or die(mysql_error());
	while($data=mysql_fetch_array($query)){
		$result_data[] = $data;		
	}
	return $result_data;
}
function getTestimonialList() {
	$query =mysql_query("select * from manage_testimonials where status = '1' order by id DESC") or die(mysql_error());
	while($data=mysql_fetch_array($query)){
		$result_data[] = $data;		
	}
	return $result_data;
}
function getPriceRateIdByPidOrdId($pid,$ordid,$bulkid) {
if($bulkid=='0') {
	 $res=mysql_query("select pricerate_id from order_detail where orderid = '".$ordid."' and productid = '".$pid."'");
}
if($bulkid=='1') {
	$res=mysql_query("select pricerate_id from order_detail where orderid = '".$ordid."' and productid = '".$pid."'");
}	 
	 $result =mysql_fetch_array($res);
	 return $result['pricerate_id'];	
}
function getPriceNameByPidBulkId($rateid,$bulkid,$pid) {
if($rateid=='0') {
$resRow=mysql_fetch_array(mysql_query("select productpricedescr from tbl_products where id = '".$pid."'"));
return $resRow['productpricedescr'];
}
if($rateid>0) {
if($bulkid=='0') {
	 $res=mysql_query("select price_name from tbl_productprice_rate where id = '".$rateid."'");
}
if($bulkid=='1') {
	$res=mysql_query("select price_name from tbl_productprice_rateBulk where id = '".$rateid."'");
}
 	 $result =mysql_fetch_array($res);
	 return $result['price_name'];
}	 
	
}
function getquantityByOrdIdPid($oid,$itmid) {
$res=mysql_query("select quantity from order_detail where orderid = '".$oid."' and productid = '".$itmid."'");
	 $result =mysql_fetch_array($res);
	 return $result['quantity'];
}
function getUserNameByMemidOrdId($mid,$oid) {
	$res=mysql_query("select delivery_cust_name from orders where memid = '".$mid."' and orderid = '".$oid."'");
	 $result =mysql_fetch_array($res);
	 return $result['delivery_cust_name'];
}
function getRegUserNameByMemidOrdId($mid,$oid) {
	$res=mysql_query("select reguserid from orders where memid = '".$mid."' and orderid = '".$oid."'");
	 $result =mysql_fetch_array($res);
	 return $result['reguserid'];
}
function getProductTypeTypeByPId($id) {
	$res=mysql_query("select p_ids from tbl_products where id = '".$id."'");
	 $result =mysql_fetch_array($res);
	 return $result['p_ids'];
}
function getcontentList() {
	$query =mysql_query("select * from contents order by id") or die(mysql_error());
	while($data=mysql_fetch_array($query)){
		$result_data[] = $data;		
	}
	return $result_data;
}
function getproductlinkList() {
	$query =mysql_query("select * from manage_productcategory order by id") or die(mysql_error());
	while($data=mysql_fetch_array($query)){
		$result_data[] = $data;		
	}
	return $result_data;
}
function getsubproductList() {
	$query =mysql_query("select * from tbl_products order by id") or die(mysql_error());
	while($data=mysql_fetch_array($query)){
		$result_data[] = $data;		
	}
	return $result_data;
}


function getProjectIdByUrlName($id) {
	$Row =mysql_fetch_array(mysql_query("select id from tbl_project where urlName = '".$id."'"));
	return $Row[id];
}
function getProjectSubcategoryIdByUrlName($id) {
	$Row =mysql_fetch_array(mysql_query("select id from tbl_projectsubcategory where urlName = '".$id."'"));
	return $Row[id];
}
function getProjectHeadingList() {
	$query =mysql_query("select * from tbl_project order by id ASC") or die(mysql_error());
	while($data=mysql_fetch_array($query)){
		$result_data[] = $data;		
	}
	return $result_data;
}
function getProjectSubcategoryListById($id) {
	$query =mysql_query("select * from tbl_projectsubcategory where pid = '".$id."' order by id ASC") or die(mysql_error());
	while($data=mysql_fetch_array($query)){
		$result_data[] = $data;		
	}
	return $result_data;
}
function getProjectSubcategoryListByIdAll() {
	$query =mysql_query("select * from tbl_projectsubcategory order by id DESC") or die(mysql_error());
	while($data=mysql_fetch_array($query)){
		$result_data[] = $data;		
	}
	return $result_data;
}
function generateUniqueIdRand($tblname,$fieldname,$fileexten) {
$charactersM = 9;
$possibleM = '0123456789';

		$codeM = '';

		$i = 0;

		while ($i < $charactersM) { 

			$codeM .= substr($possibleM, mt_rand(0, strlen($possibleM)-1), 1);

			$i++;

		}

	$ranStrM = $codeM;
	$ranStrM .=".".$fileexten;	
	$queryRes =mysql_query("select * from $tblname where $fieldname = '".$ranStrM."'") or die(mysql_error());
	$foundRes = mysql_num_rows($queryRes);
	if($foundRes>0) {
	generateUniqueIdRand($tblname,$fieldname,$fileexten);
	} else {	
return $ranStrM;
}
}
function get_question_text($q_id = 0)
{
	if($q_id){
		$resp = mysql_fetch_array(mysql_query("select * from tbl_rmquestions where id = '".$q_id."'"));
		return $resp['text'];
	}else{
		return false;
	}
}
function get_payment_data_payumoney($orderid = 0)
{
	$resp = mysql_fetch_array(mysql_query("select * from orders where orderid = '".$orderid."'"));
	return array('payment_method' => $resp['payment_method'],'payment_status' => $resp['payment_status']);
}
function get_ramalcurrent_price()
{
	$resp = mysql_fetch_array(mysql_query("select * from tbl_rmsetting where setting_id = '1'"));
	return $resp['setting_value'];
}


?>  
