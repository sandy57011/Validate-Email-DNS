<?php
ob_start();
@session_start();
include("include/connect.php");
include("include/function.php");
?>
<?php
if(isset($_REQUEST['Submit']) && $_REQUEST['Submit'] == "Login") {
$ruserid = $_POST['rruserid'];
$rpassword = $_POST['rrpassword']; 
$_SESSION['errorses'] = "";
unset($_SESSION['errorses']);
echo "select * from tbl_registration where uemail = '".$ruserid."' and mdupass = '".md5($rpassword)."'";
$cheklogUserResR = mysql_query("select * from tbl_registration where uemail = '".$ruserid."' and mdupass = '".md5($rpassword)."'");
$checkcountR = mysql_num_rows($cheklogUserResR);
if($checkcountR>0) {
 $checkcountRow = mysql_fetch_array($cheklogUserResR); 
 $_SESSION['user_idd'] = $checkcountRow['id'];
 
 if($_REQUEST['prevpage']!="" && $_REQUEST['logpar']=='2') {
			$prevpage = $_REQUEST['prevpage'];
			$prevpage = $prevpage."#reviewdiv";
			header("Location:$prevpage");
			exit();
	}		
header("location:$rootpath/myaccount");
exit();
 } else { 
 $_SESSION['errorses'] = "Some Text";
 header("location:$rootpath/login");
 exit();
 }
 }
 ?>
 <?php $result_seo=mysql_fetch_array(mysql_query("select * from  tbl_seo where id='1'"));?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title><?php echo stripslashes($result_seo['title_tag']); ?></title>
<meta name="description" content="<?php echo stripslashes($result_seo['description_tag']); ?>" />
<meta name="keywords" content="<?php echo stripslashes($result_seo['meta_tag']); ?>" />

<link rel="shortcut icon" type="image/x-icon" href="<?=$rootpath?>/images/favicon.png" />


<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />


<script type="text/javascript" src="menu/js/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" media="all" href="menu/css/webslidemenu.css" />
<script type="text/javascript" src="menu/js/webslidemenu.js"></script>
<link rel="stylesheet" type="text/css" href="menu/font-awesome/css/font-awesome.min.css" />
</head>
<body>


<?php include("header.php");?>
<div class="inner-banner">
<div class="container">
<ul class="breadcrumb">
  <li><a href="<?php echo $rootpath; ?>/">Home</a></li>
  <li class="active">Login</li>
</ul>
</div>
</div>


<div class="container2">
<div class="container">
<div class="content">
<div class="heading">
<h1>Login</h1>
</div>

<div class="row">
<div class="col-md-4 col-md-offset-4">
<div class="box1">
<!-----------------    Log In Form Satart  -------------->  
<form name="frmregistration" id="frmregistration" method="post" action="" enctype="multipart/form-data">
<input type="hidden" name="logpar" id="logpar" value="<?php echo $_REQUEST['logpar']; ?>" />
<input type="hidden" name="prevpage" id="prevpage" value="<?php echo $_SERVER['HTTP_REFERER']; ?>" />
<div>
<div><?php if($_SESSION['errorses']!="") { echo "User Id/Password Wrong";  $_SESSION['errorses'] = ""; unset($_SESSION['errorses']); } $_SESSION['errorses'] = ""; unset($_SESSION['errorses']); ?></div>

<div id="logdiv">
<form id="formlog" name="formlog" method="post" action="" onsubmit="return false">
<div class="row">
<input type="hidden" name="id" id="id">
  
  <div class="col-md-12 f-email">
    <input type="text" name="rruserid" id="rruserid" placeholder="Email" required>
  </div>
  
  <div class="col-md-12 f-pass">
    <input type="password" name="rrpassword" id="rrpassword" placeholder="Password" required>
  </div> 
  
  
  <div class="col-md-12"><hr /></div>
  <div class="col-md-6 text-left">
  <a class="forgot" href="#" onclick="forgot_pass()">Forgot Password ?</a>
  </div> 
  
  <div class="col-md-6 text-right">
    <input type="submit" name="Submit"  id="Submit" value="Login" class="btn1">
  </div>

  <div id="waitdiverror"></div>
  </div>
  </form>
</div>  
  
 
<div id="forgotpassdiv" style="display:none;">  
<form name="frmforgot" id="frmforgot" method="post" action="">

 <div>
    <label for="textfield2"></label>
    <input type="text" name="fuserid" id="fuserid" class="txtbx" placeholder="Email">
  </div>	
  <div>
    <input type="button" name="fSubmit" id="Submit" value="Submit" onclick="forgotPasswordfunction()">
  </div>

</form>  
</div>

</div>

</form>
<!-----------------    Log In Form End  -------------->
</div>
</div>


</div>

</div>
</div>
</div>

<?php include("footer.php");?>
</body>
</html>
<script>
function checkavlEmail() {
var recemail = document.getElementById('rruseremail').value;
if(recemail!="") {

//$('#trashhistoryrecDiv').html('<img src="images/ajax-loader.gif">');
var dataString = 'recemail=' + recemail;
		//alert(dataString);
			$.ajax({
			type: "POST",
			url: "check_avlemail.php",
			data: dataString,
			success: function(theResponse)
			{
			var result=theResponse;
			//alert(result);
			if(result>0 && result==78) {
			document.getElementById('rruseremail').value = "";
			document.getElementById('rruseremail').focus();
			alert(recemail+' Email Already Registered');
			return false;
			}

			}
			});
}
}
</script>