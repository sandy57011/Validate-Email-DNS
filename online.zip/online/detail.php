<?php
ob_start();
@session_start();
include("include/connect.php");
include("include/function.php");
//echo count($_SESSION['cart']);
//echo "<pre>";
//print_r($_SESSION['cart']);
?>
<?php
//echo $_REQUEST['commandBulk']."<<<>>>>>>";
?>
<?php
$chekPageUrlNameAvl = checkFieldValueAvl('tbl_products','urlname',$_REQUEST['pid']);
if($chekPageUrlNameAvl==0) {
redirect($rootpath."/404");
exit();
}
?>
<?php 
   include("includeshoping/functions.php");
?>

<?php
	if($_REQUEST['command']=='add' && $_REQUEST['productid']>0){
	    //print_r($_REQUEST);
	    //exit();
		$pid=$_REQUEST['productid'];
		$pqty = $_REQUEST['french-hens'];
		$selectprice = $_REQUEST['selectprice'];
		$selectpriceBulk = $_REQUEST['productidbulk'];
		addtocart($pid,$pqty,$selectprice,$selectpriceBulk);		
		header("location:".$rootpath."/shoppingcart");
		exit();
	} ?>
<script language="javascript">
function addtocart(pid,bulkid){
	document.frmproduct.productid.value=pid;
	document.frmproduct.productidbulk.value=bulkid;
	document.frmproduct.command.value='add';
	document.frmproduct.submit();
}
</script>    
<?php
//$_SESSION['user_idd'] = 4;
//unset($_SESSION['user_idd']);
?>
<?php
$idd= $_REQUEST['pid'];
$productRow = mysql_fetch_array(mysql_query("select * from tbl_products where urlname ='".$idd."'")); 
$product_parent_Row = mysql_fetch_array(mysql_query("select * from manage_productcategory where urlname ='".$_REQUEST['id']."'")); 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title><?php echo stripslashes($productRow['title_tag']); ?></title>
<meta name="description" content="<?php echo stripslashes($productRow['description_tag']); ?>" />
<meta name="keywords" content="<?php echo stripslashes($productRow['meta_tag']); ?>" />


<link rel="shortcut icon" type="image/x-icon" href="<?=$rootpath?>/images/favicon.png" />




<link href="<?=$rootpath?>/css/style.css" rel="stylesheet" type="text/css" />
<link href="<?=$rootpath?>/css/grid.css" rel="stylesheet" type="text/css" />
<link href="<?=$rootpath?>/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />



<script type="text/javascript" src="<?=$rootpath?>/menu/js/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" media="all" href="<?=$rootpath?>/menu/css/webslidemenu.css" />
<script type="text/javascript" src="<?=$rootpath?>/menu/js/webslidemenu.js"></script>
<link rel="stylesheet" type="text/css" href="<?=$rootpath?>/menu/font-awesome/css/font-awesome.min.css" />



<!---------------  Quantity Increment and Decrement Start ---------------->
<script src="<?=$rootpath?>/numincrement/incrementing.js"></script>
<link rel="stylesheet" href="<?=$rootpath?>/numincrement/style.css">
<!---------------  Quantity Increment and Decrement Start ---------------->

	<link rel='stylesheet' href='<?=$rootpath?>/numqty/dpNumberPicker-2.x.css' />
	<link rel='stylesheet' href='<?=$rootpath?>/numqty/dpNumberPicker-2.x-skin.grey.css' />
	<script src='<?=$rootpath?>/numqty/dpNumberPicker-2.x.js'></script>
	<script>
		$(document).ready(function(){
			dpUI.numberPicker("#np", {
				min: 1,
				//max: 10,
				//step: 0.25,
				step: 1,
				//format: "#.##",
				//format: "",
				formatter: function(x){
					//return "$ "+x;
					return x;
				}
			});
		});
	</script>
<link href="<?=$rootpath?>/http://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
<!------------------  For Custom Select Box  ------------------------>
<link href="<?=$rootpath?>/customtextbox/styles.css" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="<?=$rootpath?>/customtextbox/jquery-1.3.min.js"></script>
<script type="text/javascript" src="<?=$rootpath?>/customtextbox/jquery.customselect.js"></script>
<script type="text/javascript" src="<?=$rootpath?>/customtextbox/jquery.scrollTo-min.js"></script>

<script type="text/javascript">
$jq777 = $.noConflict();
$jq777(document).ready(function() {
	$jq777('select[name=selectprice]').SelectCustomizer();
});

</script>
<!-------------------------------------------------------------------->
</head>
<body onLoad="getproductrating()">


<?php include("header.php");?>

<!------------   For Start Rating Start ---------------->
<script src="<?=$rootpath?>/starrating/jquery.js">
</script><script src="<?=$rootpath?>/starrating/jquery.raty.js"></script>
<script src="<?=$rootpath?>/starrating/labs.js" type="text/javascript"></script>
<!------------   For Start Rating End  ---------------->


<div class="inner-banner">
<div class="container">
<ul class="breadcrumb">
  <li><a href="<?php echo $rootpath; ?>/">Home</a></li>    
  <li><a href="<?=$rootpath?>/astro-<?php echo $product_parent_Row['urlname'];?>"><?php echo $product_parent_Row['name']; ?></a></li>
  <li class="active"><?php echo stripslashes($productRow['productname']); ?></li>
</ul>

</div>
</div>

<div class="container">
<div class="content">
<div class="heading">
<h1><?php echo stripslashes($productRow['productname']); ?></h1>
</div>


<div class="row">


<div class="col-md-6">
<img src="<?=$rootpath?>/adminimg/logoimg/<?php echo $productRow['logoimg']; ?>" class="img-full" />
</div>

<div class="col-md-6 product-detail">
                <div>

                    <?php $result_productcat = mysql_fetch_array(mysql_query("select * from manage_productcategory order by id"));?>

                    <div>
                        <form name="frmproduct" id="frmproduct" method="post" action="">
                            <input type="hidden" name="hiddproductid" id="hiddproductid" value="<?php echo $productRow['id']; ?>" />
                            <input type="hidden" name="productid" />
                            <input type="hidden" name="productidbulk" />
                            <input type="hidden" name="command" />
                            
                            <div class="hidden">
                            
                            <select name="selectprice" id="selectprice">

<?php
if($_REQUEST['commandBulk']!="" && $_REQUEST['commandBulk']=="Bulk") {
?>
<?php
$priceListByPrIdBulk = getPriceListByPrIdBulk($productRow['id']);
if(count($priceListByPrIdBulk)>0) {
?>
<?php foreach($priceListByPrIdBulk as $priceListByPrIdBulkData) { ?>
<option value="<?php echo $priceListByPrIdBulkData['id']; ?>" label='<div><div class="grid_6"><?php echo strip_tags($priceListByPrIdBulkData['price_name']); ?></div><div class="grid_6 omega"><? if($priceListByPrIdBulkData['price_inr'] != 0) { ?><strong><i class="fa fa-inr"></i> <?php echo $priceListByPrIdBulkData['price_inr']; ?></strong> &nbsp; &nbsp; ( MRP: <i class="fa fa-inr"></i> <?php echo $priceListByPrIdBulkData['pricecup_inr']; ?> )<? } ?></div><div class="clear"></div></div>'></option>
<?php } ?>
<?php } ?>
<?php } else { ?>

<option value="0" label='<div><div class="grid_6"><?php echo strip_tags($productRow['productpricedescr']); ?></div><div class="grid_6 omega"><strong><i class="fa fa-inr"></i> <?php echo $productRow['productpriceinr']; ?></strong> &nbsp; &nbsp; <? if($productRow['productpricepercupinr'] != 0) { ?>( MRP: <i class="fa fa-inr"></i> <?php echo $productRow['productpricepercupinr']; ?> )<? } ?></div><div class="clear"></div></div>'></option>
<?php
$priceListByPrId = getPriceListByPrId($productRow['id']);
if(count($priceListByPrId)>0) {
?>
<?php foreach($priceListByPrId as $priceListByPrIdData) { 


?>
	<option value="<?php echo $priceListByPrIdData['id']; ?>" label='<div><div class="grid_6"><?php echo strip_tags($priceListByPrIdData['price_name']); ?></div> <? if($priceListByPrIdData['pricecup_inr'] != 0) { ?><div class="grid_6 omega"><strong><i class="fa fa-inr"></i> <?php echo $priceListByPrIdData['price_inr']; ?></strong> &nbsp; &nbsp;( MRP: <i class="fa fa-inr"></i> <?php echo $priceListByPrIdData['pricecup_inr']; ?> )</div><div class="clear"></div><?php } ?></div>'></option>
<?php } ?>
<?php } ?> 

<?php } ?> 

   
</select>
</div>


                            <div class="row">

                                
                                <!--
                                <div class="col-md-12">
                                <p><strong>Product Code:</strong></p>
                                    <?php echo $productRow['productpricedescr'] ?>
                                <p>&nbsp;</p>
                                </div>
                                -->


                                <div class="col-md-12">
                                <p><strong>Price:</strong></p>
                                    <h5><i class="fa fa-inr"></i> <?php echo $productRow['productpriceinr'] ?>/- <!--<strong><i class="fa fa-inr"></i>  <?php echo $productRow['productpricepercupinr'] ?>/-</strong>--></h5>
                                    <p>&nbsp;</p>
                                </div>



                                <div class="col-md-6">
                                <p><strong>Quantity:</strong></p>
                                    <div class="numbers-row">
                                        <input type="text" style="width:100px !important;" name="french-hens" id="french-hens" value="1" readonly>
                                    </div>
                                </div>
                                <!---------------------------------------------------------------->


                                <div class="col-md-6">
                                <p>&nbsp;</p>
                                    <?php
                                    if($_REQUEST['commandBulk']!="" && $_REQUEST['commandBulk']=='Bulk') {
                                        ?>
                                        <input type="submit" class="btn1" name="button2" id="button2" value="Add to Cart" onClick="addtocart('<?php echo $productRow['id']?>','1')"/>
                                    <?php } else { ?>
                                        <input type="submit" class="btn1" name="button2" id="button2" value="Add to Cart" onClick="addtocart('<?php echo $productRow['id']?>','0')"/>
                                    <?php } ?>
                                </div>

                            </div>
                        </form>
                    </div>
                    
                    <hr />


                    <?php if($productRow['deliverytime']!=''): ?>
                        <h4><i class="fa fa-users" aria-hidden="true"></i> &nbsp; <?php echo $productRow['deliverytime'];?></h4>
                    <?php endif; ?>
                    
                    <hr>
                    
                    <div class="social">
                    <ul>
<li><a href="http://www.facebook.com/sharer.php?u=<?php echo 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" target="_blank"><img src="<?php echo $rootpath; ?>/images/facebook.png" alt="facebook"></a></li>
       
<li><a href="https://plus.google.com/share?url=<?php echo 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" target="_blank"><img src="<?php echo $rootpath; ?>/images/google.png" alt="google plus"></a></li>
  
<li><a href="https://twitter.com/share?url=<?php echo 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" target="_blank"><img src="<?php echo $rootpath; ?>/images/twitter.png" alt="twitter"></a></li>
        
        <!--<a class="visible-xs" href="whatsapp://send?text=<?=rawurlencode($blog_data['title'] .'-'. $rootpath.'/blog/'.$blog_data['url'])?>" >WhatsApp</a>

        <a class="hidden-sm hidden-xs" href="https://api.whatsapp.com/send?text=<?=rawurlencode($blog_data['title'] .'-'. $rootpath.'/blog/'.$blog_data['url'])?>" >WhatsApp</a>-->
</ul> 
        </div>
        
        
                </div>
            </div>

</div>
</div>
</div>


<?php include("footer.php");?>
</body>
</html>
<script>
function plusQuantityFunction() {
//alert();
 var catoptidvalvvll=document.getElementById('itemqty').value;
 var catoptidvalvvll=eval(catoptidvalvvll)+1;
 if(catoptidvalvvll==0) {
 catoptidvalvvll=1;
 }
document.getElementById('itemqty').value = catoptidvalvvll;
}

function minusQuantityFunction(str,str1) {

 var catoptidvalvvll=document.getElementById('itemqty').value;
 var catoptidvalvvll=eval(catoptidvalvvll)-1;
 if(catoptidvalvvll==0) {
 
 var catoptidvalvvll=1;
 }
document.getElementById('itemqty').value = catoptidvalvvll;
}
</script>
<script>
function checkUserlogin() {
var checksession11 = '<?php echo $_SESSION['user_idd']; ?>';
	if(checksession11=="") {

	adc('test-contentReg');
					
	} else {

$.post("user-review-write.php",function(data){
		$div = $('<div />').appendTo('body');
		$div.attr('id', 'dynamicl');	
		$('#dynamicl').html(data);
		//processReg();
		},"html");
		
//return adcLogReview('test-contentLogReview')		

	}
}
function close_login() {
		 $('#dynamicl').remove();
	}
</script>

<script>
function submitreviewFunction() {
var rheading = document.getElementById('rheading').value;
var ureview = document.getElementById('ureview').value;
var ustar = document.getElementById('ustar').value;
var hiddproductid = document.getElementById('hiddproductid').value;
		if(rheading=="")
		{
		alert('Please Enter Review Summary');
		$('#rheading').focus();
		return false;
		}
		if(ureview=="")
		{
		alert('Please Enter Review');
		$('#ureview').focus();
		return false;
		}

$('#waitdivwritereview').html('<img src="<?=$rootpath?>/images/ajax-loader.gif">');
var dataString = 'rheading=' + rheading+ '&ureview=' + ureview+ '&ustar=' +ustar+ '&hiddproductid=' +hiddproductid;
		//alert(dataString);
			$.ajax({
			type: "POST",
			url: "<?=$rootpath?>/user-review.php",
			data: dataString,
			success: function(theResponse)
			{
			var result=theResponse;
			//alert(result);
			if(result<0 && result==-22) {
			$('#waitdivwritereview').html('');
			//alert();
			}
		if(result>0 && result==9) {
		$('#waitdivwritereview').html('');

		alert('Thanks for Submit Review');	
				//window.location="index.php";					
			location.reload();		
			}

			}
			});
}
</script>
<?php
$totalUser = getTotalReviewByProductId($productRow[id]);
$totalreviewstar = getTotalReviewCountByProductId($productRow[id]);
if($totalreviewstar=="") {
$totalreviewstar=0;
}
$totalrequired = $totalUser*5;
$productrating=($totalreviewstar*5)/$totalrequired;
if($productrating=="") {
$productrating=0;
}
?>
<script>
$.fn.raty.defaults.path = '<?=$rootpath?>/starrating/images';

$(function() {
//alert();
$('#halfShow-true').raty({ score: 3.26 });
//$('#prductreadOnly').raty({ readOnly: true, score: 3 });
$('#prductreadOnly').raty({ readOnly: true, score: <?php echo $productrating; ?>});

$('#click').raty({
  click: function(score, evt) {
  document.getElementById('ustar').value = score;
    //alert('ID: ' + this.id + "\nscore: " + score + "\nevent: " + evt.type);
  }
});

  });
</script>