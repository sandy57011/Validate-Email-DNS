<?php
ob_start();
@session_start();
include("include/connect.php");
include("include/function.php");
?>
<?php $result_seo=mysql_fetch_array(mysql_query("select * from contents where id='15'"));?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title><?php echo stripslashes($result_seo['title_tag']); ?></title>
<meta name="description" content="<?php echo stripslashes($result_seo['description_tag']); ?>" />
<meta name="keywords" content="<?php echo stripslashes($result_seo['meta_tag']); ?>" />


<link rel="shortcut icon" type="image/x-icon" href="<?=$rootpath?>/images/favicon.png" />

<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />


<script type="text/javascript" src="menu/js/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" media="all" href="menu/css/webslidemenu.css" />
<script type="text/javascript" src="menu/js/webslidemenu.js"></script>
<link rel="stylesheet" type="text/css" href="menu/font-awesome/css/font-awesome.min.css" />
</head>
<body>

<?php include("header.php");?>
<div class="inner-banner">
<div class="container">
<ul class="breadcrumb">
  <li><a href="<?php echo $rootpath; ?>/">Home</a></li>  
  <li class="active">About us</li>
</ul>
</div>
</div>



<div class="container">
<div class="content">

<?php
$indexRow = mysql_fetch_array(mysql_query("select * from contents where id='15'")); 
?>
    
    <h1><?php echo stripslashes($indexRow['heading']); ?><span></span></h1>
    
<?php echo restoreTags(stripslashes($indexRow['description'])); ?>


<div class="clear"></div>


</div>
</div>


<?php include("footer.php");?>
</body>
</html>
