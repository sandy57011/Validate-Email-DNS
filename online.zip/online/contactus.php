<?php
ob_start();
@session_start();
include("include/connect.php");
include("include/function.php");

?>
<?php
if(isset($_REQUEST['buttoncont']) && $_REQUEST['buttoncont']=="Submit Query") {
	 $recaptcha_secret ='6LdN53IUAAAAABtsinyJjYueP1HWYYfgobnauP8-';
    $response = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=".$recaptcha_secret."&response=".$_POST['g-recaptcha-response']);
    $response = json_decode($response, true);

    if($response["success"] === true){
		$r_name = $_REQUEST[r_name];
		$r_email = $_REQUEST[r_email];
		$r_mob = $_REQUEST[r_mob];
		$r_comment = $_REQUEST[r_comment];
				
		$fname = $_REQUEST['fname'];
		$cemail = $_REQUEST['cemail'];
		$cphone = $_REQUEST['cphone'];
		$cmessage = $_REQUEST['cmessage'];

		$q="INSERT INTO tbl_query set r_name ='".$fname."',
		r_email='".$cemail."',
		r_mob='".$cphone."',
		r_comment='".$cmessage."',
		query_from='Contact Us'	
		";
		$final=mysql_query($q)or die(mysql_error());

		$body ='<div style="line-height:30px;">
		<div style="border-bottom:solid 1px #ccc; padding:10px; margin:0 0 10px 0;"><a href="'.$rootpath.'/index.php"><img src="'.$rootpath.'/images/logo.png" alt="Delivery Kings"/></a></div>
		<div><strong>Name:</strong> '.$fname.'</div>
		<div><strong>Email:</strong> '.$cemail.'</div>
		<div><strong>Phone:</strong> '.$cphone.'</div>
		</div> ';
		if($cmessage!="") {
			$body .='<div style="line-height:30px;">
			<div><strong>Message:</strong>'.$cmessage.'</div>
		</div>';
		}
		$to = "info@deliverykings.co.in";
		$Subject = "Contact Enquiry";//
	
		//sent_smtp_email($to,$Subject,$body);
		require 'PHPMailer/PHPMailerAutoload.php';
        		
	    $mail = new PHPMailer;
	    $mail->IsSMTP();                                    
	    $mail->Host = 'mail.deliverykings.co.in';  
	    $mail->SMTPAuth = true;                              
	    $mail->Username = 'no-reply@deliverykings.co.in';               
	    $mail->Password = 'noreply@123#';                         
	    $mail->SMTPSecure = 'tls';                            
	    $mail->Port = 25;        
			
	    $mail->setFrom('no-reply@deliverykings.co.in', 'no-reply');
	    $mail->addAddress($to);     
	    $mail->isHTML(true);                                  
	    $mail->Subject = $Subject;
	    $mail->Body    = $body;
	    $mail->AltBody = $body;
	    if($mail->send()) { 
	        //	echo	$msg =  'done';
	    }else{
            // 	echo 'Mailer Error: ' . $mail->ErrorInfo;
	    }
		$bodyy ='<div style="line-height:30px;">
		<div><strong>Thank you for Submitting details, We will get in touch soon!</strong> </div>
		<div style="border-top:solid 1px #ccc; padding:10px 0; margin:10px 0 0 0;"><a href="'.$rootpath.'/index.php"><img src="'.$rootpath.'/images/logo.png" alt="Delivery Kings"/></a></div>
		</div>';

		$to = $cemail;
		$Subject = "Contact Enquiry";//
	
    			
	    $mail = new PHPMailer;
	    $mail->IsSMTP();                                    
	    $mail->Host = 'mail.deliverykings.co.in';  
	    $mail->SMTPAuth = true;                              
	    $mail->Username = 'no-reply@deliverykings.co.in';               
	    $mail->Password = 'noreply@123#';                         
	    $mail->SMTPSecure = 'tls';                            
	    $mail->Port = 25;        
			
	    $mail->setFrom('no-reply@deliverykings.co.in', 'no-reply');
	    $mail->addAddress($to);     
	    $mail->isHTML(true);                                  
	    $mail->Subject = $Subject;
	    $mail->Body    = $bodyy;
	    $mail->AltBody = $bodyy;
	    if($mail->send()) { 
	        //	echo	$msg =  'done';
	   }else{
            // 	echo 'Mailer Error: ' . $mail->ErrorInfo;
	    }
		header("location:thanks");
		exit();	
	}else{
		exit('Captcha Failed');
	}
}	
?>
<?php $result_seo=mysql_fetch_array(mysql_query("select * from contents where id='12'"));?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo stripslashes($result_seo['title_tag']); ?></title>
<meta name="description" content="<?php echo stripslashes($result_seo['description_tag']); ?>" />
<meta name="keywords" content="<?php echo stripslashes($result_seo['meta_tag']); ?>" />
<link rel="shortcut icon" type="image/x-icon" href="<?=$rootpath?>/images/favicon.png" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="menu/js/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" media="all" href="menu/css/webslidemenu.css" />
<script type="text/javascript" src="menu/js/webslidemenu.js"></script>
<link rel="stylesheet" type="text/css" href="menu/font-awesome/css/font-awesome.min.css" />
<script src='https://www.google.com/recaptcha/api.js'></script>
<script>
function check_grecaptcha()
{
	var v = grecaptcha.getResponse();
    if(v.length == 0)
    {
        alert("You can't leave Captcha Code empty");
        return false;
    }
	return true;
}
</script>
</head>
 <body>
<?php include("header.php");?>
<div class="inner-banner">
   <div class="container">
   <ul class="breadcrumb">
  <li><a href="<?php echo $rootpath; ?>/">Home</a></li>  
  <li class="active">Contact us</li>
</ul>
  </div>
 </div>
<div class="container">
<div class="content">
<div class="heading">
<h1>Contact us</h1>
</div>   
   
<?php
$contactRow=mysql_fetch_array(mysql_query("select * from manage_contactaddress where id='1'"));
?>
    <div class="row">
       <div class="col-sm-4">
       <div class="presence">
       <i class="fa fa-volume-control-phone"></i>
       <h6><a  href="tel://<?php echo $contactRow['phone']; ?>"><?php echo $contactRow['phone']; ?></a></h6>
       </div>
      </div>
      
      
      <div class="col-sm-4">
       <div class="presence">
       <i class="fa fa-envelope-open-o" aria-hidden="true"></i>
       <h6><a href="mailto:<?php echo $contactRow['email']; ?>"><?php echo $contactRow['email']; ?></a></h6>
       </div>               
      </div>
      
      
      
      <div class="col-sm-4">
       <div class="presence">
       <i class="fa fa-map-marker" aria-hidden="true"></i>
       <h6><?php echo stripslashes($contactRow['address']); ?></h6>
       </div>
      </div>
      
      
     </div>
  </div>
 </div>
<div class="container2">
   <div class="container">
    <div class="content">
    <div class="heading">
       <h2>Send Any Query</h2>
       </div>
       <form action="" method="post" name="reuq_form" id="reuq_form" onsubmit="return check_grecaptcha()">
       <div class="row">
        <div class="col-md-4 col-sm-4 f-user">
           <input name="fname" type="text" class="txtfield" id="fname" placeholder="Name *" required/>
         </div>
        <div class="col-md-4 col-sm-4 f-mobile">
           <input type="tel" pattern="\d{10}" name="cphone" id="cphone" class="txtfield" placeholder="Mobile *" maxlength="10" rerquired/>
         </div>
        <div class="col-md-4 col-sm-4 f-email">
           <input name="cemail" type="email" class="txtfield" id="cemail" placeholder="Email *" required/>
         </div>
        <div class="col-md-12 f-message">
           <textarea name="cmessage"  id="cmessage" placeholder="Message / Comments"></textarea>
         </div>
		<div class="col-md-10">
		<div class="g-recaptcha" data-sitekey="6LdN53IUAAAAANxVkNhtboOw5DQqcs60R0ueJbeO"></div>
		</div>
        <div class="col-md-2">
        <br />
           <input type="submit" name="buttoncont"id="buttoncont" value="Submit Query" class="btn1" />
           <input name="hdn" type="hidden" id="hdn" value="1" />
         </div>
        
        </div>
      </form>
     </div>
  </div>
 </div>
<?php include("footer.php");?>
</body>
 </html>
<script type="text/javascript">
  function Queryvalidate(){
   doc = document.reuq_form;
    var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
	var r_name = doc.r_name.value;
	var r_email = doc.r_email.value;
	var r_mob = doc.r_mob.value;
	var r_comment = doc.r_comment.value;
	
	    if(r_name =="")
        {
        alert('Please Enter Name');
        doc.r_name.focus();
        return false;
        }
	    if(r_email=="")
        {
        alert('Please Enter Email Address');
        doc.r_email.focus();
        return false;
        }
        if(reg.test(r_email) == false) { 
        alert('Invalid Email Address');
        doc.r_email.value ="";
        doc.r_email.focus();
        return false;
        }
		if(r_mob =="")
        {
        alert('Please Enter Mobile No');
        doc.r_mob.focus();
        return false;
        }
		if(isNaN(r_mob))
		{
		alert("Enter the valid Mobile Number(Like : 9566137117)");
		doc.r_mob.focus();
		return false;
		}
		
		var phnlen = r_mob.length;
		if(phnlen<10) {
		alert("Enter the valid Mobile Number");
		doc.r_mob.focus();
		return false;
		}
		if(r_comment =="")
        {
        alert('Please Enter Message');
        doc.r_comment.focus();
        return false;
        }
	   
			
 }
 </script>