<?php ob_start();
@session_start();
$_SESSION['user_idd'] ="";
unset($_SESSION['user_idd']);
//session_destroy();
header("location:index.php");
exit();
?>