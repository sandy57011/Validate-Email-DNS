<?php
ob_start();
@session_start();
include("include/connect.php");
include("include/function.php");
include("include/resizeimage.php");
?>
<?php if($_SESSION[user_idd]==''){ 
header("Location:index");
exit();
	}
?>
<?php
if($_REQUEST['ffSubmit'] && $_REQUEST['ffSubmit']=="Submit") {
if($_FILES["imagefilenamelogo"]["name"]!=""){
	@unlink("adminimg/userprofile/".$_REQUEST['ExistImagelogoimg']);
	$intFile=mt_rand();
	move_uploaded_file($_FILES["imagefilenamelogo"]["tmp_name"],"adminimg/userprofile/".$intFile.$_FILES["imagefilenamelogo"]["name"]);

	$filelogoimg=$intFile.$_FILES["imagefilenamelogo"]["name"];

$thumb=generateThumb($filelogoimg,"adminimg/userprofile/","adminimg/userprofile/",800,800);

} else {

	$filelogoimg=$_REQUEST['ExistImagelogoimg'];
}

$userRowOld =mysql_fetch_array(mysql_query("select * from tbl_registration where id='".$_SESSION['user_idd']."'"));

$res=mysql_query("update tbl_registration set uname = '".$_REQUEST['proname']."', imagefilename = '".$filelogoimg."', uphone = '".$_REQUEST['prophone']."' where id = '".$_SESSION['user_idd']."'");

$userRowNew =mysql_fetch_array(mysql_query("select * from tbl_registration where id='".$_SESSION['user_idd']."'"));

?>
<!-------------------------------------------------------------------------->
<?php
$contactRowAddress=mysql_fetch_array(mysql_query("select * from manage_contactaddress where id='1'"));
if($contactRowAddress['address']!="") {
$mailaddress.="<p>&nbsp;</p>";
$mailaddress.=restoreTags(stripslashes($contactRowAddress['address']));
$mailaddress.="<p>&nbsp;</p>";
}

if($contactRowAddress['email']!="") {
$mailaddress.="<h4>Email:</h4>";
$mailaddress.=$contactRowAddress['email'];
$mailaddress.="<p>&nbsp;</p>";
}

if($contactRowAddress['phone']!="") {
$mailaddress.="<h4>Phone:</h4>";
$mailaddress.=$contactRowAddress['phone'];
$mailaddress.="<p>&nbsp;</p>";
}
?>

<?php
$body='<table width="600"  border="0" cellspacing="0" cellpadding="15" style="border:solid 3px #0033FF;">
<tr>
	<td bgcolor="#0033FF;"><a href="'.$rootpath.'/index.php"><img src="'.$rootpath.'/images/logo.png" alt="deliverykings.co.in" /></a></td>
</tr>
<tr>
	<td style="font-family:Arial, Helvetica, sans-serif; font-size:12px;">
    
<table width="100%" border="0" cellpadding="4" cellspacing="0">
     <tr>
        <td colspan="2">'.$rusername.' has changed his profile information</td>
      </tr>
     <tr>
        <td colspan="2">Old profile information</td>
      </tr>	  
      <tr>
        <td width="22%" align="left"><strong> Name:</strong></td>
        <td width="78%" align="left"><span style="float:left; width:270px;">'.$userRowOld[uname].'</span></td>
      </tr>
      <tr>
        <td width="22%" align="left"><strong> Phone:</strong></td>
        <td width="78%" align="left"><span style="float:left; width:270px;">'.$userRowOld[uphone].'</span></td>
      </tr>	  		
      <tr>
        <td width="22%" align="left"><strong> Email/User Id:</strong></td>
        <td width="78%" align="left"><span style="float:left; width:270px;">'.$userRowOld[uemail].'</span></td>
      </tr>
      <tr>
        <td width="22%" align="left"><strong> Password:</strong></td>
        <td width="78%" align="left"><span style="float:left; width:270px;">'.$userRowOld[upass].'</span></td>
      </tr>			  	   	        
      <tr>
        <td align="left">&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
     <tr>
        <td colspan="2">New profile information</td>
      </tr>	  
      <tr>
        <td width="22%" align="left"><strong> Name:</strong></td>
        <td width="78%" align="left"><span style="float:left; width:270px;">'.$userRowNew[uname].'</span></td>
      </tr>
      <tr>
        <td width="22%" align="left"><strong> Phone:</strong></td>
        <td width="78%" align="left"><span style="float:left; width:270px;">'.$userRowNew[uphone].'</span></td>
      </tr>	  		
      <tr>
        <td width="22%" align="left"><strong> Email/User Id:</strong></td>
        <td width="78%" align="left"><span style="float:left; width:270px;">'.$userRowNew[uemail].'</span></td>
      </tr>
      <tr>
        <td width="22%" align="left"><strong> Password:</strong></td>
        <td width="78%" align="left"><span style="float:left; width:270px;">'.$userRowNew[upass].'</span></td>
      </tr>			  	   	        
      <tr>
        <td align="left">&nbsp;</td>
        <td>&nbsp;</td>
      </tr>	  
    </table>    
    
    </td>
</tr>
<tr>
  <td style="font-family:Arial, Helvetica, sans-serif; font-size:12px;">
  <p><strong>      Warm Regards</strong></p>
    <p style="font-size:14px; color:#0033FF;"><strong>deliverykings.co.in</strong></p>
    '.$mailaddress.'<br>
    Web:- <a href="www.deliverykings.co.in">www.deliverykings.co.in</a><br>
  </td>
</tr>
</table>';
		$to = "info@deliverykings.co.in";
		$Subject = "Registration Information from deliverykings.co.in";//
		$headers = "MIME-Version: 1.0" . "\r\n";
		$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		$from = "no-reply@deliverykings.co.in";
		$headers .= "From:" . $from;
		@mail($to,$Subject,$body,$headers);
/*******************************  Thank you mail Start  *******************************/		
$ToSubject = "Profile Information Changed With deliverykings.co.in";
$toemail = $userRowOld[uemail];
$Messagey='<table width="600"  border="0" cellspacing="0" cellpadding="15" style="border:solid 3px #0033FF;">
<tr>
	<td bgcolor="#0033FF;"><a href="'.$rootpath.'/index.php"><img src="'.$rootpath.'/images/logo.png" alt="deliverykings.co.in" /></a></td>
</tr>
<tr>
	<td style="font-family:Arial, Helvetica, sans-serif; font-size:12px;">
    
<table width="100%" border="0" cellpadding="4" cellspacing="0">
     <tr>
        <td colspan="2">You have changed your profile information</td>
      </tr>
     <tr>
        <td colspan="2">Old profile information</td>
      </tr>	  
      <tr>
        <td width="22%" align="left"><strong> Name:</strong></td>
        <td width="78%" align="left"><span style="float:left; width:270px;">'.$userRowOld[uname].'</span></td>
      </tr>
      <tr>
        <td width="22%" align="left"><strong> Phone:</strong></td>
        <td width="78%" align="left"><span style="float:left; width:270px;">'.$userRowOld[uphone].'</span></td>
      </tr>	  		
      <tr>
        <td width="22%" align="left"><strong> Email/User Id:</strong></td>
        <td width="78%" align="left"><span style="float:left; width:270px;">'.$userRowOld[uemail].'</span></td>
      </tr>
      <tr>
        <td width="22%" align="left"><strong> Password:</strong></td>
        <td width="78%" align="left"><span style="float:left; width:270px;">'.$userRowOld[upass].'</span></td>
      </tr>			  	   	        
      <tr>
        <td align="left">&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
     <tr>
        <td colspan="2">New profile information</td>
      </tr>	  
      <tr>
        <td width="22%" align="left"><strong> Name:</strong></td>
        <td width="78%" align="left"><span style="float:left; width:270px;">'.$userRowNew[uname].'</span></td>
      </tr>
      <tr>
        <td width="22%" align="left"><strong> Phone:</strong></td>
        <td width="78%" align="left"><span style="float:left; width:270px;">'.$userRowNew[uphone].'</span></td>
      </tr>	  		
      <tr>
        <td width="22%" align="left"><strong> Email/User Id:</strong></td>
        <td width="78%" align="left"><span style="float:left; width:270px;">'.$userRowNew[uemail].'</span></td>
      </tr>
      <tr>
        <td width="22%" align="left"><strong> Password:</strong></td>
        <td width="78%" align="left"><span style="float:left; width:270px;">'.$userRowNew[upass].'</span></td>
      </tr>			  	   	        
      <tr>
        <td align="left">&nbsp;</td>
        <td>&nbsp;</td>
      </tr>	  
    </table>    
    
    </td>
</tr>
<tr>
  <td style="font-family:Arial, Helvetica, sans-serif; font-size:12px;">
  <p><strong>      Warm Regards</strong></p>
    <p style="font-size:14px; color:#0033FF;"><strong>deliverykings.co.in</strong></p>
    '.$mailaddress.'<br>
    Web:- <a href="www.deliverykings.co.in">www.deliverykings.co.in</a><br>
  </td>
</tr>
</table>';

		$headers = "MIME-Version: 1.0" . "\r\n";
		$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		$from = "no-reply@deliverykings.co.in";
		$headers .= "From:" . $from;
 		@mail($toemail,$ToSubject, $Messagey, $headers);
?>
<!-------------------------------------------------------------------------->

<?php
if($_REQUEST['pronewpass']!="") {

$res=mysql_query("update tbl_registration set upass = '".$_REQUEST['pronewpass']."', mdupass = '".md5($_REQUEST['pronewpass'])."' where id = '".$_SESSION['user_idd']."'");

}

}
?>
<?php
//echo $_SESSION['user_idd'];
$userRow =mysql_fetch_array(mysql_query("select * from tbl_registration where id='".$_SESSION['user_idd']."'"));
?>
<?php $result_seo=mysql_fetch_array(mysql_query("select * from  tbl_seo where id='4'"));?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title><?php echo stripslashes($result_seo['title_tag']); ?></title>
<meta name="description" content="<?php echo stripslashes($result_seo['description_tag']); ?>" />
<meta name="keywords" content="<?php echo stripslashes($result_seo['meta_tag']); ?>" />

<link rel="shortcut icon" type="image/x-icon" href="<?=$rootpath?>/images/favicon.png" />




<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />


<script type="text/javascript" src="menu/js/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" media="all" href="menu/css/webslidemenu.css" />
<script type="text/javascript" src="menu/js/webslidemenu.js"></script>
<link rel="stylesheet" type="text/css" href="menu/font-awesome/css/font-awesome.min.css" />


</head>
<body>


<?php include("header.php");?>
<?php include("userlinks.php");?>

<div class="container">
<div class="content">
<div class="heading">
<h1>Edit Profile</h1>
</div>


<div id="profileeditdiv">
<form id="formpr" name="formpr" method="post" enctype="multipart/form-data" action="">
<input type="hidden" name="id" id="id">

<div class="row">
  <div class="col-sm-4 f-user">
    <label for="textfield2"></label>
    Name:<input type="text" name="proname" id="proname" value="<?php echo $userRow['uname']; ?>" />
  </div>
  
  <div class="col-sm-4 f-mobile">
    <label for="textfield2"></label>
    Phone:<input type="text" name="prophone" id="prophone" value="<?php echo $userRow['uphone']; ?>" maxlength="10"/>
  </div>  
 
    <div class="col-sm-4 f-email">
    <label for="textfield2"></label>
    Email:<input type="text" name="proemail" id="proemail" value="<?php echo $userRow['uemail']; ?>" readonly="readonly"/>
  </div>
  
  
  <div class="clear"></div>  
<div class="col-sm-4">
    <label for="textfield2"></label>
    
<?php if($userRow[imagefilename] and file_exists("adminimg/userprofile/".$userRow[imagefilename])) { ?> 
<img src="adminimg/userprofile/<?=$userRow[imagefilename]?>" width='80' style="border:1px solid #ccc; padding:2px; float:left; margin-right:5px;"> 
<input type="hidden" name="ExistImagelogoimg" id="ExistImagelogoimg" value="<?=$userRow[imagefilename]?>">
<?php } else { ?>
<img src="images/No-Picture.jpg" width='80' style="border:1px solid #ccc; padding:2px; float:left; margin-right:5px;">
<?php } ?>

Upload Image<br />
<div class="btn-file">
    <label id="fileLabellogo">Click to Upload Image </label><input name="imagefilenamelogo" id="imagefilenamelogo" type="file" onchange="pressedimage('logo')">
    </div> 
</div>

  
    <div class="col-sm-4 f-pass">
    <label for="textfield2"></label>
    New Password:<input type="text" name="pronewpass" id="pronewpass" value=""/>
  </div> 
  
  
  
  <div class="col-sm-4 text-right"><br />
    <input type="submit" name="ffSubmit" id="Submit" value="Submit" class="btn1">
  </div>  
  
  
  </div>
  
  <div id="waitdivprofile" style="text-align:center;"></div>
  
  
  </form>
</div>

<!--------------->

</div>
</div>


<?php include("footer.php"); ?>
</body>
</html>

<script>
window.pressedimage = function(numstr)
{	
//alert(numstr);

    var dylebel = 'fileLabel'+numstr;
	var dyimg = 'imagefilename'+numstr;

var ggllb = dyimg;
var imgpathBanner = document.getElementById(ggllb).value;
//var fsize = $('#imgfile1')[0].files[0].size;
var fsize = document.getElementById(ggllb).files[0].size;
//var fsize = $('#galimg')[0].files[0].size;
if(fsize>1048576*2) {
document.getElementById(ggllb).value = "";
alert('Upload File Size Must be < 2 MB');
return false;
}
if(imgpathBanner!="") {
var arr1 = new Array;
arr1 = imgpathBanner.split("\\");
var len = arr1.length;
var img1 = arr1[len-1];
var filext = img1.substring(img1.lastIndexOf(".")+1);
// Checking Extension
var filext = filext.toLowerCase();
if(filext != "jpg" && filext != "JPG" && filext != "JPEG" && filext != "JPEG" && filext != "gif" && filext != "GIF" && filext != "png" && filext != "PNG")
{
document.getElementById(ggllb).value = "";
alert("Invalid File Format Selected");
document.frmadd.ggllb.focus();
return false;
}
}
    var a = document.getElementById(ggllb);
    if(a.value == "")
    {
		document.getElementById(dylebel).innerHTML = "";
    }
    else
    {
        var theSplit = a.value.split('\\');
		document.getElementById(dylebel).innerHTML = theSplit[theSplit.length-1];
    }
};
</script>