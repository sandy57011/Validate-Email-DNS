<?php
@session_start();
$characters = 5;
$possible = '0123456789';

		$code = '';

		$i = 0;

		while ($i < $characters) { 

			$code .= substr($possible, mt_rand(0, strlen($possible)-1), 1);

			$i++;

		}

		$ranStr = $code;
$_SESSION['cap_code'] = $ranStr;
$newImage = imagecreatefromjpeg("cap_bg.jpg");
$txtColor = imagecolorallocate($newImage, 0, 0, 0);
imagestring($newImage, 5, 5, 5, $ranStr, $txtColor);
header("Content-type: image/jpeg");
imagejpeg($newImage);
?>


