<?php
include("../include/resizeimage.php");
?>
<?php
if(isset($_REQUEST['Add']) && $_REQUEST['Add']=="Add Five Point") {

/*****************************   Plus Images Upload Start  *************************************/

foreach($_FILES['imagefilename']['tmp_name'] as $key => $tmp_name )
{
    if(is_uploaded_file($_FILES['imagefilename']['tmp_name'][$key]))
	{
	  $intFile=mt_rand();    
	          if($_FILES["imagefilename"]["name"][$key]!="")
	          {
 						move_uploaded_file($_FILES["imagefilename"]["tmp_name"][$key],"../adminimg/fivepoint/".$intFile.$_FILES["imagefilename"]["name"][$key]);
				        $fileUploadgalimgFileName[]=$intFile.$_FILES["imagefilename"]["name"][$key];
						$fileUploadgalimgFileNamethumb=$intFile.$_FILES["imagefilename"]["name"][$key];
						$thumb=generateThumb($fileUploadgalimgFileNamethumb,"../adminimg/fivepoint/","../adminimg/fivepoint/",800,800);	
				}
				else
				    {
					//$fileUploadgalimgFileName[]=$_REQUEST[ExistGalImage];
			        }
	    
    }   ///////////////////  End if is uploaded //////////////
	
}  ////////////  End foreach function ////////////////

/***************************    Plus Images Upload End  ********************************/

/*****************************************************/
//$catpid = getProductParentCategoryByCatId($_REQUEST[cat_id]);

   $res=mysql_query("insert into tbl_fivepoint set heading = '".addslashes($_REQUEST['heading'])."', 
   description = '".addslashes($_REQUEST['description'])."',
   embd_video = '".$_REQUEST['embd_video']."', 
   status = '1'");
   
   $inspid = mysql_insert_id();
   
for($i = 0; $i < sizeof($fileUploadgalimgFileName); $i++) { 
			$query =mysql_query("INSERT INTO tbl_fivepointicons set imagefilename ='".$fileUploadgalimgFileName[$i]."', p_id = '".$inspid."'") or die(mysql_error());
		}   	
   header("location:home.php?PageURL=manage_fivepoint");
}
?>
<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
<script type="text/javascript" src="ckfinder/ckfinder.js"></script>
<link href="images/class.css" rel="stylesheet" type="text/css">
<link href="css/custom.css" rel="stylesheet">

<form name="frmadd" id="frmadd" method="post" ENCTYPE="multipart/form-data">
<input type="hidden" name="hdn" value="1">
<input type="hidden" name="cat_id" id="cat_id" value="<?php echo $_REQUEST['cat_id']; ?>">
<input type="hidden" name="hdnh" value="1">
  
  
<h1>Add Five point</h1>
<table width="100%" border="0" align="center" cellpadding="3" cellspacing="1">
  <tr> 
    <td height="10" colspan=3 ></td>
  </tr>
 
    <?
	if($MSG) { ?>
    <TR align="center"> 
      <TD colspan=3> <?echo "<font color='#FF3366'>".$MSG."</font>"; ?> </TD>
    </TR>
    <? } ?>
	<TR>
      <TD width="9%" align=left valign="middle" class="text">Heading</TD>
      <TD width="3%" align="left"><strong>:</strong></TD>
      <TD width="88%" align="left"><input name="heading" type="text" class="TextBox" id="heading" value="" required/></TD>
    </TR>
     <TR>
      <TD align=left valign="top" class="text"> Description</TD>
      <TD align="left" valign="top" class="text"><strong>:</strong></TD>
      <TD align="left"><span class="text">
        
        <textarea id="description" name="description" style="width:140px;"></textarea>
      </span></TD>
    </TR>
   <script type="text/javascript">		
		var editor = CKEDITOR.replace( 'description',{ customConfig : '<?=$rootpath?>/ckeditor/configcms.js' } );
		CKFinder.SetupCKEditor( editor, '<?=$rootpath?>/ckfinder/' ) ;
   </script>
    <TR>
      <TD align=left valign="top" class="text">Video Link</TD>
      <TD align="left" valign="top" class="text"><strong>:</strong></TD>
      <TD align="left"><span class="text">
        <input name="embd_video" type="text" class="TextBox" id="embd_video" value=""/>
      </span></TD>
    </TR>
    <TR> 
      <TD height=35 align=left valign="top" class="text">Icon </TD>
      <TD align=left valign="top" class="text"><strong>:</strong></TD>
      <TD height=35 align=left valign="top" class="text">
    <div class="btn-file">
    <label id="fileLabel0">Click to Upload Image </label><input name="imagefilename[]" id="imagefilename0" type="file" onChange="pressedimage('0')">
    </div></TD>
    </TR>    
	<TR> 
      <TD height=0 align=left valign="top" class="text">&nbsp;</TD>
      <TD align=left valign="top" class="text">&nbsp;</TD>
      <TD height=0 align=left valign="top" class="text">
      
      <div id="addimagediv"></div></TD>
    </TR>
    
         <input type="hidden" value="0" id="theValueItemImage" />
    
	<TR> 
      <TD height=0 align=left valign="top" class="text">&nbsp;</TD>
      <TD align=left valign="top" class="text">&nbsp;</TD>
      <TD height=0 align=left valign="top" class="text"><a href="javascript:void(0);" onClick="addmoreimage()">Add+</a></TD>
    </TR>   
    <TR align="center"> 
      <TD height=50 align="left">&nbsp;</TD>
      <TD height=50 align="left">&nbsp;</TD>
      <TD height=50 align="left"> <input type="submit" name="Add" value="Add Five Point">
	  
	  &nbsp;&nbsp;&nbsp;&nbsp;<input id="btnBack2" class="button1" type="button" value=" Back " onClick="javascript:history.back(-1)" name="Back"/>      </TD>
    </TR>
</TABLE>
</form>
<script language="JavaScript" type="text/javascript">

function validate()
{
if(document.frmAdd.procity.value=="")
{
	alert("Please Select City");
	document.frmAdd.procity.focus();
	return false;
}
if(document.frmAdd.prolocation.value=="")
{
	alert("Please Select locality");
	document.frmAdd.prolocation.focus();
	return false;
}
	
if(document.frmAdd.sub_name.value=="")
{
	alert("Name field can't be blank");
	document.frmAdd.sub_name.focus();
	return false;
}
  
}
</script>
<script>
function loadmorecitykeyword() {
var categoryid =  <?php echo $_REQUEST['sub_id']; ?>;
				$.post('morecitykeywordlocdivbyclick.php', {'categoryid': categoryid}, function(data){
									
				$("#morecitykeywordlocdiv").append(data); //append received data into the element

	});
}
</script>

<script>
function loadmorecitykeyword12(str) {
//alert(str);
var catcityid123 =  str;

				$.post('localitydivupdat.php?cct='+str, {'catcityid123': catcityid123}, function(data){
									
				//$("#citydiv").append(data); //append received data into the element
				//$("#citydiv12").replaceWith(data); //append received data into the element
				//$("#citydiv12").html(data); //append received data into the element

	});
}
</script>
<script>
function changeimagesrc(str,str1) {
	 image = document.getElementById(str);
     image.src = "";
	 document.getElementById(str1).value="";
}
</script>
<script>
window.pressedimage = function(numstr)
{	
//alert(numstr);

    var dylebel = 'fileLabel'+numstr;
	var dyimg = 'imagefilename'+numstr;

var ggllb = dyimg;
var imgpathBanner = document.getElementById(ggllb).value;
//var fsize = $('#imgfile1')[0].files[0].size;
var fsize = document.getElementById(ggllb).files[0].size;
//var fsize = $('#galimg')[0].files[0].size;
if(fsize>1048576*2) {
document.getElementById(ggllb).value = "";
alert('Upload File Size Must be < 2 MB');
return false;
}
if(imgpathBanner!="") {
var arr1 = new Array;
arr1 = imgpathBanner.split("\\");
var len = arr1.length;
var img1 = arr1[len-1];
var filext = img1.substring(img1.lastIndexOf(".")+1);
// Checking Extension
var filext = filext.toLowerCase();
if(filext != "jpg" && filext != "JPG" && filext != "JPEG" && filext != "JPEG" && filext != "gif" && filext != "GIF" && filext != "png" && filext != "PNG")
{
document.getElementById(ggllb).value = "";
alert("Invalid File Format Selected");
document.frmadd.ggllb.focus();
return false;
}
}
    var a = document.getElementById(ggllb);
    if(a.value == "")
    {
		document.getElementById(dylebel).innerHTML = "";
    }
    else
    {
        var theSplit = a.value.split('\\');
		document.getElementById(dylebel).innerHTML = theSplit[theSplit.length-1];
    }
};
</script>
<script>
function addmoreimage() {

 //var ni = document.getElementById('myDivItem');

  var numi = document.getElementById('theValueItemImage');

  var num = (document.getElementById('theValueItemImage').value -1)+ 2;
  numi.value = num;

  var remo = document.getElementsByName('imagefilename[]'); 
  var remolen  = remo.length;
 
//alert(remolen);

 
  var dvid= parseInt(num);
 
  var count =num;

var dataString = 'remolen=' + remolen;
		//alert(dataString);
			$.ajax({
			type: "POST",
			url: "plusimages.php",
			//url: "12.php",
			data: dataString,
			success: function(theResponse)
			{
			var result=theResponse;
			//alert(result);
			$('#addimagediv').append(result);
			if(result>0 && result==9) {

			}
			if(result<0 && result==-1) {
	
			}
			}
			
			});
	
}
</script>
<script>
function remove_meNleft(str) {
var rmvdiv = 'imageremovediv'+str;
var elem = document.getElementById(rmvdiv);
elem.remove();
}
</script>
<script>
function addmoreimagepricerate() {
//var ni = document.getElementById('myDivItem');

  var numi = document.getElementById('theValueItemImagePriceRate');

  var num = (document.getElementById('theValueItemImagePriceRate').value -1)+ 2;
  numi.value = num;

  var remo = document.getElementsByName('price_name[]'); 
  var remolen  = remo.length;
 
//alert(remolen);
 
  var dvid= parseInt(num);
 
  var count =num;

var dataString = 'remolen=' + remolen;
		//alert(dataString);
			$.ajax({
			type: "POST",
			url: "pluspricerate.php",
			//url: "12.php",
			data: dataString,
			success: function(theResponse)
			{
			var result=theResponse;
			//alert(result);
			$('#addimagedivpricerate').append(result);
			if(result>0 && result==9) {

			}
			if(result<0 && result==-1) {
	
			}
			}
			
			});

}
</script>
<script>
function remove_meNleftrate(str) {
var rmvdiv = 'imageremovedivlerate'+str;
var elem = document.getElementById(rmvdiv);
elem.remove();
}
</script>
<script>

//function validatedate(inputText)  
function validatedate()  
  {
  //alert();
  var vdd = document.getElementById('dd').value;
  var vmm = document.getElementById('mm').value;
  var vyy = document.getElementById('yy').value;
	
  var valldate = vmm+'-'+vdd+'-'+vyy;	  
	//alert(valldate);
  var inputText =  valldate;
  var dateformat = /^(0?[1-9]|1[012])[\/\-](0?[1-9]|[12][0-9]|3[01])[\/\-]\d{4}$/;  
  // Match the date format through regular expression  
  //if(inputText.value.match(dateformat))  
  if(inputText.match(dateformat))  
  {  
  //document.form1.text1.focus();  
  //Test which seperator is used '/' or '-'  
  var opera1 = inputText.split('/');  
  var opera2 = inputText.split('-');  
  lopera1 = opera1.length;  
  lopera2 = opera2.length;  
  // Extract the string into month, date and year  
  if (lopera1>1)  
  {  
  var pdate = inputText.split('/');  
  }  
  else if (lopera2>1)  
  {  
  var pdate = inputText.split('-');  
  }  
  var mm  = parseInt(pdate[0]);  
  var dd = parseInt(pdate[1]);  
  var yy = parseInt(pdate[2]);  
  // Create list of days of a month [assume there is no leap year by default]  
  var ListofDays = [31,28,31,30,31,30,31,31,30,31,30,31];  
  if (mm==1 || mm>2)  
  {  
  if (dd>ListofDays[mm-1])  
  {  
  alert('Invalid date format!');  
  document.getElementById('dd').selectedIndex="00";
  document.getElementById('mm').selectedIndex="00";
  return false;  
  }  
  }  
  if (mm==2)  
  {  
  var lyear = false;  
  if ( (!(yy % 4) && yy % 100) || !(yy % 400))   
  {  
  lyear = true;  
  }  
  if ((lyear==false) && (dd>=29))  
  {  
  alert('Invalid date format!'); 
    document.getElementById('dd').selectedIndex="00";
  document.getElementById('mm').selectedIndex="00"; 
  return false;  
  }  
  if ((lyear==true) && (dd>29))  
  {  
  alert('Invalid date format!'); 
  document.getElementById('dd').selectedIndex="00";
  document.getElementById('mm').selectedIndex="00"; 
  return false;  
  }  
  }  
  }  
  else  
  {  
  document.getElementById('dd').selectedIndex="00";
  document.getElementById('mm').selectedIndex="00";
  alert("Invalid date format!");  
  document.form1.dd.focus();  
  return false;  
  }  
  }  
</script>
