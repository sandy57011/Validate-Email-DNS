 <?php
if(isset($_REQUEST['save']) && $_REQUEST['save']=='Update')
{
$pwd1 = md5(trim($_POST['pwd1']));
mysql_query("update tbl_users set user_password = '".$pwd1."' where user_id = '1'") or die(mysql_error());
echo "Password Succesfully Changed";
}
?>
<link href="images/class.css" rel="stylesheet" type="text/css">
<h1>Change Password</h1>
 <form name="form " id="form" method="post" action="" enctype="multipart/form-data" onsubmit="return checkForm(this);">
<table width="100%" border="0" cellpadding="0" cellspacing="3" class="table2"  >
	<tr>
    	<td width="13%">New Password</td>
    	<td width="4%">:</td>
        <td width="83%"><input name="pwd1" type="password" class="txtbox1" id="pwd1" value="" /></td>
    </tr>
    <tr>
    	<td>Confirm Password</td>
    	<td>:</td>
        <td><input name="pwd2" type="password" class="txtbox1" id="pwd2" value="" /></td>
    </tr>
    <tr>
    	<td align="right">&nbsp;</td>
    	<td>&nbsp;</td>
        <td><input name="save" type="submit" class="btn1" value="Update"></td>
    </tr>
    <tr>
      <td colspan="3" align="center">&nbsp;</td>
    </tr>
    <tr>
    	<td colspan="3" align="center">at least one number, one lowercase and one uppercase letter<br />at least six characters that are letters, numbers or the underscore</td>
    </tr>
</table>
</form>	
<script type="text/javascript">
// at least one number, one lowercase and one uppercase letter
// at least six characters that are letters, numbers or the underscore
function checkPassword(str) { 
	var re = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}$/;
	return re.test(str); 
	} 
	function checkForm(form) { 

	if(form.pwd1.value != "" && form.pwd1.value == form.pwd2.value) { 
	if(!checkPassword(form.pwd1.value)) { 
		alert("The password you have entered is not valid!");
		form.pwd1.focus();
			return false;
		} 
	} else { 
			alert("Error: Please check that you've entered and confirmed your password!"); 
			form.pwd1.focus();
				return false;
		} 
			return true;
			}
 </script>
    