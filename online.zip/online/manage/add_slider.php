<?php
include("../include/resizeimage.php");
?>
<?php
if(isset($_REQUEST[Submit]) && $_REQUEST['Submit']=="Add")
{
/*****************************************/
if($_FILES["galimg"]["name"]!="") {
 		       			$intFile2=mt_rand();
			            move_uploaded_file($_FILES["galimg"]["tmp_name"],"../adminimg/slider/".$intFile2.$_FILES["galimg"]["name"]);
		                $fileUploadgalimgFileName=$intFile2.$_FILES["galimg"]["name"];
						$thumb1=generateThumb($fileUploadgalimgFileName,"../adminimg/slider/","../adminimg/slider/",1440,1440);

			   
	} else {
			  $fileUploadgalimgFileName = "";
		   }
		   
if($_FILES["galimgsmall"]["name"]!="") {
 		       			$intFile2=mt_rand();
			            move_uploaded_file($_FILES["galimgsmall"]["tmp_name"],"../adminimg/slider/".$intFile2.$_FILES["galimgsmall"]["name"]);
		                $fileUploadgalimgFileName1=$intFile2.$_FILES["galimgsmall"]["name"];
						$thumb1=generateThumb($fileUploadgalimgFileName1,"../adminimg/slider/","../adminimg/slider/",400,400);

			   
	} else {
			  $fileUploadgalimgFileName1 = "";
		   }		   

                                         

	$query =mysql_query("insert into slider set slider_name='".addslashes($_POST['slider_name'])."' , slider_name1 ='".addslashes($_POST['slider_name1'])."', slider_descrip ='".addslashes($_POST['slider_descrip'])."' , slider_imagefile1 ='".$fileUploadgalimgFileName."', slider_imagefile2 ='".$fileUploadgalimgFileName1."', titletag = '".$_POST['titletag']."', alttag = '".$_POST['alttag']."'" ) or die(mysql_error());

	
   
   header("location:home.php?PageURL=manage_slider");
 
}
?>
   
    <style type="text/css">
.bs-example{
	font-family: sans-serif;
	position: relative;
	margin: 50px;
}
.typeahead, .tt-query, .tt-hint {
	border: 2px solid #CCCCCC;
	border-radius: 8px;
	font-size: 14px;
	height: 30px;
	line-height: 30px;
	outline: medium none;
	padding: 4px 4px;
	width: 250px;
	
}
.typeahead {
	background-color: #FFFFFF;
}
.typeahead:focus {
	border: 2px solid #0097CF;
}
.tt-query {
	box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset;
}
.tt-hint {
	color: #999999;
}
.tt-dropdown-menu {
	background-color: #FFFFFF;
	border: 1px solid rgba(0, 0, 0, 0.2);
	border-radius: 8px;
	box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
	margin-top: 12px;
	padding: 8px 0;
	width: 422px;
}
.tt-suggestion {
	font-size: 14px;
	line-height: 24px;
	padding: 3px 20px;
}
.tt-suggestion.tt-is-under-cursor {
	background-color: #0097CF;
	color: #FFFFFF;
}
.tt-suggestion p {
	margin: 0;
}
</style>
<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
<script type="text/javascript" src="ckfinder/ckfinder.js"></script>
<link href="images/class.css" rel="stylesheet" type="text/css">
<link href="css/custom.css" rel="stylesheet">

<form name="frmcontents" method="post" action="" enctype="multipart/form-data">
<table width="100%" border="0" cellpadding="0" cellspacing="0">

 <tr>
 <td><h1>Add Banner (Size:1440px X 400px)</h1></td>
 </tr>
  <tr>
    <td  align="left">
<? if($msg==1){ echo "<font color=red>".$_REQUEST[title] ." page content is update.</font>"; $msg=0;}elseif($msg==2){ echo "<font color=red>".$_REQUEST[title] ." page  is add.</font>";$msg=0;}elseif($msg==3){ echo "<font color=red>".$_REQUEST[title] ." page  is deleted.</font>";$msg=0;}?></td>
  </tr><tr>
 <td align="left">    </td>
    </tr>
    <tr>
          <td align="left">Heading 1:</td>
        </tr>
  <tr>
    <td align="left" valign="middle">
<input type="text" name="slider_name" id="slider_name" value="" />
    </td>
    </tr>
    <tr>
          <td align="left">&nbsp;</td>
        </tr>   
    <tr>
      <td align="left" valign="middle">
      <br><br>
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="26%">Banner Image (Size:1440px X 400px):</td>
          <!--<td width="26%">Title Tag:</td>
          <td width="26%">Alt Tag:</td>-->
          
        </tr>
        <tr>
          <td>
    <div class="btn-file">
     <label id="fileLabel">Click to Upload Image</label><input name="galimg" id="galimg" type="file" onchange="pressed()" />
    </div> 
              
          </td>
        </tr>
      </table><br><br>
      
      </td>
    </tr>
<!--<tr>
      <td align="left" valign="middle">      
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="26%">Banner Small Image (400 X 260 px):</td>         
        </tr>
        <tr>
          <td>
    <div class="btn-file">
     <label id="fileLabelsmall">Click to Upload Image</label><input name="galimgsmall" id="galimgsmall" type="file" onchange="pressedsmall()" />
    </div> 
              
          </td>
        
        </tr>
      </table>
      
      </td>
    </tr>  -->  
  <tr>
    <td align="left" valign="middle">&nbsp;</td>
    </tr>
	 &nbsp;

  <tr>
    <td><input type="submit" name="Submit" value="Add" class="btn1">&nbsp;&nbsp;
    <input type="button" name="back" id="back" value="Back" class="btn1" onclick="location.href='home.php?PageURL=manage_slider'">
      <input name="hdn" type="hidden" id="hdn" value="1"></td>
  </tr>

</table>
</form>

<script language="javascript">
window.pressed = function()
{
var ggllb = 'galimg';
var imgpathBanner = document.getElementById(ggllb).value;
var fsize = $('#galimg')[0].files[0].size;
//var fsize = $('#galimg')[0].files[0].size;
if(fsize>1048576*2) {
alert('Upload File Size Must be < 2 MB');
return false;
}
if(imgpathBanner!="") {
var arr1 = new Array;
arr1 = imgpathBanner.split("\\");
var len = arr1.length;
var img1 = arr1[len-1];
var filext = img1.substring(img1.lastIndexOf(".")+1);
// Checking Extension
var filext = filext.toLowerCase();
if(filext != "jpg" && filext != "JPG" && filext != "JPEG" && filext != "JPEG" && filext != "gif" && filext != "GIF" && filext != "png" && filext != "PNG")
{
alert("Invalid File Format Selected");
document.form1.imgfile.focus();
return false;
}
}
    var a = document.getElementById('galimg');
    if(a.value == "")
    {
        //fileLabel.innerHTML = "";
		document.getElementById('fileLabel').innerHTML = "";
    }
    else
    {
        var theSplit = a.value.split('\\');
		//alert(theSplit);
        //fileLabel.innerHTML = theSplit[theSplit.length-1];
		document.getElementById('fileLabel').innerHTML = theSplit[theSplit.length-1];
    }			

}
</script>

<script language="javascript">
window.pressedsmall = function()
{
var ggllb = 'galimgsmall';
var imgpathBanner = document.getElementById(ggllb).value;
var fsize = $('#galimgsmall')[0].files[0].size;
//var fsize = $('#galimg')[0].files[0].size;
if(fsize>1048576*2) {
alert('Upload File Size Must be < 2 MB');
return false;
}
if(imgpathBanner!="") {
var arr1 = new Array;
arr1 = imgpathBanner.split("\\");
var len = arr1.length;
var img1 = arr1[len-1];
var filext = img1.substring(img1.lastIndexOf(".")+1);
// Checking Extension
var filext = filext.toLowerCase();
if(filext != "jpg" && filext != "JPG" && filext != "JPEG" && filext != "JPEG" && filext != "gif" && filext != "GIF" && filext != "png" && filext != "PNG")
{
alert("Invalid File Format Selected");
document.form1.imgfile.focus();
return false;
}
}
    var a = document.getElementById('galimgsmall');
    if(a.value == "")
    {
        //fileLabel.innerHTML = "";
		document.getElementById('fileLabelsmall').innerHTML = "";
    }
    else
    {
        var theSplit = a.value.split('\\');
		//alert(theSplit);
        //fileLabel.innerHTML = theSplit[theSplit.length-1];
		document.getElementById('fileLabelsmall').innerHTML = theSplit[theSplit.length-1];
    }			

}
</script>
