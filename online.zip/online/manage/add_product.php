<?php
include("../include/resizeimage.php");
?>
<?php
if(isset($_REQUEST['Add']) && $_REQUEST['Add']=="Add Product") {


if($_FILES["imagefilenamelogo"]["name"]!=""){
	$intFile=mt_rand();
	move_uploaded_file($_FILES["imagefilenamelogo"]["tmp_name"],"../adminimg/logoimg/".$intFile.$_FILES["imagefilenamelogo"]["name"]);
	$filelogoimg=$intFile.$_FILES["imagefilenamelogo"]["name"];
	$thumb=generateThumb($filelogoimg,"../adminimg/logoimg/","../adminimg/logoimg/",800,800);
} else {
	$filelogoimg="";
}

if($_FILES["imagefilenameorigin"]["name"]!=""){
	$intFile=mt_rand();
	move_uploaded_file($_FILES["imagefilenameorigin"]["tmp_name"],"../adminimg/originimg/".$intFile.$_FILES["imagefilenameorigin"]["name"]);
	$fileoriginimg=$intFile.$_FILES["imagefilenameorigin"]["name"];
	$thumb=generateThumb($fileoriginimg,"../adminimg/originimg/","../adminimg/originimg/",800,800);
} else {
	$fileoriginimg="";
}

/*****************************   Plus Certification Images Upload Start  *************************************/

foreach($_FILES['imagefilenamecertification']['tmp_name'] as $key => $tmp_name )
{
    if(is_uploaded_file($_FILES['imagefilenamecertification']['tmp_name'][$key]))
	{
	  $intFile=mt_rand();    
	          if($_FILES["imagefilenamecertification"]["name"][$key]!="")
	          {
 						move_uploaded_file($_FILES["imagefilenamecertification"]["tmp_name"][$key],"../adminimg/certification/".$intFile.$_FILES["imagefilenamecertification"]["name"][$key]);
				        $fileUploadgalimgFileNamecertification[]=$intFile.$_FILES["imagefilenamecertification"]["name"][$key];
						$fileUploadgalimgFileNamethumb=$intFile.$_FILES["imagefilenamecertification"]["name"][$key];
						$thumb=generateThumb($fileUploadgalimgFileNamethumb,"../adminimg/certification/","../adminimg/certification/",800,800);	
				}
				else
				    {
					//$fileUploadgalimgFileName[]=$_REQUEST[ExistGalImage];
			        }
	    
    }   ///////////////////  End if is uploaded //////////////
	
}  ////////////  End foreach function ////////////////

/***************************    Plus Certification Upload End  ********************************/

/*****************************   Plus Images Upload Start  *************************************/

foreach($_FILES['imagefilename']['tmp_name'] as $key => $tmp_name )
{
    if(is_uploaded_file($_FILES['imagefilename']['tmp_name'][$key]))
	{
	  $intFile=mt_rand();    
	          if($_FILES["imagefilename"]["name"][$key]!="")
	          {
 						move_uploaded_file($_FILES["imagefilename"]["tmp_name"][$key],"../adminimg/galimg/".$intFile.$_FILES["imagefilename"]["name"][$key]);
				        $fileUploadgalimgFileName[]=$intFile.$_FILES["imagefilename"]["name"][$key];
						$fileUploadgalimgFileNamethumb=$intFile.$_FILES["imagefilename"]["name"][$key];
						$thumb=generateThumb($fileUploadgalimgFileNamethumb,"../adminimg/galimg/","../adminimg/galimg/",800,800);	
				}
				else
				    {
					//$fileUploadgalimgFileName[]=$_REQUEST[ExistGalImage];
			        }
	    
    }   ///////////////////  End if is uploaded //////////////
	
}  ////////////  End foreach function ////////////////

/***************************    Plus Images Upload End  ********************************/

/*****************************************************/
//$catpid = getProductParentCategoryByCatId($_REQUEST[cat_id]);
		$date_dd = $_REQUEST[dd];
		$date_mm = $_REQUEST[mm];
		$date_yy = $_REQUEST[yy];
		$date_dob = $date_yy."-".$date_mm."-".$date_dd;

   $productname = addslashes($_REQUEST['productname']);
   //$urlname = makeurlnamebyname($productname);
   $urlname = makeurlnamebynameProduct($productname);
   $res=mysql_query("insert into tbl_products set cat_id = '".$_REQUEST[cat_id]."', 
   productname = '".$productname."', 
   detail = '".strip_tags($_REQUEST['detail'])."', 
   instock = '".$_REQUEST['instock']."', 
   newarrival = '".$_REQUEST['newarrival']."',
   showinbulk = '".$_REQUEST['showinbulk']."',
   deliverytime = '".$_REQUEST['deliverytime']."', 
   productdescription = '".addslashes($_REQUEST['productdescription'])."', 
   logoimg = '".$filelogoimg."', 
   productpriceinr = '".strip_tags($_REQUEST[productpriceinr])."',
   productpricedollar = '".strip_tags($_REQUEST[productpricedollar])."',
   productpricedescr = '".strip_tags($_REQUEST[productpricedescr])."',
   productpricepercupinr = '".$_REQUEST[productpricepercupinr]."', 
   productpricepercupdollor = '".$_REQUEST[productpricepercupdollor]."', 
   productsku = '".strip_tags($_REQUEST[productsku])."', 
   productgrade = '".strip_tags($_REQUEST[productgrade])."', 
   productpicking = '".$date_dob."', 
   productinvoice = '".strip_tags($_REQUEST[productinvoice])."', 
   productspecial = '".strip_tags($_REQUEST[productspecial])."', 
   productelevation = '".strip_tags($_REQUEST[productelevation])."', 
   pwater = '".strip_tags($_REQUEST[pwater])."', 
   pfire = '".strip_tags($_REQUEST[pfire])."', 
   ptime = '".strip_tags($_REQUEST[ptime])."', 
   pleaves = '".strip_tags($_REQUEST[pleaves])."', 
   pcaffeine = '".strip_tags($_REQUEST[pcaffeine])."',  
   testing_colordryleaf = '".strip_tags($_REQUEST[testing_colordryleaf])."', 
   testing_colorinfusion = '".strip_tags($_REQUEST[testing_colorinfusion])."', 
   testing_colorliquor = '".strip_tags($_REQUEST[testing_colorliquor])."', 
   testing_aromadryleaf = '".strip_tags($_REQUEST[testing_aromadryleaf])."', 
   testing_aromainfusion = '".strip_tags($_REQUEST[testing_aromainfusion])."', 
   testing_aromaliquor = '".strip_tags($_REQUEST[testing_aromaliquor])."', 
   testing_tastedryleaf = '".strip_tags($_REQUEST[testing_tastedryleaf])."', 
   testing_tasteinfusion = '".strip_tags($_REQUEST[testing_tasteinfusion])."', 
   testing_tasteliquor = '".strip_tags($_REQUEST[testing_tasteliquor])."', 
   testing_finishdryleaf = '".strip_tags($_REQUEST[testing_finishdryleaf])."', 
   testing_finishinfusion = '".strip_tags($_REQUEST[testing_finishinfusion])."', 
   testing_finishliquor = '".strip_tags($_REQUEST[testing_finishliquor])."', 
   imagefilenameorigin = '".$fileoriginimg."', 
   non_veg = '".(int)($_REQUEST[non_veg])."',
   origin_description = '".strip_tags($_REQUEST[origin_description])."',
   urlname = '".$urlname."',     
   status = '1'");
   
   $inspid = mysql_insert_id();
   
for($i = 0; $i < sizeof($fileUploadgalimgFileName); $i++) { 
			$query =mysql_query("INSERT INTO tbl_product_galimage set imagefilename ='".$fileUploadgalimgFileName[$i]."', p_id = '".$inspid."'") or die(mysql_error());
		} 
		
for($i = 0; $i < sizeof($fileUploadgalimgFileNamecertification); $i++) { 
			$query =mysql_query("INSERT INTO tbl_product_certificationimage set imagefilename ='".$fileUploadgalimgFileNamecertification[$i]."', p_id = '".$inspid."'") or die(mysql_error());
		} 		  
   
	$price_name = $_POST['price_name'];  
    $price_inr = $_POST['price_inr'];
	$price_dollar = $_POST['price_dollar'];
	$pricecup_inr = $_POST['pricecup_inr'];
	$pricecup_dollar = $_POST['pricecup_dollar'];
	
for($i = 0; $i < sizeof($price_name); $i++) { 
			$query =mysql_query("INSERT INTO tbl_productprice_rate set price_name ='".$price_name[$i]."', price_inr ='".$price_inr[$i]."', price_dollar ='".$price_dollar[$i]."', pricecup_inr ='".$pricecup_inr[$i]."', pricecup_dollar ='".$pricecup_dollar[$i]."', p_id = '".$inspid."'") or die(mysql_error());
		} 
		
	$price_nameBulk = $_POST['price_nameBulk'];  
    $price_inrBulk = $_POST['price_inrBulk'];
	$price_dollarBulk = $_POST['price_dollarBulk'];
	$pricecup_inrBulk = $_POST['pricecup_inrBulk'];
	$pricecup_dollarBulk = $_POST['pricecup_dollarBulk'];
	
for($i = 0; $i < sizeof($price_nameBulk); $i++) { 
			$query =mysql_query("INSERT INTO tbl_productprice_rateBulk set price_name ='".$price_nameBulk[$i]."', price_inr ='".$price_inrBulk[$i]."', price_dollar ='".$price_dollarBulk[$i]."', pricecup_inr ='".$pricecup_inrBulk[$i]."', pricecup_dollar ='".$pricecup_dollarBulk[$i]."', p_id = '".$inspid."'") or die(mysql_error());
		} 		 	
	
   header("location:home.php?PageURL=manage_products&cat_id=$_REQUEST[cat_id]");
}
?>
<?php
$sqlProductRow = mysql_fetch_array(mysql_query("select * from tbl_products where id='1'")); 
//echo $sqlProductRow['productpriceinr'];
?>
<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
<script type="text/javascript" src="ckfinder/ckfinder.js"></script>
<link href="images/class.css" rel="stylesheet" type="text/css">
<link href="css/custom.css" rel="stylesheet">

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
<script src="../select-menu/jquery.sumoselect.min.js"></script>
<link href="../select-menu/sumoselect.css" rel="stylesheet" />

<script type="text/javascript">
$jq123 = $.noConflict();
        $jq123(document).ready(function () {
            window.asd = $jq123('.SlectBox').SumoSelect({ csvDispCount: 3 });
            window.test = $jq123('.testsel').SumoSelect({okCancelInMulti:true });
        });
</script>

<link href="../SpryAssets/SpryTabbedPanels.css" rel="stylesheet" type="text/css" />
<script src="../SpryAssets/SpryTabbedPanels.js" type="text/javascript"></script>

<form name="frmadd" id="frmadd" method="post" ENCTYPE="multipart/form-data">
<input type="hidden" name="hdn" value="1">
<input type="hidden" name="cat_id" id="cat_id" value="<?php echo $_REQUEST['cat_id']; ?>">
<input type="hidden" name="hdnh" value="1">
  
  
<h1>Add Product in: <label><?php echo getProductCategorynameById($_REQUEST[cat_id]); ?></label></h1>
<table width="100%" border="0" align="center" cellpadding="3" cellspacing="1">
  <tr> 
    <td height="10" ></td>
  </tr>
 
    <?
	if($MSG) { ?>
    <TR align="center"> 
      <TD> <?echo "<font color='#FF3366'>".$MSG."</font>"; ?> </TD>
    </TR>
    <? } ?>

	<TR>
	  <TD>
     <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="33%"><input name="productname" type="text" id="productname" value="" placeholder="Product Name" required/></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>

      </TD>
    </TR>

	<TR>
	  <TD class="text">&nbsp;</TD>
    </TR>
	<TR>
	  <TD class="text"><h4>Price Manage</h4>
	    <table width="100%" border="0" cellspacing="0" cellpadding="0">
	      <tr>
	        <td>
                <input name="productpricedescr" type="text" id="productpricedescr" placeholder="Description"/>
            </td>
	        <td>
	          <input name="productpriceinr" type="text"  id="productpriceinr" placeholder="Price (INR)"/>
           </td>
	        <td>
	          &nbsp;
            </td>
	        <td>
	          <input name="productpricepercupinr" type="text" id="productpricepercupinr" placeholder="Price Per Ratti"/>
          </td>
	        <td>&nbsp;</td>
          </tr>
      </table></TD>
    </TR>
	<TR>
	  <TD>
      <table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
    	<td><input type="text" name="price_name[]" id="price_name" placeholder="Description" /></td>
        <td><input type="text" name="price_inr[]" id="price_inr" placeholder="Price (INR)" /></td>
        <td>&nbsp;</td>
        <td><input type="text" name="pricecup_inr[]" id="pricecup_inr" placeholder="Price Per Ratti" /></td>
        <td>&nbsp;</td>
    </tr>    
</table>
      </TD>
    </TR>
	<TR>
	  <TD><div id="addimagedivpricerate"></div></TD>
    </TR>
    <input type="hidden" value="0" id="theValueItemImagePriceRate" />
	<TR>
      <TD><a href="javascript:void(0);" onClick="addmoreimagepricerate()">Add more Price +</a></TD>
    </TR>
    <TR>
      <TD>&nbsp;</TD>
    </TR>

    <TR>
      <TD><table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td>Stock Available: <input type="checkbox" name="instock" id="instock" value="1"></td>
          <td>New Arrival: <input type="checkbox" name="newarrival" id="newarrival" value="1"></td>
          <td>&nbsp;</td>
          <td><input name="deliverytime" type="text" class="TextBox" id="deliverytime" placeholder="Est. Delivery Time:"/></td>
        </tr>
      </table></TD>
    </TR>
    <TR>
      <TD>&nbsp;</TD>
    </TR>
   <TR>
      <TD align="left"><h4>
        
        Veg or Non-Veg
        </h4>
        <select name="non_veg" class="form-control">
            <option selected value="0">Veg</option>
            <option  value="1">Non - Veg</option></select>
      </TD>
    </TR>
     <TR>
      <TD>&nbsp;</TD>
    </TR>      
 
     <TR>
      <TD align="left"><h4 class="text">
        
        Product Description
        </h4>
        <p class="text">
          <textarea id="productdescription" name="productdescription" style="width:140px;"></textarea>
       </p></TD>
    </TR>
   <script type="text/javascript">		
		var editor = CKEDITOR.replace( 'productdescription',{ customConfig : '<?=$rootpath?>/ckeditor/configcms.js' } );
		CKFinder.SetupCKEditor( editor, '<?=$rootpath?>/ckfinder/' ) ;
   </script>
   

    <TR>
      <TD align="left">&nbsp;</TD>
    </TR>

      <TD valign="top">
      <div class="grid_6">
      <h4>Product Images:</h4>
      <table width="100%" border="0" cellpadding="0" cellspacing="0">
      <TR> 
      <TD >
        
        <div class="btn-file">
          <label id="fileLabellogo">Click to Upload Image </label><input name="imagefilenamelogo" id="imagefilenamelogo" type="file" onchange="pressedimage('logo')">
        </div>      
      </TD>
    </TR>    
	<TR> 
      <TD>       
        <div id="addimagediv"></div>
        
      </TD>
    </TR>
    
         <input type="hidden" value="0" id="theValueItemImage" />
    
	<TR> 
      <TD height=0 align=left valign="top" class="text"><a href="javascript:void(0);" onClick="addmoreimage()">Add more +</a></TD>
    </TR> 
      </table>
      </div>
      
      
      </TD>
    </TR>
      
    <TR align="center"> 
      <TD height=50 align="left"> <input type="submit" name="Add" value="Add Product">
        
      &nbsp;&nbsp;&nbsp;&nbsp;<input id="btnBack2" class="button1" type="button" value=" Back " onClick="javascript:history.back(-1)" name="Back"/>      </TD>
    </TR>
</TABLE>
</form>
<script language="JavaScript" type="text/javascript">

function validate()
{
if(document.frmAdd.procity.value=="")
{
	alert("Please Select City");
	document.frmAdd.procity.focus();
	return false;
}
if(document.frmAdd.prolocation.value=="")
{
	alert("Please Select locality");
	document.frmAdd.prolocation.focus();
	return false;
}
	
if(document.frmAdd.sub_name.value=="")
{
	alert("Name field can't be blank");
	document.frmAdd.sub_name.focus();
	return false;
}
  
}
</script>
<script>
function loadmorecitykeyword() {
var categoryid =  <?php echo $_REQUEST['sub_id']; ?>;
				$.post('morecitykeywordlocdivbyclick.php', {'categoryid': categoryid}, function(data){
									
				$("#morecitykeywordlocdiv").append(data); //append received data into the element

	});
}
</script>

<script>
function loadmorecitykeyword12(str) {
//alert(str);
var catcityid123 =  str;

				$.post('localitydivupdat.php?cct='+str, {'catcityid123': catcityid123}, function(data){
									
				//$("#citydiv").append(data); //append received data into the element
				//$("#citydiv12").replaceWith(data); //append received data into the element
				//$("#citydiv12").html(data); //append received data into the element

	});
}
</script>
<script>
function changeimagesrc(str,str1) {
	 image = document.getElementById(str);
     image.src = "";
	 document.getElementById(str1).value="";
}
</script>
<script>
window.pressedimage = function(numstr)
{	
//alert(numstr);

    var dylebel = 'fileLabel'+numstr;
	var dyimg = 'imagefilename'+numstr;

var ggllb = dyimg;
var imgpathBanner = document.getElementById(ggllb).value;
//var fsize = $('#imgfile1')[0].files[0].size;
var fsize = document.getElementById(ggllb).files[0].size;
//var fsize = $('#galimg')[0].files[0].size;
if(fsize>1048576*2) {
document.getElementById(ggllb).value = "";
alert('Upload File Size Must be < 2 MB');
return false;
}
if(imgpathBanner!="") {
var arr1 = new Array;
arr1 = imgpathBanner.split("\\");
var len = arr1.length;
var img1 = arr1[len-1];
var filext = img1.substring(img1.lastIndexOf(".")+1);
// Checking Extension
var filext = filext.toLowerCase();
if(filext != "jpg" && filext != "JPG" && filext != "JPEG" && filext != "JPEG" && filext != "gif" && filext != "GIF" && filext != "png" && filext != "PNG")
{
document.getElementById(ggllb).value = "";
alert("Invalid File Format Selected");
document.frmadd.ggllb.focus();
return false;
}
}
    var a = document.getElementById(ggllb);
    if(a.value == "")
    {
		document.getElementById(dylebel).innerHTML = "";
    }
    else
    {
        var theSplit = a.value.split('\\');
		document.getElementById(dylebel).innerHTML = theSplit[theSplit.length-1];
    }
};
</script>
<script>
window.pressedimagecertification = function(numstr)
{	
//alert(numstr);

    var dylebel = 'fileLabelcertification'+numstr;
	var dyimg = 'imagefilenamecertification'+numstr;

var ggllb = dyimg;
var imgpathBanner = document.getElementById(ggllb).value;
//var fsize = $('#imgfile1')[0].files[0].size;
var fsize = document.getElementById(ggllb).files[0].size;
//var fsize = $('#galimg')[0].files[0].size;
if(fsize>1048576*2) {
document.getElementById(ggllb).value = "";
alert('Upload File Size Must be < 2 MB');
return false;
}
if(imgpathBanner!="") {
var arr1 = new Array;
arr1 = imgpathBanner.split("\\");
var len = arr1.length;
var img1 = arr1[len-1];
var filext = img1.substring(img1.lastIndexOf(".")+1);
// Checking Extension
var filext = filext.toLowerCase();
if(filext != "jpg" && filext != "JPG" && filext != "JPEG" && filext != "JPEG" && filext != "gif" && filext != "GIF" && filext != "png" && filext != "PNG")
{
document.getElementById(ggllb).value = "";
alert("Invalid File Format Selected");
document.frmadd.ggllb.focus();
return false;
}
}
    var a = document.getElementById(ggllb);
    if(a.value == "")
    {
		document.getElementById(dylebel).innerHTML = "";
    }
    else
    {
        var theSplit = a.value.split('\\');
		document.getElementById(dylebel).innerHTML = theSplit[theSplit.length-1];
    }
};
</script>
<script>
function addmoreimage() {

 //var ni = document.getElementById('myDivItem');

  var numi = document.getElementById('theValueItemImage');

  var num = (document.getElementById('theValueItemImage').value -1)+ 2;
  numi.value = num;

  var remo = document.getElementsByName('imagefilename[]'); 
  var remolen  = remo.length;
 
//alert(remolen);

 
  var dvid= parseInt(num);
 
  var count =num;

var dataString = 'remolen=' + remolen;
		//alert(dataString);
			$.ajax({
			type: "POST",
			url: "plusimages.php",
			//url: "12.php",
			data: dataString,
			success: function(theResponse)
			{
			var result=theResponse;
			//alert(result);
			$('#addimagediv').append(result);
			if(result>0 && result==9) {

			}
			if(result<0 && result==-1) {
	
			}
			}
			
			});
	
}
</script>
<script>
function remove_meNleft(str) {
var rmvdiv = 'imageremovediv'+str;
var elem = document.getElementById(rmvdiv);
elem.remove();
}
</script>
<script>
function addmoreimagepricerate() {
//var ni = document.getElementById('myDivItem');

  var numi = document.getElementById('theValueItemImagePriceRate');

  var num = (document.getElementById('theValueItemImagePriceRate').value -1)+ 2;
  numi.value = num;

  var remo = document.getElementsByName('price_name[]'); 
  var remolen  = remo.length;
 
//alert(remolen);
 
  var dvid= parseInt(num);
 
  var count =num;

var dataString = 'remolen=' + remolen;
		//alert(dataString);
			$.ajax({
			type: "POST",
			url: "pluspricerate.php",
			//url: "12.php",
			data: dataString,
			success: function(theResponse)
			{
			var result=theResponse;
			//alert(result);
			$('#addimagedivpricerate').append(result);
			if(result>0 && result==9) {

			}
			if(result<0 && result==-1) {
	
			}
			}
			
			});

}
</script>
<script>
function remove_meNleftrate(str) {
var rmvdiv = 'imageremovedivlerate'+str;
var elem = document.getElementById(rmvdiv);
elem.remove();
}
</script>
<script>
function addmoreimagepricerateBulk() {
//var ni = document.getElementById('myDivItem');

  var numi = document.getElementById('theValueItemImagePriceRateBulk');

  var num = (document.getElementById('theValueItemImagePriceRateBulk').value -1)+ 2;
  numi.value = num;

  var remo = document.getElementsByName('price_nameBulk[]'); 
  var remolen  = remo.length;
 
//alert(remolen);
 
  var dvid= parseInt(num);
 
  var count =num;

var dataString = 'remolen=' + remolen;
		//alert(dataString);
			$.ajax({
			type: "POST",
			url: "pluspricerateBulk.php",
			//url: "12.php",
			data: dataString,
			success: function(theResponse)
			{
			var result=theResponse;
			//alert(result);
			$('#addimagedivpricerateBulk').append(result);
			if(result>0 && result==9) {

			}
			if(result<0 && result==-1) {
	
			}
			}
			
			});

}
</script>
<script>
function remove_meNleftrateBulk(str) {
var rmvdiv = 'imageremovedivlerateBulk'+str;
var elem = document.getElementById(rmvdiv);
elem.remove();
}
</script>
<script type="text/javascript">
var TabbedPanels1 = new Spry.Widget.TabbedPanels("TabbedPanels1");
</script>
<script>

//function validatedate(inputText)  
function validatedate()  
  {
  //alert();
  var vdd = document.getElementById('dd').value;
  var vmm = document.getElementById('mm').value;
  var vyy = document.getElementById('yy').value;
	
  var valldate = vmm+'-'+vdd+'-'+vyy;	  
	//alert(valldate);
  var inputText =  valldate;
  var dateformat = /^(0?[1-9]|1[012])[\/\-](0?[1-9]|[12][0-9]|3[01])[\/\-]\d{4}$/;  
  // Match the date format through regular expression  
  //if(inputText.value.match(dateformat))  
  if(inputText.match(dateformat))  
  {  
  //document.form1.text1.focus();  
  //Test which seperator is used '/' or '-'  
  var opera1 = inputText.split('/');  
  var opera2 = inputText.split('-');  
  lopera1 = opera1.length;  
  lopera2 = opera2.length;  
  // Extract the string into month, date and year  
  if (lopera1>1)  
  {  
  var pdate = inputText.split('/');  
  }  
  else if (lopera2>1)  
  {  
  var pdate = inputText.split('-');  
  }  
  var mm  = parseInt(pdate[0]);  
  var dd = parseInt(pdate[1]);  
  var yy = parseInt(pdate[2]);  
  // Create list of days of a month [assume there is no leap year by default]  
  var ListofDays = [31,28,31,30,31,30,31,31,30,31,30,31];  
  if (mm==1 || mm>2)  
  {  
  if (dd>ListofDays[mm-1])  
  {  
  alert('Invalid date format!');  
  document.getElementById('dd').selectedIndex="00";
  document.getElementById('mm').selectedIndex="00";
  return false;  
  }  
  }  
  if (mm==2)  
  {  
  var lyear = false;  
  if ( (!(yy % 4) && yy % 100) || !(yy % 400))   
  {  
  lyear = true;  
  }  
  if ((lyear==false) && (dd>=29))  
  {  
  alert('Invalid date format!'); 
    document.getElementById('dd').selectedIndex="00";
  document.getElementById('mm').selectedIndex="00"; 
  return false;  
  }  
  if ((lyear==true) && (dd>29))  
  {  
  alert('Invalid date format!'); 
  document.getElementById('dd').selectedIndex="00";
  document.getElementById('mm').selectedIndex="00"; 
  return false;  
  }  
  }  
  }  
  else  
  {  
  document.getElementById('dd').selectedIndex="00";
  document.getElementById('mm').selectedIndex="00";
  alert("Invalid date format!");  
  document.form1.dd.focus();  
  return false;  
  }  
  }  
</script>
<script>
function addmoreimagecertification() {

 //var ni = document.getElementById('myDivItem');

  var numi = document.getElementById('theValueItemImagecertification');

  var num = (document.getElementById('theValueItemImagecertification').value -1)+ 2;
  numi.value = num;

  var remo = document.getElementsByName('imagefilenamecertification[]'); 
  var remolen  = remo.length;
 
//alert(remolen);

 
  var dvid= parseInt(num);
 
  var count =num;

var dataString = 'remolen=' + remolen;
		//alert(dataString);
			$.ajax({
			type: "POST",
			url: "plusimagescertification.php",
			//url: "12.php",
			data: dataString,
			success: function(theResponse)
			{
			var result=theResponse;
			//alert(result);
			$('#addimagedivcertification').append(result);
			if(result>0 && result==9) {

			}
			if(result<0 && result==-1) {
	
			}
			}
			
			});
	
}
</script>
<script>
function remove_meNleftcertification(str) {
var rmvdiv = 'imageremovedivcertification'+str;
var elem = document.getElementById(rmvdiv);
elem.remove();
}
</script>
