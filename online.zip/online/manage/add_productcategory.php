<?php
ob_start();
@session_start(); ?>
<?php
include("../include/resizeimage.php");
?>
<?php
if(isset($_POST['Submit']) && $_REQUEST['Submit'] == "Add")
{
if($_FILES["imagefilenamelogo"]["name"]!=""){
	$intFile=mt_rand();
	move_uploaded_file($_FILES["imagefilenamelogo"]["tmp_name"],"../adminimg/logoimg/".$intFile.$_FILES["imagefilenamelogo"]["name"]);
	$filelogoimg=$intFile.$_FILES["imagefilenamelogo"]["name"];
	$thumb=generateThumb($filelogoimg,"../adminimg/logoimg/","../adminimg/logoimg/",1440,800);
} else {
	$filelogoimg="";
}
  
  
    $name = addslashes($_REQUEST['name']);
	//$lowrname = strtolower($name);
	//$product_url = str_replace(" ","/","$lowrname");
	
	//echo  $product_url;
	
	
	$cat = $_POST['hidcat'];
	if($cat == "")
	{
	$cat = '0';
	}
	//exit();
	
	$urlname = makeurlnamebyname($name);
	$urlname = makeurlnamebynameCategory($name);
	$q="INSERT INTO manage_productcategory set name = '".$name."', p_id = '".$cat."', description = '".addslashes($_REQUEST['description'])."', imagefilename = '".$filelogoimg."', titletag = '".$_REQUEST['titletag']."', alttag = '".$_REQUEST['alttag']."',urlname = '".$urlname."'";
	$final=mysql_query($q);
	if($final)
	{
	header("location:home.php?PageURL=manage_productcategory&cat=$cat&msg=2");
	}
	else
	{
	//echo"not";
	}
	//echo  $lowrname;

}

?>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery.imgareaselect.pack.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<link rel="stylesheet" type="text/css" href="css/imgareaselect-animated.css" />
<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
<script type="text/javascript" src="ckfinder/ckfinder.js"></script>
<link href="images/class.css" rel="stylesheet" type="text/css">
<link href="css/custom.css" rel="stylesheet">


<table width="100%" border="0" cellpadding="0" cellspacing="0">
<form name="frmcontents" method="post" action="" enctype="multipart/form-data">
<input type="hidden" name="hidcat" id="hidcat" value="<?php echo $_REQUEST['cat'];?>">
 <tr>
 <td>
<?php
if($_REQUEST[cat]=="") {
?> 
 <h1>Add Category</h1>
<?php } else { ?>

<h1>Add Category (<?php echo getProductCategorynameById($_REQUEST[cat]); ?>)</h1>
<?php } ?> 
 </td>
 </tr>
  <tr>
    <td  align="center">
<?php if($msg==1){ echo "<font color=red>".$_REQUEST[title] ." page content is update.</font>"; $msg=0;}elseif($msg==2){ echo "<font color=red>".$_REQUEST[title] ." page  is add.</font>";$msg=0;}elseif($msg==3){ echo "<font color=red>".$_REQUEST[title] ." page  is deleted.</font>";$msg=0;}?></td>
  </tr>
  <tr>
  <td align="left"> </td>
    </tr>
    <tr>
          <td align="left"><h4>Name:</h4></td>
    </tr>
  <tr>
    <td align="left" valign="middle"> <input name="name" type="text" class="txtbox1" id="name"/></td>
    </tr>
    <tr>
      <td align="left">&nbsp;</td>
    </tr>
    <!--
    <tr>
          <td align="left"><h4>Description:</h4></td>
    </tr>
  <tr>
    <td align="left" valign="middle"><textarea id="description" name="description"></textarea></td>
    </tr>
   <script type="text/javascript">		
		var editor = CKEDITOR.replace( 'description',{ customConfig : '<?=$rootpath?>/ckeditor/configcms.js' } );
		CKFinder.SetupCKEditor( editor, '<?=$rootpath?>/ckfinder/' ) ;
   </script>    
    <tr>
      <td align="left">&nbsp;</td>
    </tr>
-->
  <tr>
    <td align="left" valign="middle">
    
<h4>Category Image:</h4>
<table width="100%">
	<tr>
    	<td width="31%">Category Image:</td>
        <td width="35%">Title Tag:</td>
        <td width="34%">Alt Tag:</td>
    </tr>
	<tr>
    	<td>
    <div class="btn-file">
    <label id="fileLabellogo">Click to Upload Image </label><input name="imagefilenamelogo" id="imagefilenamelogo" type="file" onchange="pressedimage('logo')">
    </div>        
        </td>
        <td> <input name="titletag" type="text" class="txtbox1" id="titletag"/></td>
        <td> <input name="alttag" type="text" class="txtbox1" id="alttag"/></td>
    </tr>    
</table>    
    
        
    </td>
    </tr>

  <tr>
    <td align="left" valign="middle">
    
    </td>
    </tr>
        
    <tr>
      <td align="left">&nbsp;</td>
    </tr>        
    <tr>
    <td><input type="submit" name="Submit" value="Add" class="btn1">&nbsp;&nbsp;
    
    <input type="button" name="back" id="back" value="Back" class="btn1" onClick="javascript:history.back(-1)">
    <?php /*?><input type="button" name="back" id="back" value="Back" class="btn1" onclick="location.href='home.php?PageURL=manage_contents&cat=<?php echo $_REQUEST[cat];?>'"><?php */?>
      <input name="hdn" type="hidden" id="hdn" value="1"></td>
  </tr>
  </form>
</table>
<script>
window.pressedimage = function(numstr)
{	
//alert(numstr);

    var dylebel = 'fileLabel'+numstr;
	var dyimg = 'imagefilename'+numstr;

var ggllb = dyimg;
var imgpathBanner = document.getElementById(ggllb).value;
//var fsize = $('#imgfile1')[0].files[0].size;
var fsize = document.getElementById(ggllb).files[0].size;
//var fsize = $('#galimg')[0].files[0].size;
if(fsize>1048576*2) {
document.getElementById(ggllb).value = "";
alert('Upload File Size Must be < 2 MB');
return false;
}
if(imgpathBanner!="") {
var arr1 = new Array;
arr1 = imgpathBanner.split("\\");
var len = arr1.length;
var img1 = arr1[len-1];
var filext = img1.substring(img1.lastIndexOf(".")+1);
// Checking Extension
var filext = filext.toLowerCase();
if(filext != "jpg" && filext != "JPG" && filext != "JPEG" && filext != "JPEG" && filext != "gif" && filext != "GIF" && filext != "png" && filext != "PNG")
{
document.getElementById(ggllb).value = "";
alert("Invalid File Format Selected");
document.frmadd.ggllb.focus();
return false;
}
}
    var a = document.getElementById(ggllb);
    if(a.value == "")
    {
		document.getElementById(dylebel).innerHTML = "";
    }
    else
    {
        var theSplit = a.value.split('\\');
		document.getElementById(dylebel).innerHTML = theSplit[theSplit.length-1];
    }
};
</script>