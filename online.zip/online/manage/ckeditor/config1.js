﻿/*
Copyright (c) 2003-2010, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.editorConfig = function( config )
{

    //config.language = 'fr';
    //config.uiColor = '#AADC6E';
config.toolbar = 'Full';

//config.filebrowserBrowseUrl = 'http://localhost/uploder/upload.php';
	//config.filebrowserBrowseUrl ='/browser/browse.php';
      //  config.filebrowserUploadUrl='/uploader/upload.php';

//config.filebrowserWindowWidth = '640';
     //   config.filebrowserWindowHeight = '480';


//config.filebrowserImageBrowseUrl = '/browser/browse.php?type=Images';

config.toolbar_Full =
[
    ['Source','Preview'],    
    ['Bold','Italic','Underline'],
    ['JustifyLeft','JustifyCenter','JustifyRight','JustifyBlock'],
    ['Link','Unlink'],
    ['Image','Table','HorizontalRule','Smiley'],    
    ['Styles','Font','FontSize'],
    ['TextColor','BGColor']
];
config.width = '700px';
config.hieght = '1000px';

/*config.toolbar_Basic =
[
    ['Bold', 'Italic', '-', 'NumberedList', 'BulletedList', '-', 'Link', 'Unlink','-','About']
];*/

};
