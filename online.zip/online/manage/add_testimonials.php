<?php
include("../include/resizeimage.php");
?>
<?php
if(isset($_REQUEST['Add']) && $_REQUEST['Add']=="Add") {

   $res=mysql_query("insert into manage_testimonials set  
   testimonials_name = '".addslashes($_REQUEST['testimonials_name'])."',
   testimonials_by = '".addslashes($_REQUEST['testimonials_by'])."',
   description = '".addslashes($_REQUEST['description'])."'");
	
   header("location:home.php?PageURL=manage_testimonials");
}
?>
<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
<script type="text/javascript" src="ckfinder/ckfinder.js"></script>
<link href="images/class.css" rel="stylesheet" type="text/css">
<link href="css/custom.css" rel="stylesheet">

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
<script src="../select-menu/jquery.sumoselect.min.js"></script>
<link href="../select-menu/sumoselect.css" rel="stylesheet" />

<script type="text/javascript">
$jq123 = $.noConflict();
        $jq123(document).ready(function () {
            window.asd = $jq123('.SlectBox').SumoSelect({ csvDispCount: 3 });
            window.test = $jq123('.testsel').SumoSelect({okCancelInMulti:true });
        });
</script>

<link href="../SpryAssets/SpryTabbedPanels.css" rel="stylesheet" type="text/css" />
<script src="../SpryAssets/SpryTabbedPanels.js" type="text/javascript"></script>

<form name="frmadd" id="frmadd" method="post" ENCTYPE="multipart/form-data">
<input type="hidden" name="hdn" value="1">
<input type="hidden" name="cat_id" id="cat_id" value="<?php echo $_REQUEST['cat_id']; ?>">
<input type="hidden" name="hdnh" value="1">
  
  
<h1>Add Testimonial</h1>
<table width="100%" border="0" align="center" cellpadding="3" cellspacing="1">
  <tr> 
    <td height="10" colspan=3 ></td>
  </tr>
 
    <?
	if($MSG) { ?>
    <TR align="center"> 
      <TD colspan=3> <?echo "<font color='#FF3366'>".$MSG."</font>"; ?> </TD>
    </TR>
    <? } ?>
	<TR>
      <TD width="9%" align=left valign="middle" class="text"> Heading</TD>
      <TD width="2%" align="center"><strong>:</strong></TD>
      <TD width="89%" align="left"><input name="testimonials_name" type="text" id="testimonials_name" value="" required/></TD>
    </TR> 
<TR>
      <TD width="9%" align=left valign="middle" class="text"> By</TD>
      <TD width="2%" align="center"><strong>:</strong></TD>
      <TD width="89%" align="left"><input name="testimonials_by" type="text" id="testimonials_by" value=""/></TD>
    </TR>       
    <TR>
      <TD align=left valign="top" class="text">Description</TD>
      <TD align="center" valign="top" class="text"><strong>:</strong></TD>
      <TD align="left"><span class="text">
        
        <textarea id="description" name="description" style="width:140px;"></textarea>
      </span></TD>
    </TR>
   <script type="text/javascript">		
		var editor = CKEDITOR.replace( 'description',{ customConfig : '<?=$rootpath?>/ckeditor/configcms.js' } );
		CKFinder.SetupCKEditor( editor, '<?=$rootpath?>/ckfinder/' ) ;
   </script> 
    <TR align="center"> 
      <TD height=50>&nbsp;</TD>
      <TD height=50>&nbsp;</TD>
      <TD height=50 align="left"> <input type="submit" name="Add" value="Add">
	  
	  &nbsp;&nbsp;&nbsp;&nbsp;<input id="btnBack2" class="button1" type="button" value=" Back " onClick="javascript:history.back(-1)" name="Back"/>      </TD>
    </TR>
</TABLE>
</form>
<script language="JavaScript" type="text/javascript">

function validate()
{
if(document.frmAdd.procity.value=="")
{
	alert("Please Select City");
	document.frmAdd.procity.focus();
	return false;
}
if(document.frmAdd.prolocation.value=="")
{
	alert("Please Select locality");
	document.frmAdd.prolocation.focus();
	return false;
}
	
if(document.frmAdd.sub_name.value=="")
{
	alert("Name field can't be blank");
	document.frmAdd.sub_name.focus();
	return false;
}
  
}
</script>
<script>
function loadmorecitykeyword() {
var categoryid =  <?php echo $_REQUEST['sub_id']; ?>;
				$.post('morecitykeywordlocdivbyclick.php', {'categoryid': categoryid}, function(data){
									
				$("#morecitykeywordlocdiv").append(data); //append received data into the element

	});
}
</script>

<script>
function loadmorecitykeyword12(str) {
//alert(str);
var catcityid123 =  str;

				$.post('localitydivupdat.php?cct='+str, {'catcityid123': catcityid123}, function(data){
									
				//$("#citydiv").append(data); //append received data into the element
				//$("#citydiv12").replaceWith(data); //append received data into the element
				//$("#citydiv12").html(data); //append received data into the element

	});
}
</script>
<script>
function changeimagesrc(str,str1) {
	 image = document.getElementById(str);
     image.src = "";
	 document.getElementById(str1).value="";
}
</script>
<script>
window.pressedimage = function(numstr)
{	
//alert(numstr);

    var dylebel = 'fileLabel'+numstr;
	var dyimg = 'imagefilename'+numstr;

var ggllb = dyimg;
var imgpathBanner = document.getElementById(ggllb).value;
//var fsize = $('#imgfile1')[0].files[0].size;
var fsize = document.getElementById(ggllb).files[0].size;
//var fsize = $('#galimg')[0].files[0].size;
if(fsize>1048576*2) {
document.getElementById(ggllb).value = "";
alert('Upload File Size Must be < 2 MB');
return false;
}
if(imgpathBanner!="") {
var arr1 = new Array;
arr1 = imgpathBanner.split("\\");
var len = arr1.length;
var img1 = arr1[len-1];
var filext = img1.substring(img1.lastIndexOf(".")+1);
// Checking Extension
var filext = filext.toLowerCase();
if(filext != "jpg" && filext != "JPG" && filext != "JPEG" && filext != "JPEG" && filext != "gif" && filext != "GIF" && filext != "png" && filext != "PNG")
{
document.getElementById(ggllb).value = "";
alert("Invalid File Format Selected");
document.frmadd.ggllb.focus();
return false;
}
}
    var a = document.getElementById(ggllb);
    if(a.value == "")
    {
		document.getElementById(dylebel).innerHTML = "";
    }
    else
    {
        var theSplit = a.value.split('\\');
		document.getElementById(dylebel).innerHTML = theSplit[theSplit.length-1];
    }
};
</script>




