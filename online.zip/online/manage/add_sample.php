<?php
include("../include/resizeimage.php");
?>
<?php
if(isset($_REQUEST['Add']) && $_REQUEST['Add']=="Add Gift") {


if($_FILES["imagefilenamelogo"]["name"]!=""){
	$intFile=mt_rand();
	move_uploaded_file($_FILES["imagefilenamelogo"]["tmp_name"],"../adminimg/logoimg/".$intFile.$_FILES["imagefilenamelogo"]["name"]);
	$filelogoimg=$intFile.$_FILES["imagefilenamelogo"]["name"];
	$thumb=generateThumb($filelogoimg,"../adminimg/logoimg/","../adminimg/logoimg/",800,800);
} else {
	$filelogoimg="";
}

$allcheckedcategory = "";
$allcheckedparentcategory = "";
   $chkmaincategory = $_POST["chkmaincategory"];
    foreach ($chkmaincategory as $value) {	
	
	 $allcheckedparentcategory.= ",".$value;
	 
 		$childc = $value."chkchildcategory";
 		$childpost = $_POST[$childc];
  foreach ($childpost as $valuec) {
  $allcheckedcategory.= ",".$valuec;
            }
    }
	$allcheckedparentcategory = substr($allcheckedparentcategory,1) ;
	$allcheckedcategory = substr($allcheckedcategory,1);
/*****************************************************/
//$catpid = getProductParentCategoryByCatId($_REQUEST[cat_id]);

   $res=mysql_query("insert into tbl_products set product_type = '1', 
   productname = '".addslashes($_REQUEST['productname'])."', 
   detail = '".strip_tags($_REQUEST['detail'])."', 
   instock = '".$_REQUEST['instock']."', 
   deliverytime = '".$_REQUEST['deliverytime']."', 
   productdescription = '".addslashes($_REQUEST['productdescription'])."', 
   logoimg = '".$filelogoimg."', 
   productpriceinr = '".strip_tags($_REQUEST[productpriceinr])."',
   productpricedollar = '".strip_tags($_REQUEST[productpricedollar])."',      
   status = '1', p_ids ='".$allcheckedcategory."', c_ids = '".$allcheckedparentcategory."'");

   header("location:home.php?PageURL=manage_sampleproduct");
}
?>
<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
<script type="text/javascript" src="ckfinder/ckfinder.js"></script>
<link href="images/class.css" rel="stylesheet" type="text/css">
<link href="css/custom.css" rel="stylesheet">

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
<script src="../select-menu/jquery.sumoselect.min.js"></script>
<link href="../select-menu/sumoselect.css" rel="stylesheet" />

<script type="text/javascript">
$jq123 = $.noConflict();
        $jq123(document).ready(function () {
            window.asd = $jq123('.SlectBox').SumoSelect({ csvDispCount: 3 });
            window.test = $jq123('.testsel').SumoSelect({okCancelInMulti:true });
        });
</script>

<link href="../SpryAssets/SpryTabbedPanels.css" rel="stylesheet" type="text/css" />
<script src="../SpryAssets/SpryTabbedPanels.js" type="text/javascript"></script>

<form name="frmadd" id="frmadd" method="post" ENCTYPE="multipart/form-data">
<input type="hidden" name="hdn" value="1">
<input type="hidden" name="cat_id" id="cat_id" value="<?php echo $_REQUEST['cat_id']; ?>">
<input type="hidden" name="hdnh" value="1">
  
  
<h1>Add Sample</h1>
<table width="100%" border="0" align="center" cellpadding="3" cellspacing="1">
  <tr> 
    <td height="10" colspan=3 ></td>
  </tr>
 
    <?
	if($MSG) { ?>
    <TR align="center"> 
      <TD colspan=3> <?echo "<font color='#FF3366'>".$MSG."</font>"; ?> </TD>
    </TR>
    <? } ?>
	<TR>
      <TD width="22%" align=right valign="middle" class="text">Product Name</TD>
      <TD width="2%" align="center"><strong>:</strong></TD>
      <TD width="76%" align="left"><input name="productname" type="text" class="TextBox" id="productname" value="" required/></TD>
    </TR>
    <TR>
      <TD width="22%" align=right valign="middle" class="text">Price (INR)</TD>
      <TD width="2%" align="center"><strong>:</strong></TD>
      <TD width="76%" align="left"><input name="productpriceinr" type="text" class="TextBox" id="productpriceinr" value=""/></TD>
    </TR>
    <TR>
      <TD width="22%" align=right valign="middle" class="text">Price (Dollar)</TD>
      <TD width="2%" align="center"><strong>:</strong></TD>
      <TD width="76%" align="left"><input name="productpricedollar" type="text" class="TextBox" id="productpricedollar" value=""/></TD>
    </TR>    
    <!--<TR>
     <TD width="22%" align=right valign="middle" class="text">Stock Available</TD>
     <TD width="2%" align="center"><strong>:</strong></TD>
      <TD width="76%" align="left"><input type="checkbox" name="instock" id="instock" value="1"></TD>
    </TR>-->
    <TR>
      <TD width="22%" align=right valign="middle" class="text">Est. Delivery Time</TD>
      <TD width="2%" align="center"><strong>:</strong></TD>
      <TD width="76%" align="left"><input name="deliverytime" type="text" class="TextBox" id="deliverytime" value=""/></TD>
    </TR>
     <TR>
      <TD align=right valign="top" class="text">Product Description</TD>
      <TD valign="top" class="text"><strong>:</strong></TD>
      <TD align="left"><span class="text">
        
        <textarea id="productdescription" name="productdescription" style="width:140px;"></textarea>
      </span></TD>
    </TR>
   <script type="text/javascript">		
		var editor = CKEDITOR.replace( 'productdescription',{ customConfig : '<?=$rootpath?>/ckeditor/configcms.js' } );
		CKFinder.SetupCKEditor( editor, '<?=$rootpath?>/ckfinder/' ) ;
   </script>
    <TR>
      <TD width="22%" align=right valign="middle" class="text">&nbsp;</TD>
      <TD width="2%" align="center"><strong>:</strong></TD>
      <TD width="76%" align="left"></TD>
    </TR>   
    <TR> 
      <TD height=35 align=right valign="top" class="text">Product </TD>
      <TD align=center valign="top" class="text"><strong>:</strong></TD>
      <TD height=35 align=left valign="top" class="text">
<?php
$productCategoryList =getProductCategoryList();
if(count($productCategoryList)>0) {
foreach($productCategoryList as $productCategoryListData) {
	if(getProductCountByCatId($productCategoryListData['id'])>0) {
?>          
          

<input type="checkbox" name="chkmaincategory[]" id="chkmaincategory<?php echo $productCategoryListData['id']; ?>" value="<?php echo $productCategoryListData['id']; ?>" onClick="maincatgoryclick('<?php echo $productCategoryListData['id']; ?>')" /><?php echo $productCategoryListData['name']; ?>          
          
          
<?php
$allProductListByCatId = getAllProductListByCatId($productCategoryListData['id']);
foreach($allProductListByCatId as $allProductListByCatIdData) {
?>          
<br />&nbsp;&nbsp;            
<input type="checkbox" name="<?php echo $productCategoryListData['id']; ?>chkchildcategory[]" id="<?php echo $productCategoryListData['id']; ?>chkchildcategory<?php echo $allProductListByCatIdData['id']; ?>" value="<?php echo $allProductListByCatIdData['id']; ?>" onClick="childcatgoryclick('<?php echo $productCategoryListData['id']; ?>', '<?php echo $allProductListByCatIdData['id']; ?>')" /><?php echo $allProductListByCatIdData['productname']; ?>            
            
            
            
            
<?php } ?>            
    <br /><br />  
<?php } ?>          
<?php } ?>         
<?php } ?>      
      </TD>
    </TR>    
	<TR> 
      <TD height=0 align=right valign="top" class="text">&nbsp;</TD>
      <TD align=left valign="top" class="text">&nbsp;</TD>
      <TD height=0 align=left valign="top" class="text">&nbsp;</TD>
    </TR> 
    <TR align="center"> 
      <TD height=50>&nbsp;</TD>
      <TD height=50>&nbsp;</TD>
      <TD height=50 align="left"> <input type="submit" name="Add" value="Add Gift">
	  
	  &nbsp;&nbsp;&nbsp;&nbsp;<input id="btnBack2" class="button1" type="button" value=" Back " onClick="javascript:history.back(-1)" name="Back"/>      </TD>
    </TR>
</TABLE>
</form>
<script language="JavaScript" type="text/javascript">

function validate()
{
if(document.frmAdd.procity.value=="")
{
	alert("Please Select City");
	document.frmAdd.procity.focus();
	return false;
}
if(document.frmAdd.prolocation.value=="")
{
	alert("Please Select locality");
	document.frmAdd.prolocation.focus();
	return false;
}
	
if(document.frmAdd.sub_name.value=="")
{
	alert("Name field can't be blank");
	document.frmAdd.sub_name.focus();
	return false;
}
  
}
</script>
<script>
function loadmorecitykeyword() {
var categoryid =  <?php echo $_REQUEST['sub_id']; ?>;
				$.post('morecitykeywordlocdivbyclick.php', {'categoryid': categoryid}, function(data){
									
				$("#morecitykeywordlocdiv").append(data); //append received data into the element

	});
}
</script>

<script>
function loadmorecitykeyword12(str) {
//alert(str);
var catcityid123 =  str;

				$.post('localitydivupdat.php?cct='+str, {'catcityid123': catcityid123}, function(data){
									
				//$("#citydiv").append(data); //append received data into the element
				//$("#citydiv12").replaceWith(data); //append received data into the element
				//$("#citydiv12").html(data); //append received data into the element

	});
}
</script>
<script>
function changeimagesrc(str,str1) {
	 image = document.getElementById(str);
     image.src = "";
	 document.getElementById(str1).value="";
}
</script>
<script>
window.pressedimage = function(numstr)
{	
//alert(numstr);

    var dylebel = 'fileLabel'+numstr;
	var dyimg = 'imagefilename'+numstr;

var ggllb = dyimg;
var imgpathBanner = document.getElementById(ggllb).value;
//var fsize = $('#imgfile1')[0].files[0].size;
var fsize = document.getElementById(ggllb).files[0].size;
//var fsize = $('#galimg')[0].files[0].size;
if(fsize>1048576*2) {
document.getElementById(ggllb).value = "";
alert('Upload File Size Must be < 2 MB');
return false;
}
if(imgpathBanner!="") {
var arr1 = new Array;
arr1 = imgpathBanner.split("\\");
var len = arr1.length;
var img1 = arr1[len-1];
var filext = img1.substring(img1.lastIndexOf(".")+1);
// Checking Extension
var filext = filext.toLowerCase();
if(filext != "jpg" && filext != "JPG" && filext != "JPEG" && filext != "JPEG" && filext != "gif" && filext != "GIF" && filext != "png" && filext != "PNG")
{
document.getElementById(ggllb).value = "";
alert("Invalid File Format Selected");
document.frmadd.ggllb.focus();
return false;
}
}
    var a = document.getElementById(ggllb);
    if(a.value == "")
    {
		document.getElementById(dylebel).innerHTML = "";
    }
    else
    {
        var theSplit = a.value.split('\\');
		document.getElementById(dylebel).innerHTML = theSplit[theSplit.length-1];
    }
};
</script>
<script>
function maincatgoryclick(str) {

var maincat = 'chkmaincategory'+str;
var childcat = str+'chkchildcategory';
//alert(childcat);
var elemArray = document.getElementsByName(childcat+'[]');

//alert(elemArray.length);

var lfckv = document.getElementById(maincat).checked;

if(lfckv==true) {

for(var i = 0; i < elemArray.length; i++){
        var elem = document.getElementById(elemArray[i].id);
		var vvll = elem.value;
		var ccld = childcat+vvll;
		//alert(ccld);
		document.getElementById(ccld).checked = true;
    }
	
		}
if(lfckv==false) {

for(var i = 0; i < elemArray.length; i++){
        var elem = document.getElementById(elemArray[i].id);
		var vvll = elem.value;
		var ccld = childcat+vvll;
		//alert(ccld);
		document.getElementById(ccld).checked = false;
    }
	
		}
}
</script>

<script>
function childcatgoryclick(str,str1) {
var countnum = 0;
var childcat = str+'chkchildcategory';
//alert(childcat);
var elemArray = document.getElementsByName(childcat+'[]');
for(var i = 0; i < elemArray.length; i++){
		var elem = document.getElementById(elemArray[i].id);
		var vvll = elem.value;
		var ccld = childcat+vvll;
		//alert(ccld);
		if(document.getElementById(ccld).checked == true) {
		
		countnum = countnum+1;
		}

}
if(countnum>0) {
var maincat = 'chkmaincategory'+str;
document.getElementById(maincat).checked = true;
}
if(countnum==0) {
var maincat = 'chkmaincategory'+str;
document.getElementById(maincat).checked = false;
}
}
</script>



