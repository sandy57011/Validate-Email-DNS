<?php
include("../include/resizeimage.php");
?>
<?php
if(isset($_REQUEST['Add']) && $_REQUEST['Add']=="Add Faq") {

/*****************************************************/
//$catpid = getProductParentCategoryByCatId($_REQUEST[cat_id]);

   $res=mysql_query("insert into manage_faq set  
   faq_name = '".addslashes($_REQUEST['faq_name'])."', 
   description = '".addslashes($_REQUEST['description'])."'");
	
   header("location:home.php?PageURL=manage_faq");
}
?>
<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
<script type="text/javascript" src="ckfinder/ckfinder.js"></script>
<link href="images/class.css" rel="stylesheet" type="text/css">
<link href="css/custom.css" rel="stylesheet">

<form name="frmadd" id="frmadd" method="post" ENCTYPE="multipart/form-data">
<input type="hidden" name="hdn" value="1">
<input type="hidden" name="cat_id" id="cat_id" value="<?php echo $_REQUEST['cat_id']; ?>">
<input type="hidden" name="hdnh" value="1">
  
  
<h1>Add Faq</h1>
<table width="100%" border="0" align="center" cellpadding="3" cellspacing="1">
  <tr> 
    <td height="10" colspan=3 ></td>
  </tr>
 
    <?
	if($MSG) { ?>
    <TR align="center"> 
      <TD colspan=3> <?echo "<font color='#FF3366'>".$MSG."</font>"; ?> </TD>
    </TR>
    <? } ?>
	<TR>
      <TD width="8%" align=left valign="middle" class="text">Question</TD>
      <TD width="3%" align="left"><strong>:</strong></TD>
      <TD width="89%" align="left"><input name="faq_name" type="text" class="TextBox" id="faq_name" value="" required/></TD>
    </TR>    
    <TR>
      <TD align=left valign="top" class="text">Answer</TD>
      <TD align="left" valign="top" class="text"><strong>:</strong></TD>
      <TD align="left"><span class="text">
        
        <textarea id="description" name="description" style="width:140px;"></textarea>
      </span></TD>
    </TR>
   <script type="text/javascript">		
		var editor = CKEDITOR.replace( 'description',{ customConfig : '<?=$rootpath?>/ckeditor/configcms.js' } );
		CKFinder.SetupCKEditor( editor, '<?=$rootpath?>/ckfinder/' ) ;
   </script>     
   
	<TR align="center"> 
      <TD height=50>&nbsp;</TD>
      <TD height=50>&nbsp;</TD>
      <TD height=50 align="left"> <input type="submit" name="Add" value="Add Faq">
	  
	  &nbsp;&nbsp;&nbsp;&nbsp;<input id="btnBack2" class="button1" type="button" value=" Back " onClick="javascript:history.back(-1)" name="Back"/>      </TD>
    </TR>
</TABLE>
</form>