<?php
ob_start();
@session_start();
include("include/connect.php");
include("include/function.php");
?>
<?php
$recemail = $_POST['recemail'];
$cheklogUserRes = mysql_query("select * from tbl_registration where uemail = '".$recemail."'");
$checkcount = mysql_num_rows($cheklogUserRes);
if($checkcount>0) {
echo $errorcode = 78;
} 
//echo $errorcode;
?>
