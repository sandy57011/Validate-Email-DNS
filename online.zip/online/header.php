<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js" type="text/javascript"></script>

<script type="text/javascript">
	$(document).ready(function() {
	   	var stickyNavTop = $('.t-menu').offset().top;		   	
	   	var stickyNav = function(){
	    var scrollTop = $(window).scrollTop(); // our current vertical position from the top			         
		    if (scrollTop > stickyNavTop) { 
		        $('.t-menu').addClass('sticky');
		    } else {
		        $('.t-menu').removeClass('sticky'); 
		    }
		};
		stickyNav();			
		$(window).scroll(function() {
			stickyNav();
		});
	});
</script>


<link href="<?=$rootpath?>/css/style.css" rel="stylesheet" type="text/css" />
<style>

#country-list{float:left;list-style:none;margin-top:-3px;padding:0;width:190px;position: absolute;}
#country-list li{padding: 10px; background: #333; border-bottom: #bbb9b9 1px solid;}
#country-list li:hover{background:#ece3d2;cursor: pointer;}
#search-box{padding: 10px;border: #a8d4b1 1px solid;border-radius:4px;}

</style>
<?php
$contactRow = mysql_fetch_array(mysql_query("select * from manage_contactaddress where id='1'"));
?>
  
<?php $result_pagebulk = mysql_fetch_array(mysql_query("select * from contents where id='7'"));?>    
<?php $result_pageshipping = mysql_fetch_array(mysql_query("select * from contents where id='8'"));?>







<header>
<div class="container">
<div class="h-left">
<i class="fa fa-volume-control-phone"></i> <a href="tel://<?php echo $contactRow['phone']; ?>"><?php echo $contactRow['phone']; ?></a>
</div>

<div class="logo"><a href="<?=$rootpath?>/index"><img src="<?=$rootpath?>/images/logo.png" alt="Delivery Kings" /></a></div>


<div class="h-right">
<ul>
<!---------------------------------------------------->
<?php
if($_SESSION['user_idd']!="") {
?>
<?php $uservarname = getUsernameByUid($_SESSION['user_idd']);
$uservarname = explode(" ", $uservarname);
$userregname = $uservarname[0];
?>
<li><a href="<?=$rootpath?>/myaccount"><i class="fa fa-user"></i><?php echo $userregname; ?></a></li>
<?php } ?>
<!---------------------------------------------------->
<li>
<div class="frmSearch">
	<input type="text" name="search_product" id="search_products" placeholder="Search...">
	<div id="suggesstion-box"></div>
</div>


</li>

<?php
if($_SESSION['user_idd']!="") {
?>

<li><a href="<?=$rootpath?>/logout"><i class="fa fa-sign-out"></i>Logout</a></li>

<?php } else { ?>
<!--<a href="javascript:void(0)" onclick="return adcLog('test-contentLog')" id="test-linkLog">Log in</a> |--> <!--<a href="javascript:void(0)" onclick="new_regUser()">New</a>-->
<li><a href="<?=$rootpath?>/login"><i class="fa fa-key"></i>Log in</a></li>
<!--<a href="#" onclick="return adc('test-contentReg')" id="test-linkReg">New User</a>-->
<li><a href="<?=$rootpath?>/registration"><i class="fa fa-user-plus"></i>New User</a></li>
<?php } ?>


 
 
 <li>
<a href="<?=$rootpath?>/shoppingcart" id="master_shopping_cart_top">
<i class="fa fa-shopping-cart"></i>Cart (<?php echo count($_SESSION['cart']); ?>)</a></li>


 
 <div class="clear"></div>
 </ul>

</div>
<div class="clear"></div>
</div> 

<div class="t-menu">
<div class="container">
<div class="wsmenucontainer">
<div class="wsmenuexpandermain slideRight"><a id="navToggle" class="animated-arrow slideLeft" href="#"><span></span></a></div>
<div class="wsmenucontent overlapblackbg"></div>
<div>
  
<!--Menu HTML Code-->
<nav class="wsmenu slideLeft clearfix">
<ul class="mobile-sub wsmenu-list">
<li class="menu-logo hidden-md hidden-lg"><img src="<?=$rootpath?>/images/logo.png" alt="Delivery Kings" /></a></li>
<li class="visible-xs"><a href="<?=$rootpath?>/">Home</a></li>
<?php
$productCategoryList =getProductCategoryList();
if(count($productCategoryList)>0) {
foreach($productCategoryList as $productCategoryListData) {
if(getProductCountByCatId($productCategoryListData['id'])>0) {
?>          
<li><a href="<?=$rootpath?>/astro-<?php echo $productCategoryListData['urlname'];?>"><?php echo $productCategoryListData['name']; ?></a></li>          
<?php } ?>          
<?php } ?>         
<?php } ?>
<li class="visible-xs"><a href="<?=$rootpath?>/contactus">Contact us</a></li>
    
</ul>
</nav>
    
</div> 
</div>
</div>
</div>


</header>





<script>
	$(document).ready(function(){
		$("#search_products").keyup(function(){
			$.ajax({
				type: "POST",
				url: "<?=$rootpath?>/ajax_add_to_cart.php",
				data:'auto_search_keyword='+$(this).val(),
				beforeSend: function(){
					$("#search-box").css("background","#FFF url(LoaderIcon.gif) no-repeat 165px");
				},
				success: function(data){
					$("#suggesstion-box").show();
					$("#suggesstion-box").html(data);
					$("#search-box").css("background","#FFF");
				}
			});
		});
		$('body').click(function(){
			$('#suggesstion-box').hide();
		});
	});
function login_now()
{ 
	$.post("login_form.php",function(data){
			$div = $('<div />').appendTo('body');
			$div.attr('id', 'dynamicl');	
			$('#dynamicl').html(data);
			process();
			},"html");
	}
	
	 function close_login(){
		 $('#dynamicl').remove();
		 }// JavaScript Document
		 
		 function process(){
			$("#Submit").click(function(){
			//if(frmValidate())
			//var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
			var userid = $('#userid').val();
			var password = $('#password').val();		
			
			if(userid=="")
			{
			alert('Please Enter userid');
			$('#userid').focus();
			}else if(password==""){
				alert('Please Enter Password');
		$('#password').focus();
		return false;
				}else{
				sendValue($("#formlog").serialize());   
				return false;
			}  
			});
			}
			function sendValue(str){
			str = str+"&value=true"; 
			
			$.post("member.php",str , function(data){
			if(data.trim()=="true"){
			window.setTimeout(function(){window.location="index.php"},2000);}else{
			//window.setTimeout(function(){window.location="myaccount.php"},2000);}else{
			$('#waitdiverror').html(data);}
			}, "html");
			}
function new_regUser() {
	$.post("user-registration.php",function(data){
			$div = $('<div />').appendTo('body');
			$div.attr('id', 'dynamicl');	
			$('#dynamicl').html(data);
			//processReg();
			},"html");

}			
</script>
<script language="javascript">
function forgotPasswordfunction() {
var fuserid = document.getElementById('fuserid').value;
var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
if(fuserid=="")
		{
		alert('Please Enter Email Address');
		$('#fuserid').focus();
		return false;
		}
		if(reg.test(fuserid) == false) { 
		alert('Invalid Email Address');
		$('#fuserid').value ="";
		$('#fuserid').focus();
		return false;
		}						
//$('#waitdiv').html('<img src="images/ajax-loader.gif">');
var dataString = 'fuserid=' +fuserid;
		//alert(dataString);
			$.ajax({
			type: "POST",
			url: "send_mail_forgotpass.php",
			data: dataString,
			success: function(theResponse)
			{
			var result=theResponse;
			//alert(result);
			if(result>0 && result==2) {
		    alert('Email Not Registered');
				return false;
			}
			if(result>0 && result==9) {
		    alert('Your password has been reset, Please Check your email.');	
			window.location="index";			
			}

			}
			});
	}
</script>
<script>
function userregFunction() {
var rusername = document.getElementById('rusername').value;
var ruseremail = document.getElementById('ruseremail').value;
var ruserphone = document.getElementById('ruserphone').value;
var ruseraboutme = document.getElementById('ruseraboutme').value;
var ruserpass = document.getElementById('ruserpass').value;
var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;

		if(rusername=="")
		{
		alert('Please Enter Name');
		$('#rusername').focus();
		return false;
		}
		if(ruseremail=="")
		{
		alert('Please Enter Email');
		$('#ruseremail').focus();
		return false;
		}
		if(reg.test(ruseremail) == false) { 
		alert('Invalid Email Id');
		$('#ruseremail').value ="";
		$('#ruseremail').focus();
		return false;
		}
		if(ruserphone=="")
		{
		alert('Please Enter Phone');
		$('#ruserphone').focus();
		return false;
		}
		if(isNaN(ruserphone)) {
		alert('Please Enter Valid Phone');
		$('#ruserphone').focus();
		return false;		
		}
		if(ruseraboutme=="")
		{
		alert('Please Enter About me');
		$('#ruseraboutme').focus();
		return false;
		}								
		if(ruserpass=="")
		{
		alert('Please Enter Password');
		$('#ruserpass').focus();
		return false;
		}			
								
$('#waitdivreg').html('<img src="images/ajax-loader.gif">');
var dataString = 'rusername=' + rusername+ '&ruseremail=' + ruseremail+ '&ruserpass=' +ruserpass+ '&ruserphone=' +ruserphone+ '&ruseraboutme=' +ruseraboutme;
		//alert(dataString);
			$.ajax({
			type: "POST",
			url: "new-user-registration.php",
			data: dataString,
			success: function(theResponse)
			{
			var result=theResponse;
			//alert(result);
			if(result<0 && result==-22) {
			$('#waitdivreg').html('');
			document.getElementById('ruseremail').value="";
			document.getElementById('ruserpass').value="";
			document.getElementById('ruseremail').focus();
			alert("Email Already Registered");
			return false;
			}
		if(result>0 && result==9) {
		$('#waitdivreg').html('');

		alert('Thanks for Registration');	
				//window.location="index.php";					
			location.reload();		
			}

			}
			});
}
</script>
    <script>
	function adc(id)
	{
	//alert(id);
		$("#"+id).show();
		//$("#cboxClose").bind('closes');
		document.getElementById('cboxClose').addEventListener('click', function() {
		 $(".dfcboxOverlay").hide();
		 //alert();
		 return true;
		});
		document.getElementById('cboxOverlay').addEventListener('click', function() {
		 $(".dfcboxOverlay").hide();
		 return true;
		});		
		$(document).keyup(function(e) {
 if (e.keyCode == 27) $(".dfcboxOverlay").hide();   // esc
});
	}
	
	</script>
    <script>
	function adcLog(id)
	{
	//alert(id);
		$("#"+id).show();
		//$("#cboxClose").bind('closes');
		//alert();
		document.getElementById('cboxClose').addEventListener('click', function() {
		 $(".dfcboxOverlay").hide();
		 //alert();
		 return true;
		});
		document.getElementById('cboxOverlay').addEventListener('click', function() {
		 $(".dfcboxOverlay").hide();
		 return true;
		});		
		$(document).keyup(function(e) {
 if (e.keyCode == 27) $(".dfcboxOverlay").hide();   // esc
});
	}
	</script>  
<script>
	function adcRegReview(id)
	{
	//alert(id);
		$("#"+id).show();
		//$("#cboxClose").bind('closes');
		//alert();
		document.getElementById('cboxClose').addEventListener('click', function() {
		 $(".dfcboxOverlay").hide();
		 //alert();
		 return true;
		});
		document.getElementById('cboxOverlay').addEventListener('click', function() {
		 $(".dfcboxOverlay").hide();
		 return true;
		});		
		$(document).keyup(function(e) {
 if (e.keyCode == 27) $(".dfcboxOverlay").hide();   // esc
});
	}
	</script>      
<script>
function forgot_pass() {
document.getElementById('forgotpassdiv').style.display="block";
document.getElementById('logdiv').style.display="none";
}
</script>  
<script>

			$("#Submit").click(function(){
			//if(frmValidate())
			//var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
			var userid = $('#userid').val();
			var password = $('#password').val();		
			
			if(userid=="")
			{
			alert('Please Enter userid');
			$('#userid').focus();
			}else if(password==""){
				alert('Please Enter Password');
		$('#password').focus();
		return false;
				}else{
				sendValueLog($("#formlog").serialize());   
				return false;
			}  
			});

			function sendValueLog(str){
			str = str+"&value=true"; 
			
			$.post("member.php",str , function(data){
			if(data.trim()=="true"){
			window.setTimeout(function(){window.location="myaccount"},2000);}else{
			$('#waitdiverror').html(data);}
			}, "html");
			}
</script> 