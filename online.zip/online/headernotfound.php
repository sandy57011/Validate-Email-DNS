
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js" type="text/javascript"></script>

<script type="text/javascript">
	$(document).ready(function() {
	   	var stickyNavTop = $('.t-menu').offset().top;		   	
	   	var stickyNav = function(){
	    var scrollTop = $(window).scrollTop(); // our current vertical position from the top			         
		    if (scrollTop > stickyNavTop) { 
		        $('.t-menu').addClass('sticky');
		    } else {
		        $('.t-menu').removeClass('sticky'); 
		    }
		};
		stickyNav();			
		$(window).scroll(function() {
			stickyNav();
		});
	});
</script>
<!--------------------  Colorbox   Start   -------------------->
<link rel="stylesheet" type="text/css" href="<?=$rootpath?>/colorbox/colorbox.css" />
<script type="text/javascript" src="<?=$rootpath?>/colorbox/jquery-1.3.2.min.js"></script>
<script type="text/javascript" src="<?=$rootpath?>/colorbox/jquery.colorbox-min.js"></script>
<script type="text/javascript">
$jq123 = $.noConflict();
	$jq123(document).ready(function(){
	//alert();
		$jq123("#test-linkReg").colorbox({width:"300",display:"inline", height:"", inline:true, href:"#test-contentReg"});
		$jq123("#test-linkRegRe").colorbox({width:"300",display:"inline", height:"", inline:true, href:"#test-contentReg"});
		$jq123("#test-linkLog").colorbox({width:"300",display:"inline", height:"", inline:true, href:"#test-contentLog"});
		$jq123("#test-linkRegReview").colorbox({width:"300",display:"inline", height:"", inline:true, href:"#test-contentRegReview"});
	});
</script>
<!------------------    Colorbox End   ------------------------->

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
<link href="<?=$rootpath?>/css/style.css" rel="stylesheet" type="text/css" />
  
<?php $result_pagebulk = mysql_fetch_array(mysql_query("select * from contents where id='7'"));?>    
<?php $result_pageshipping = mysql_fetch_array(mysql_query("select * from contents where id='8'"));?>
<div class="top-nav">
<div>
<div class="tn-l"><a href="<?=$rootpath?>/<?php echo $result_pagebulk['urlname'];?>">For Bulk orders</a></div>

<div class="tn-r">
<a href="<?=$rootpath?>/contactus">Contact us</a> | <a href="<?=$rootpath?>/<?php echo $result_pageshipping['urlname'];?>">Shipping</a> | <a href="returns">Returns</a>
</div>
</div>
</div>


<header>
<div>

<div class="h-left">
<br />
<i class="fa fa-check-square-o"></i> <a href="<?=$rootpath?>/sample">Request for Sample</a>
</div>

<div class="logo"><a href="<?=$rootpath?>/index"><img src="<?=$rootpath?>/images/logo.png" alt="Delivery Kings" /></a></div>



<!------------------------------------------------------> 
 <div class="dfcboxOverlay" style="display:none;"  id="test-contentRegReview">
<h2>User Review Write</h2>
<form name="frmsubmitreview" id="frmsubmitreview" action="" method="post">
    <input type="hidden" name="hidreview" id="hidreview" value="1">
     
    
<div>

<div>Your Rating</div>
<div><div id="click"></div></div>
<div style="clear:both;"></div>

<div>Review Summary</div>
<div><input type="text" name="rheading" id="rheading">
<input type="hidden" name="ustar" id="ustar" value="0">
</div>
<div style="clear:both;"></div>


<div>Review </div>
<div><textarea name="ureview" id="ureview"></textarea></div>
<div style="clear:both;"></div>

<div>&nbsp;</div>
<div><input type="button" name="btnreview" id="btnreview" value="Submit Review" onClick="submitreviewFunction()"></div>
<div style="clear:both;"></div>

<div id="waitdivwritereview" style="text-align:center;"></div>


</div>
</form>
</div>
<!------------------------------------------------------>  

 <div class="clear"></div>
  </div>
 
</header>


  



<div class="t-menu">
<div>
<div id='cssmenu'>
        <ul>
          <li><a href="<?=$rootpath?>/index">Home</a>
          <li><a href="<?=$rootpath?>/philosophy">Our Philosophy</a>
          
<?php
$productCategoryList =getProductCategoryList();
if(count($productCategoryList)>0) {
foreach($productCategoryList as $productCategoryListData) {
	if(getProductCountByCatId($productCategoryListData['id'])>0) {
?>          
          
          <li><?php /*?><a href="<?=$rootpath?>/<?php echo $productCategoryListData['urlname'];?>.htm"><?php echo $productCategoryListData['name']; ?></a><?php */?>
          <a href="#"><?php echo $productCategoryListData['name']; ?></a>
          <ul>
<?php
$allProductListByCatId = getAllProductListByCatId($productCategoryListData['id']);
foreach($allProductListByCatId as $allProductListByCatIdData) {
?>          
          	<li><a href="<?=$rootpath?>/<?php echo $productCategoryListData['urlname']; ?>/<?php echo $allProductListByCatIdData['urlname']; ?>"><?php echo $allProductListByCatIdData['productname']; ?></a></li>
<?php } ?>            
          </ul>
          </li>          
<?php } ?>          
<?php } ?>         
<?php } ?>          
          

          <li><a href="<?=$rootpath?>/gift">Gift Box</a></li>
          <li style="border-right:solid 1px #ccc"><a href="<?=$rootpath?>/blog">Blog</a></li>
        </ul>
        
    </div>
</div>
</div>
<script>
function login_now()
{ 
	$.post("login_form.php",function(data){
			$div = $('<div />').appendTo('body');
			$div.attr('id', 'dynamicl');	
			$('#dynamicl').html(data);
			process();
			},"html");
	}
	
	 function close_login(){
		 $('#dynamicl').remove();
		 }// JavaScript Document
		 
		 function process(){
			$("#Submit").click(function(){
			//if(frmValidate())
			//var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
			var userid = $('#userid').val();
			var password = $('#password').val();		
			
			if(userid=="")
			{
			alert('Please Enter userid');
			$('#userid').focus();
			}else if(password==""){
				alert('Please Enter Password');
		$('#password').focus();
		return false;
				}else{
				sendValue($("#formlog").serialize());   
				return false;
			}  
			});
			}
			function sendValue(str){
			str = str+"&value=true"; 
			
			$.post("member.php",str , function(data){
			if(data.trim()=="true"){
			window.setTimeout(function(){window.location="index.php"},2000);}else{
			//window.setTimeout(function(){window.location="myaccount.php"},2000);}else{
			$('#waitdiverror').html(data);}
			}, "html");
			}
function new_regUser() {
	$.post("user-registration.php",function(data){
			$div = $('<div />').appendTo('body');
			$div.attr('id', 'dynamicl');	
			$('#dynamicl').html(data);
			//processReg();
			},"html");

}			
</script>
<script language="javascript">
function forgotPasswordfunction() {
var fuserid = document.getElementById('fuserid').value;
var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
if(fuserid=="")
		{
		alert('Please Enter Email Address');
		$('#fuserid').focus();
		return false;
		}
		if(reg.test(fuserid) == false) { 
		alert('Invalid Email Address');
		$('#fuserid').value ="";
		$('#fuserid').focus();
		return false;
		}						
//$('#waitdiv').html('<img src="images/ajax-loader.gif">');
var dataString = 'fuserid=' +fuserid;
		//alert(dataString);
			$.ajax({
			type: "POST",
			url: "send_mail_forgotpass.php",
			data: dataString,
			success: function(theResponse)
			{
			var result=theResponse;
			//alert(result);
			if(result>0 && result==2) {
		    alert('Email Not Registered');
				return false;
			}
			if(result>0 && result==9) {
		    alert('Your password has been reset, Please Check your email.');	
			window.location="index";			
			}

			}
			});
	}
</script>
<script>
function userregFunction() {
var rusername = document.getElementById('rusername').value;
var ruseremail = document.getElementById('ruseremail').value;
var ruserphone = document.getElementById('ruserphone').value;
var ruseraboutme = document.getElementById('ruseraboutme').value;
var ruserpass = document.getElementById('ruserpass').value;
var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;

		if(rusername=="")
		{
		alert('Please Enter Name');
		$('#rusername').focus();
		return false;
		}
		if(ruseremail=="")
		{
		alert('Please Enter Email');
		$('#ruseremail').focus();
		return false;
		}
		if(reg.test(ruseremail) == false) { 
		alert('Invalid Email Id');
		$('#ruseremail').value ="";
		$('#ruseremail').focus();
		return false;
		}
		if(ruserphone=="")
		{
		alert('Please Enter Phone');
		$('#ruserphone').focus();
		return false;
		}
		if(isNaN(ruserphone)) {
		alert('Please Enter Valid Phone');
		$('#ruserphone').focus();
		return false;		
		}
		if(ruseraboutme=="")
		{
		alert('Please Enter About me');
		$('#ruseraboutme').focus();
		return false;
		}								
		if(ruserpass=="")
		{
		alert('Please Enter Password');
		$('#ruserpass').focus();
		return false;
		}			
								
$('#waitdivreg').html('<img src="images/ajax-loader.gif">');
var dataString = 'rusername=' + rusername+ '&ruseremail=' + ruseremail+ '&ruserpass=' +ruserpass+ '&ruserphone=' +ruserphone+ '&ruseraboutme=' +ruseraboutme;
		//alert(dataString);
			$.ajax({
			type: "POST",
			url: "new-user-registration.php",
			data: dataString,
			success: function(theResponse)
			{
			var result=theResponse;
			//alert(result);
			if(result<0 && result==-22) {
			$('#waitdivreg').html('');
			document.getElementById('ruseremail').value="";
			document.getElementById('ruserpass').value="";
			document.getElementById('ruseremail').focus();
			alert("Email Already Registered");
			return false;
			}
		if(result>0 && result==9) {
		$('#waitdivreg').html('');

		alert('Thanks for Registration');	
				//window.location="index.php";					
			location.reload();		
			}

			}
			});
}
</script>
    <script>
	function adc(id)
	{
	//alert(id);
		$("#"+id).show();
		//$("#cboxClose").bind('closes');
		document.getElementById('cboxClose').addEventListener('click', function() {
		 $(".dfcboxOverlay").hide();
		 //alert();
		 return true;
		});
		document.getElementById('cboxOverlay').addEventListener('click', function() {
		 $(".dfcboxOverlay").hide();
		 return true;
		});		
		$(document).keyup(function(e) {
 if (e.keyCode == 27) $(".dfcboxOverlay").hide();   // esc
});
	}
	
	</script>
    <script>
	function adcLog(id)
	{
	//alert(id);
		$("#"+id).show();
		//$("#cboxClose").bind('closes');
		//alert();
		document.getElementById('cboxClose').addEventListener('click', function() {
		 $(".dfcboxOverlay").hide();
		 //alert();
		 return true;
		});
		document.getElementById('cboxOverlay').addEventListener('click', function() {
		 $(".dfcboxOverlay").hide();
		 return true;
		});		
		$(document).keyup(function(e) {
 if (e.keyCode == 27) $(".dfcboxOverlay").hide();   // esc
});
	}
	</script>  
<script>
	function adcRegReview(id)
	{
	//alert(id);
		$("#"+id).show();
		//$("#cboxClose").bind('closes');
		//alert();
		document.getElementById('cboxClose').addEventListener('click', function() {
		 $(".dfcboxOverlay").hide();
		 //alert();
		 return true;
		});
		document.getElementById('cboxOverlay').addEventListener('click', function() {
		 $(".dfcboxOverlay").hide();
		 return true;
		});		
		$(document).keyup(function(e) {
 if (e.keyCode == 27) $(".dfcboxOverlay").hide();   // esc
});
	}
	</script>      
<script>
function forgot_pass() {
document.getElementById('forgotpassdiv').style.display="block";
document.getElementById('logdiv').style.display="none";
}
</script>  
<script>

			$("#Submit").click(function(){
			//if(frmValidate())
			//var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
			var userid = $('#userid').val();
			var password = $('#password').val();		
			
			if(userid=="")
			{
			alert('Please Enter userid');
			$('#userid').focus();
			}else if(password==""){
				alert('Please Enter Password');
		$('#password').focus();
		return false;
				}else{
				sendValueLog($("#formlog").serialize());   
				return false;
			}  
			});

			function sendValueLog(str){
			str = str+"&value=true"; 
			
			$.post("member.php",str , function(data){
			if(data.trim()=="true"){
			window.setTimeout(function(){window.location="myaccount"},2000);}else{
			$('#waitdiverror').html(data);}
			}, "html");
			}
</script> 