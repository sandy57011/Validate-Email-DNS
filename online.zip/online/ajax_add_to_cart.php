<?php
@session_start();
include("include/connect.php");
include("include/function.php");

include("includeshoping/functions.php");

if($_REQUEST['command']=='add' && $_REQUEST['productid']>0){
    
	$pid=$_REQUEST['productid'];
	$pqty = 1;
	$productRow = mysql_fetch_array(mysql_query("select * from tbl_products where id ='".$pid."'"));
	$selectprice = 0;
	$selectpriceBulk = $_REQUEST['productidbulk'];
	addtocart($pid,$pqty,$selectprice,$selectpriceBulk);
	ob_start();
	echo count($_SESSION['cart']);
	die();
}
if($_REQUEST['veg_filter']){
	$veg_filter_cat = trim($_REQUEST['veg_filter']);
	$newArrivalProductList = getNewArrivalProductList_filter($veg_filter_cat);
	if(count($newArrivalProductList)>0) {
		foreach($newArrivalProductList as $newArrivalProductListData){
?>
	<div class="product">
		<a href="<?=$rootpath?>/astroDetail-<?php echo getProductCategoryUrlnameById($newArrivalProductListData['cat_id']);?>/<?php echo $newArrivalProductListData['urlname'];?>">
			<div class="p-img">
				<img src="adminimg/logoimg/<?php echo $newArrivalProductListData['logoimg']; ?>" alt="new" />
			</div>
			<div class="<?php if($newArrivalProductListData['non_veg'] ==0){echo 'veg';} else{ echo 'non-veg';} ?>">&nbsp;</div>
			<h3><?php echo $newArrivalProductListData['productname']; ?></h3>
			<h5><i class="fa fa-inr"></i> <?php echo $newArrivalProductListData['productpriceinr'];?>/-</h5>
		</a>
		<span class="btn1" onClick="addtocart('<?php echo $newArrivalProductListData['id']?>','0')"><i class="fa fa-cart-plus" aria-hidden="true"></i> Add to cart</span>
	</div>
<?php }
 } 
}

if($_REQUEST['auto_search_keyword']){
	$search_keyword = trim($_REQUEST['auto_search_keyword']);
	$search_keyword_lists = getSearchProductList($search_keyword);
?>
	<ul id="country-list">
<?php
	if(count($search_keyword_lists)>0){
	foreach($search_keyword_lists as $search_keyword_list) {
?>
	<li>
		<a href="<?=$rootpath?>/astroDetail-<?php echo getProductCategoryUrlnameById($search_keyword_list['cat_id']);?>/<?php echo $search_keyword_list['urlname'];?>">
			<?php echo $search_keyword_list["productname"]; ?>
		</a>
	</li>
	<?php } }else{ echo '<li>No Record Found.</li>'; } ?>
</ul>
<?php	
}